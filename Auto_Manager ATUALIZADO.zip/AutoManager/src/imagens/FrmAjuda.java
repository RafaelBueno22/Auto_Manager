package imagens;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import util.Estilo;


public class FrmAjuda extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(FrmAjuda.class.getName());

        
private JPanel painelConteudo;

// CONTROLE DOS BOTÕES DO MENU
private final java.util.Map<String, JButton> botoesMenu =
        new java.util.HashMap<>();

private String categoriaAtual = "cadastros";

private void criarInterface() {

    JPanel principal = new JPanel(new BorderLayout(0, 20));
    principal.setBackground(Estilo.FUNDO);
    principal.setBorder(new EmptyBorder(25, 30, 25, 30));

    // CABEÇALHO
    JPanel cabecalho = new JPanel(new BorderLayout(0, 15));
    cabecalho.setOpaque(false);

    JPanel textos = new JPanel();
    textos.setOpaque(false);
    textos.setLayout(
        new BoxLayout(textos, BoxLayout.Y_AXIS)
    );

    JLabel titulo = new JLabel("Central de Ajuda");
    titulo.setFont(new Font("Segoe UI", Font.BOLD, 28));
    titulo.setForeground(Estilo.TEXTO);

    JLabel subtitulo = new JLabel(
        "ENCONTRE ORIENTAÇÕES PARA UTILIZAR O AUTOMANAGER"
    );
    subtitulo.setFont(new Font("Segoe UI", Font.PLAIN, 12));
    subtitulo.setForeground(Estilo.TEXTO_SECUNDARIO);

    textos.add(titulo);
    textos.add(Box.createVerticalStrut(7));
    textos.add(subtitulo);

    cabecalho.add(textos, BorderLayout.CENTER);

    JLabel logo = new JLabel(Estilo.carregarLogo(185, 65));
    cabecalho.add(logo, BorderLayout.EAST);

    JPanel divisor = new JPanel();
    divisor.setBackground(Estilo.LARANJA);
    divisor.setPreferredSize(new Dimension(0, 2));
    cabecalho.add(divisor, BorderLayout.SOUTH);

    principal.add(cabecalho, BorderLayout.NORTH);

    // MENU LATERAL
    JPanel menu = new JPanel();
    menu.setLayout(new BoxLayout(menu, BoxLayout.Y_AXIS));
    menu.setBackground(Estilo.PAINEL);
    menu.setBorder(new EmptyBorder(20, 14, 20, 14));
    menu.setPreferredSize(new Dimension(230, 0));

    JLabel tituloMenu = new JLabel("TÓPICOS DE AJUDA");
    tituloMenu.setFont(new Font("Segoe UI", Font.BOLD, 11));
    tituloMenu.setForeground(Estilo.TEXTO_SECUNDARIO);
    tituloMenu.setAlignmentX(Component.LEFT_ALIGNMENT);

    menu.add(tituloMenu);
    menu.add(Box.createVerticalStrut(20));

    menu.add(criarBotaoMenu("Cadastros", "cadastros"));
    menu.add(Box.createVerticalStrut(10));

    menu.add(criarBotaoMenu("Consultas", "consultas"));
    menu.add(Box.createVerticalStrut(10));

    menu.add(criarBotaoMenu(
        "Ordens de Serviço", "ordens"
    ));
    menu.add(Box.createVerticalStrut(10));

    menu.add(criarBotaoMenu("Relatórios", "relatorios"));
    menu.add(Box.createVerticalGlue());

    // PAINEL DE CONTEÚDO
    painelConteudo = new JPanel(new BorderLayout(0, 18));
    painelConteudo.setBackground(Estilo.PAINEL);
    painelConteudo.setBorder(
        new EmptyBorder(25, 28, 25, 28)
    );

    JPanel centro = new JPanel(new BorderLayout(15, 0));
    centro.setOpaque(false);

    centro.add(menu, BorderLayout.WEST);
    centro.add(painelConteudo, BorderLayout.CENTER);

    principal.add(centro, BorderLayout.CENTER);

    // RODAPÉ
    JPanel rodape = new JPanel(new BorderLayout());
    rodape.setOpaque(false);

    JLabel rodapeTexto = new JLabel(
        "AutoManager | Central de suporte e orientações"
    );
    rodapeTexto.setFont(
        new Font("Segoe UI", Font.PLAIN, 12)
    );
    rodapeTexto.setForeground(Estilo.TEXTO_SECUNDARIO);

    JButton btnFechar = new JButton("FECHAR");
    Estilo.configurarBotao(btnFechar, "cinza");
    btnFechar.setPreferredSize(new Dimension(155, 43));
    btnFechar.addActionListener(e -> dispose());

    rodape.add(rodapeTexto, BorderLayout.WEST);
    rodape.add(btnFechar, BorderLayout.EAST);

    principal.add(rodape, BorderLayout.SOUTH);

    setContentPane(principal);

    // EXIBIR A PRIMEIRA CATEGORIA
    mostrarConteudo("cadastros");

    revalidate();
    repaint();
}

// CRIAR BOTÕES DO MENU LATERAL
private JButton criarBotaoMenu(
        String texto, String categoria) {

    JButton botao = new JButton(texto);

    botao.setFont(new Font("Segoe UI", Font.BOLD, 13));
    botao.setHorizontalAlignment(SwingConstants.LEFT);
    botao.setForeground(Estilo.TEXTO);
    botao.setBackground(new Color(45, 52, 64));
    botao.setFocusPainted(false);
    botao.setOpaque(true);

    botao.setBorder(
        new EmptyBorder(13, 15, 13, 15)
    );

    botao.setCursor(
        Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)
    );

    botao.setMaximumSize(
        new Dimension(Integer.MAX_VALUE, 46)
    );

    botao.setAlignmentX(Component.LEFT_ALIGNMENT);

    // REGISTRAR O BOTÃO
    botoesMenu.put(categoria, botao);

    // ABRIR O CONTEÚDO AO CLICAR
    botao.addActionListener(
        e -> mostrarConteudo(categoria)
    );

    return botao;
}

// MOSTRAR CONTEÚDO DA CATEGORIA SELECIONADA
private void mostrarConteudo(String categoria) {

    categoriaAtual = categoria;

    // ATUALIZAR DESTAQUE DOS BOTÕES
    for (java.util.Map.Entry<String, JButton> entrada
            : botoesMenu.entrySet()) {

        boolean selecionado =
            entrada.getKey().equals(categoriaAtual);

        JButton botao = entrada.getValue();

        botao.setBackground(
            selecionado
                ? new Color(75, 49, 35)
                : new Color(45, 52, 64)
        );

        botao.setForeground(
            selecionado
                ? Estilo.LARANJA
                : Estilo.TEXTO
        );
    }

    painelConteudo.removeAll();

    String titulo = "";
    String texto = "";

    switch (categoria) {

        case "cadastros":
            titulo = "Cadastros";
            texto = """
                CADASTRO DE CLIENTES

                1. Acesse Cadastros > Clientes.
                2. Preencha nome, CPF, telefone, e-mail e endereço.
                3. Marque a situação do cliente.
                4. Clique em Cadastrar para salvar.

                CADASTRO DE VEÍCULOS

                1. Acesse Cadastros > Veículos.
                2. Selecione o cliente responsável.
                3. Informe placa, marca, modelo, ano e cor.
                4. Clique em Cadastrar.

                CADASTRO DE MECÂNICOS

                1. Acesse Cadastros > Mecânicos.
                2. Informe os dados do profissional.
                3. Clique em Cadastrar.

                CADASTRO DE SERVIÇOS

                1. Acesse Cadastros > Serviços.
                2. Informe descrição, categoria e valor base.
                3. Clique em Cadastrar.
                """;
            break;

        case "consultas":
            titulo = "Consultas";
            texto = """
                CONSULTA DE REGISTROS

                1. Acesse o menu Consultas.
                2. Escolha Clientes, Veículos, Mecânicos,
                   Serviços ou Ordens de Serviço.
                3. Utilize os filtros disponíveis.
                4. Localize o registro desejado na tabela.

                ALTERAÇÃO DE DADOS

                1. Selecione o registro desejado.
                2. Edite as informações permitidas.
                3. Salve as alterações.

                DICA

                Confira os dados antes de confirmar
                qualquer alteração.
                """;
            break;

        case "ordens":
            titulo = "Ordens de Serviço";
            texto = """
                ABRIR UMA ORDEM DE SERVIÇO

                1. Acesse Cadastros > Ordem de Serviço.
                2. Selecione o veículo.
                3. Selecione o mecânico responsável.
                4. Selecione o serviço.
                5. Informe o problema relatado.
                6. Preencha os demais campos necessários.
                7. Clique em Cadastrar.

                ACOMPANHAMENTO

                A ordem de serviço pode apresentar
                os seguintes estados:

                ABERTA
                EM_ANDAMENTO
                CONCLUIDA
                CANCELADA

                Consulte as ordens para acompanhar
                o andamento dos serviços.
                """;
            break;

        case "relatorios":
            titulo = "Relatórios";
            texto = """
                GERAR RELATÓRIOS

                1. Acesse o menu Relatórios.
                2. Escolha o tipo de relatório:

                   - Clientes
                   - Veículos
                   - Mecânicos
                   - Serviços
                   - Ordens de Serviço

                3. Utilize os filtros disponíveis.
                4. Analise os resultados apresentados.

                Os relatórios ajudam a acompanhar
                os registros e as atividades
                da oficina mecânica.
                """;
            break;

        default:
            titulo = "Ajuda";
            texto = "Selecione um tópico no menu lateral.";
            break;
    }

    // TÍTULO DO CONTEÚDO
    JLabel lblTitulo = new JLabel(titulo);
    lblTitulo.setFont(
        new Font("Segoe UI", Font.BOLD, 22)
    );
    lblTitulo.setForeground(Estilo.TEXTO);

    // TEXTO DAS INSTRUÇÕES
    JTextArea area = new JTextArea(texto);
    area.setFont(
        new Font("Segoe UI", Font.PLAIN, 14)
    );
    area.setForeground(Estilo.TEXTO_SECUNDARIO);
    area.setBackground(Estilo.PAINEL);

    area.setEditable(false);
    area.setFocusable(false);
    area.setLineWrap(true);
    area.setWrapStyleWord(true);
    area.setMargin(new Insets(16, 5, 16, 12));
    area.setCaretPosition(0);

    // ROLAGEM
    JScrollPane scroll = new JScrollPane(area);
    scroll.setBorder(null);
    scroll.setOpaque(false);
    scroll.getViewport().setBackground(Estilo.PAINEL);
    scroll.getVerticalScrollBar().setUnitIncrement(16);

    painelConteudo.add(lblTitulo, BorderLayout.NORTH);
    painelConteudo.add(scroll, BorderLayout.CENTER);

    painelConteudo.revalidate();
    painelConteudo.repaint();
}
    
    
    
    
    
    
    public FrmAjuda() {
        initComponents();

    setTitle("Central de Ajuda | AutoManager");
    setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    setSize(950, 720);
    setResizable(false);
    setLocationRelativeTo(null);

    Estilo.configurarIcone(this);
    criarInterface();
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        com.formdev.flatlaf.FlatDarkLaf.setup();
        java.awt.EventQueue.invokeLater(() -> new FrmAjuda().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
