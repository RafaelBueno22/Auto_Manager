package imagens;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import util.Estilo;

public class FrmSobre extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(FrmSobre.class.getName());

    


private void criarInterface() {

    JPanel principal = new JPanel(new BorderLayout(0, 16));
    principal.setBackground(Estilo.FUNDO);
    principal.setBorder(new EmptyBorder(24, 28, 24, 28));

    // CABEÇALHO COM LOGO
    JPanel cabecalho = new JPanel();
    cabecalho.setOpaque(false);
    cabecalho.setLayout(
        new BoxLayout(cabecalho, BoxLayout.Y_AXIS)
    );

    JLabel logo = new JLabel(Estilo.carregarLogo(260, 95));
    logo.setAlignmentX(Component.CENTER_ALIGNMENT);

    JLabel subtitulo = new JLabel(
        "SISTEMA DE GERENCIAMENTO DE OFICINAS"
    );
    subtitulo.setFont(new Font("Segoe UI", Font.BOLD, 12));
    subtitulo.setForeground(Estilo.TEXTO_SECUNDARIO);
    subtitulo.setAlignmentX(Component.CENTER_ALIGNMENT);

    JLabel versao = new JLabel("VERSÃO 1.0");
    versao.setFont(new Font("Segoe UI", Font.BOLD, 12));
    versao.setForeground(Estilo.LARANJA);
    versao.setAlignmentX(Component.CENTER_ALIGNMENT);

    cabecalho.add(logo);
    cabecalho.add(Box.createVerticalStrut(7));
    cabecalho.add(subtitulo);
    cabecalho.add(Box.createVerticalStrut(10));
    cabecalho.add(versao);

    principal.add(cabecalho, BorderLayout.NORTH);

    // CONTEÚDO CENTRAL
    JPanel conteudo = new JPanel();
    conteudo.setOpaque(false);
    conteudo.setLayout(
        new BoxLayout(conteudo, BoxLayout.Y_AXIS)
    );

    // DESCRIÇÃO
    JPanel cardDescricao = criarCardSobre();
    cardDescricao.setLayout(new BorderLayout(0, 12));

    JLabel tituloSobre = criarTituloSobre("Sobre o sistema");

    JTextArea descricao = new JTextArea(
        "O AutoManager é um sistema de gerenciamento "
        + "de oficinas mecânicas, desenvolvido para "
        + "facilitar o cadastro de clientes, veículos, "
        + "mecânicos e serviços, além do controle de "
        + "ordens de serviço e geração de relatórios."
    );

    descricao.setFont(new Font("Segoe UI", Font.PLAIN, 14));
    descricao.setForeground(Estilo.TEXTO_SECUNDARIO);
    descricao.setBackground(Estilo.PAINEL);
    descricao.setEditable(false);
    descricao.setFocusable(false);
    descricao.setLineWrap(true);
    descricao.setWrapStyleWord(true);
    descricao.setBorder(null);

    cardDescricao.add(tituloSobre, BorderLayout.NORTH);
    cardDescricao.add(descricao, BorderLayout.CENTER);
    cardDescricao.setMaximumSize(
        new Dimension(Integer.MAX_VALUE, 145)
    );

    conteudo.add(cardDescricao);
    conteudo.add(Box.createVerticalStrut(15));

    // FUNCIONALIDADES
    JPanel cardFuncionalidades = criarCardSobre();
    cardFuncionalidades.setLayout(new BorderLayout(0, 15));

    cardFuncionalidades.add(
        criarTituloSobre("Funcionalidades"),
        BorderLayout.NORTH
    );

    JPanel grade = new JPanel(new GridLayout(2, 3, 10, 10));
    grade.setOpaque(false);

    grade.add(criarFuncionalidade("Clientes"));
    grade.add(criarFuncionalidade("Veículos"));
    grade.add(criarFuncionalidade("Mecânicos"));
    grade.add(criarFuncionalidade("Serviços"));
    grade.add(criarFuncionalidade("Ordens de serviço"));
    grade.add(criarFuncionalidade("Relatórios"));

    cardFuncionalidades.add(grade, BorderLayout.CENTER);
    cardFuncionalidades.setMaximumSize(
        new Dimension(Integer.MAX_VALUE, 205)
    );

    conteudo.add(cardFuncionalidades);
    conteudo.add(Box.createVerticalStrut(15));

    // INFORMAÇÕES DO PROJETO
    JPanel cardInformacoes = criarCardSobre();
    cardInformacoes.setLayout(new BorderLayout(0, 14));

    cardInformacoes.add(
        criarTituloSobre("Informações do projeto"),
        BorderLayout.NORTH
    );

    JPanel dados = new JPanel(new GridLayout(3, 1, 0, 10));
    dados.setOpaque(false);

    dados.add(criarLinhaInformacao(
        "DESENVOLVEDOR", "Rafael Correa Bueno"
    ));

    dados.add(criarLinhaInformacao(
        "TURMA", "261T"
    ));

    dados.add(criarLinhaInformacao(
        "TECNOLOGIAS",
        "Java | Swing | NetBeans | JDBC | PostgreSQL"
    ));

    cardInformacoes.add(dados, BorderLayout.CENTER);
    cardInformacoes.setMaximumSize(
        new Dimension(Integer.MAX_VALUE, 185)
    );

    conteudo.add(cardInformacoes);

    JScrollPane rolagem = new JScrollPane(conteudo);
    rolagem.setBorder(null);
    rolagem.setOpaque(false);
    rolagem.getViewport().setOpaque(false);
    rolagem.setHorizontalScrollBarPolicy(
        JScrollPane.HORIZONTAL_SCROLLBAR_NEVER
    );
    rolagem.getVerticalScrollBar().setUnitIncrement(16);

    principal.add(rolagem, BorderLayout.CENTER);

    // RODAPÉ
    JPanel rodape = new JPanel(
        new FlowLayout(FlowLayout.RIGHT, 0, 0)
    );
    rodape.setOpaque(false);

    JButton fechar = new JButton("FECHAR");
    Estilo.configurarBotao(fechar, "cinza");
    fechar.setPreferredSize(new Dimension(150, 42));
    fechar.addActionListener(e -> dispose());

    rodape.add(fechar);
    principal.add(rodape, BorderLayout.SOUTH);

    setContentPane(principal);
    revalidate();
    repaint();
}

private JPanel criarCardSobre() {
    JPanel painel = new JPanel();
    painel.setBackground(Estilo.PAINEL);
    painel.setBorder(new EmptyBorder(18, 20, 18, 20));
    painel.setAlignmentX(Component.LEFT_ALIGNMENT);
    return painel;
}

private JLabel criarTituloSobre(String texto) {
    JLabel titulo = new JLabel(texto);
    titulo.setFont(new Font("Segoe UI", Font.BOLD, 18));
    titulo.setForeground(Estilo.TEXTO);
    return titulo;
}

private JPanel criarFuncionalidade(String nome) {
    JPanel painel = new JPanel(new BorderLayout());
    painel.setBackground(new Color(45, 52, 64));
    painel.setBorder(new EmptyBorder(12, 10, 12, 10));

    JLabel nomeLabel = new JLabel(nome);
    nomeLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
    nomeLabel.setForeground(Estilo.TEXTO);
    nomeLabel.setHorizontalAlignment(SwingConstants.CENTER);

    JPanel detalhe = new JPanel();
    detalhe.setBackground(Estilo.LARANJA);
    detalhe.setPreferredSize(new Dimension(0, 3));

    painel.add(nomeLabel, BorderLayout.CENTER);
    painel.add(detalhe, BorderLayout.SOUTH);

    return painel;
}

private JPanel criarLinhaInformacao(
        String rotulo, String valor) {

    JPanel painel = new JPanel(new BorderLayout(0, 4));
    painel.setOpaque(false);

    JLabel labelRotulo = new JLabel(rotulo);
    labelRotulo.setFont(
        new Font("Segoe UI", Font.BOLD, 10)
    );
    labelRotulo.setForeground(Estilo.TEXTO_SECUNDARIO);

    JLabel labelValor = new JLabel(valor);
    labelValor.setFont(
        new Font("Segoe UI", Font.BOLD, 13)
    );
    labelValor.setForeground(Estilo.TEXTO);

    painel.add(labelRotulo, BorderLayout.NORTH);
    painel.add(labelValor, BorderLayout.CENTER);

    return painel;
}

    
    
    
    
    
    public FrmSobre() {
        initComponents();

    setTitle("Sobre | AutoManager");
    setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    setSize(720, 790);
    setResizable(false);
    setLocationRelativeTo(null);

    Estilo.configurarIcone(this);

    criarInterface();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
       
        
        Estilo.configurarTema();
        java.awt.EventQueue.invokeLater(() -> new FrmSobre().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
