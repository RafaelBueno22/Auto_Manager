
package util;
import java.awt.*;
import javax.swing.*;

/**
 *
 * @author Usuário
 */
public class Mensagem {
    private static void mostrar(
            Component pai,
            String titulo,
            String texto,
            Color destaque,
            String simbolo) {

        Window janelaPai = pai == null
                ? null
                : SwingUtilities.getWindowAncestor(pai);

        JDialog dialogo = new JDialog(
                janelaPai,
                titulo,
                Dialog.ModalityType.APPLICATION_MODAL);

        dialogo.setDefaultCloseOperation(
                JDialog.DISPOSE_ON_CLOSE);

        dialogo.setResizable(false);

        JPanel principal = new JPanel(
                new BorderLayout(18, 0));

        principal.setBackground(Estilo.PAINEL);
        principal.setBorder(
                BorderFactory.createEmptyBorder(
                        25, 28, 25, 28));

        // Barra lateral colorida
        JPanel barra = new JPanel();
        barra.setBackground(destaque);
        barra.setPreferredSize(new Dimension(4, 0));

        principal.add(barra, BorderLayout.WEST);

        // Conteúdo
        JPanel conteudo = new JPanel();
        conteudo.setBackground(Estilo.PAINEL);
        conteudo.setLayout(
                new BoxLayout(conteudo, BoxLayout.Y_AXIS));

        JLabel lblTitulo = new JLabel(
                simbolo + "  " + titulo);

        lblTitulo.setFont(Estilo.FONTE_SUBTITULO);
        lblTitulo.setForeground(destaque);
        lblTitulo.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel lblTexto = new JLabel(texto);
        lblTexto.setFont(Estilo.FONTE_PADRAO);
        lblTexto.setForeground(Estilo.TEXTO);
        lblTexto.setAlignmentX(Component.LEFT_ALIGNMENT);

        conteudo.add(lblTitulo);
        conteudo.add(Box.createVerticalStrut(12));
        conteudo.add(lblTexto);
        conteudo.add(Box.createVerticalStrut(24));

        // Botão
        JButton btnOk = new JButton("ENTENDI");

        Estilo.configurarBotao(btnOk, "laranja");

        btnOk.setPreferredSize(new Dimension(125, 40));
        btnOk.addActionListener(e -> dialogo.dispose());

        JPanel rodape = new JPanel(
                new FlowLayout(FlowLayout.RIGHT, 0, 0));

        rodape.setBackground(Estilo.PAINEL);
        rodape.setAlignmentX(Component.LEFT_ALIGNMENT);
        rodape.add(btnOk);

        conteudo.add(rodape);

        principal.add(conteudo, BorderLayout.CENTER);

        dialogo.setContentPane(principal);
        dialogo.setSize(460, 210);
        dialogo.setLocationRelativeTo(pai);
        dialogo.setVisible(true);
    }

    public static void sucesso(Component pai, String texto) {
        mostrar(
                pai,
                "Operação concluída",
                texto,
                Estilo.VERDE,
                "\u2713");
    }

    public static void erro(Component pai, String texto) {
        mostrar(
                pai,
                "Ocorreu um erro",
                texto,
                Estilo.VERMELHO,
                "\u2715");
    }

    public static void aviso(Component pai, String texto) {
        mostrar(
                pai,
                "Atenção",
                texto,
                Estilo.LARANJA,
                "!");
    }
    public static boolean confirmar(Component pai, String texto) {

    Window janelaPai = pai == null
            ? null
            : SwingUtilities.getWindowAncestor(pai);

    JDialog dialogo = new JDialog(
            janelaPai,
            "Confirmar operação",
            Dialog.ModalityType.APPLICATION_MODAL
    );

    dialogo.setDefaultCloseOperation(
            JDialog.DISPOSE_ON_CLOSE
    );
    dialogo.setResizable(false);

    final boolean[] confirmado = {false};

    JPanel principal = new JPanel(new BorderLayout(18, 0));
    principal.setBackground(Estilo.PAINEL);
    principal.setBorder(
            BorderFactory.createEmptyBorder(25, 28, 25, 28)
    );

    JPanel barra = new JPanel();
    barra.setBackground(Estilo.LARANJA);
    barra.setPreferredSize(new Dimension(4, 0));
    principal.add(barra, BorderLayout.WEST);

    JPanel conteudo = new JPanel();
    conteudo.setOpaque(false);
    conteudo.setLayout(
            new BoxLayout(conteudo, BoxLayout.Y_AXIS)
    );

    JLabel titulo = new JLabel("!  Confirmar operação");
    titulo.setFont(Estilo.FONTE_SUBTITULO);
    titulo.setForeground(Estilo.LARANJA);
    titulo.setAlignmentX(Component.LEFT_ALIGNMENT);

    JLabel descricao = new JLabel(texto);
    descricao.setFont(Estilo.FONTE_PADRAO);
    descricao.setForeground(Estilo.TEXTO);
    descricao.setAlignmentX(Component.LEFT_ALIGNMENT);

    conteudo.add(titulo);
    conteudo.add(Box.createVerticalStrut(14));
    conteudo.add(descricao);
    conteudo.add(Box.createVerticalStrut(24));

    JButton cancelar = new JButton("CANCELAR");
    JButton confirmar = new JButton("CONFIRMAR");

    Estilo.configurarBotao(cancelar, "cinza");
    Estilo.configurarBotao(confirmar, "laranja");

    cancelar.setPreferredSize(new Dimension(135, 40));
    confirmar.setPreferredSize(new Dimension(135, 40));

    cancelar.addActionListener(e -> dialogo.dispose());

    confirmar.addActionListener(e -> {
        confirmado[0] = true;
        dialogo.dispose();
    });

    JPanel botoes = new JPanel(
            new FlowLayout(FlowLayout.RIGHT, 10, 0)
    );
    botoes.setOpaque(false);
    botoes.setAlignmentX(Component.LEFT_ALIGNMENT);

    botoes.add(cancelar);
    botoes.add(confirmar);

    conteudo.add(botoes);
    principal.add(conteudo, BorderLayout.CENTER);

    dialogo.setContentPane(principal);
    dialogo.setSize(460, 220);
    dialogo.setLocationRelativeTo(pai);
    dialogo.setVisible(true);

    return confirmado[0];
}
}
