
package util;
import java.awt.*;
import javax.swing.border.AbstractBorder;

public class BordaArredondada extends AbstractBorder{
    
    
    private final Color cor;
    private final int raio;

    public BordaArredondada(Color cor, int raio) {
        this.cor = cor;
        this.raio = raio;
    }

    @Override
    public void paintBorder(
            Component c, Graphics g,
            int x, int y, int width, int height) {

        Graphics2D g2 = (Graphics2D) g.create();

        g2.setRenderingHint(
            RenderingHints.KEY_ANTIALIASING,
            RenderingHints.VALUE_ANTIALIAS_ON
        );

        g2.setColor(cor);
        g2.setStroke(new BasicStroke(1.5f));

        g2.drawRoundRect(
            x + 1,
            y + 1,
            width - 3,
            height - 3,
            raio,
            raio
        );

        g2.dispose();
    }

    @Override
    public Insets getBorderInsets(Component c) {
        return new Insets(2, 2, 2, 2);
    }

    @Override
    public Insets getBorderInsets(Component c, Insets insets) {
        insets.set(2, 2, 2, 2);
        return insets;
    }
}
