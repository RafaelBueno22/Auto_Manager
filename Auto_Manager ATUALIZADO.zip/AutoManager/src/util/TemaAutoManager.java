package util;
import java.awt.Color;
import java.awt.Font;
import javax.swing.UIManager;

public class TemaAutoManager {
    
     // Cores principais
    public static final Color FUNDO = new Color(17, 19, 24);
    public static final Color PAINEL = new Color(31, 36, 45);
    public static final Color CAMPO = new Color(42, 48, 59);
    public static final Color LARANJA = new Color(249, 115, 22);
    public static final Color LARANJA_HOVER = new Color(234, 88, 12);
    public static final Color TEXTO = new Color(245, 245, 245);
    public static final Color TEXTO_SECUNDARIO = new Color(156, 163, 175);
    public static final Color BORDA = new Color(65, 73, 85);

    // Fontes
    public static final Font TITULO =
            new Font("Montserrat", Font.BOLD, 26);

    public static final Font SUBTITULO =
            new Font("Montserrat", Font.BOLD, 17);

    public static final Font TEXTO_PADRAO =
            new Font("Inter", Font.PLAIN, 14);

    public static final Font BOTAO =
            new Font("Inter", Font.BOLD, 14);

    public static void aplicar() {
        UIManager.put("defaultFont", TEXTO_PADRAO);
        UIManager.put("Component.arc", 12);
        UIManager.put("Button.arc", 12);
        UIManager.put("TextComponent.arc", 10);
        UIManager.put("Component.focusWidth", 1);
        UIManager.put("Component.focusColor", LARANJA);
        UIManager.put("TextComponent.selectBackground",
                new Color(124, 63, 25));
    }
}
