package util;
import java.awt.*;
import javax.swing.*;



public class SwitchAtivo  extends JToggleButton {
    
    private final Color verde = new Color(22, 163, 74);
    private final Color cinza = new Color(75, 85, 99);

    public SwitchAtivo() {
        setSelected(true);
        setPreferredSize(new Dimension(54, 30));
        setMinimumSize(new Dimension(54, 30));
        setMaximumSize(new Dimension(54, 30));

        setOpaque(false);
        setContentAreaFilled(false);
        setBorderPainted(false);
        setFocusPainted(false);
        setCursor(new Cursor(Cursor.HAND_CURSOR));

        addChangeListener(e -> repaint());
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();

        g2.setRenderingHint(
                RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON);

        int largura = getWidth();
        int altura = getHeight();

        // Fundo do interruptor
        g2.setColor(isSelected() ? verde : cinza);
        g2.fillRoundRect(0, 0, largura, altura,
                altura, altura);

        // Círculo branco
        int diametro = altura - 8;
        int x = isSelected()
                ? largura - diametro - 4
                : 4;

        g2.setColor(Color.WHITE);
        g2.fillOval(x, 4, diametro, diametro);

        g2.dispose();
    }
    
}
