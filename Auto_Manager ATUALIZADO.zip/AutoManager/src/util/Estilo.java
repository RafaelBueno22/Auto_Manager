package util;
import com.formdev.flatlaf.FlatDarkLaf;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.Image;
import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;


public class Estilo {
    
    
  // ========================================
    // PALETA DE CORES - AUTOMANAGER 2.0
    // ========================================

    public static final Color FUNDO =
            new Color(17, 19, 24);

    public static final Color COMPONENTE =
            new Color(42, 48, 59);

    public static final Color PAINEL =
            new Color(31, 36, 45);

    public static final Color CABECALHO =
            new Color(37, 43, 53);

    public static final Color TEXTO =
            new Color(245, 245, 245);

    public static final Color TEXTO_SECUNDARIO =
            new Color(156, 163, 175);

    public static final Color LARANJA =
            new Color(249, 115, 22);

    public static final Color LARANJA_HOVER =
            new Color(234, 88, 12);

    // Mantido para compatibilidade com telas antigas
    public static final Color AZUL = LARANJA;

    public static final Color VERDE =
            new Color(22, 163, 74);

    public static final Color VERMELHO =
            new Color(185, 28, 28);

    public static final Color CINZA =
            new Color(75, 85, 99);

    public static final Color BORDA =
            new Color(65, 73, 85);

    // ========================================
    // FONTES - SEM INSTALAÇÃO EXTERNA
    // ========================================

    public static final Font FONTE_PADRAO =
            new Font(Font.SANS_SERIF, Font.PLAIN, 14);

    public static final Font FONTE_BOTAO =
            new Font(Font.SANS_SERIF, Font.BOLD, 14);

    public static final Font FONTE_TITULO =
            new Font(Font.SANS_SERIF, Font.BOLD, 26);

    public static final Font FONTE_SUBTITULO =
            new Font(Font.SANS_SERIF, Font.BOLD, 17);

    public static final Font FONTE_INDICADOR =
            new Font(Font.SANS_SERIF, Font.BOLD, 30);

    // ========================================
    // CONFIGURAÇÃO GLOBAL DO FLATLAF
    // ========================================

    public static void configurarTema() {

        FlatDarkLaf.setup();
        
        UIManager.put("Component.focusWidth", 0);
UIManager.put("Component.innerFocusWidth", 0);
        
       

        UIManager.put("defaultFont", FONTE_PADRAO);

        // Cores gerais
        UIManager.put("Panel.background", FUNDO);
        UIManager.put("Viewport.background", FUNDO);
        UIManager.put("Label.foreground", TEXTO);

        // Botões
        UIManager.put("Button.background", COMPONENTE);
        UIManager.put("Button.foreground", TEXTO);
        UIManager.put("Button.arc", 18);

        // Campos de texto
        UIManager.put("TextField.background", COMPONENTE);
        UIManager.put("TextField.foreground", TEXTO);

        UIManager.put("FormattedTextField.background", COMPONENTE);
        UIManager.put("FormattedTextField.foreground", TEXTO);

        UIManager.put("TextArea.background", COMPONENTE);
        UIManager.put("TextArea.foreground", TEXTO);

        // Arredondamento e foco
        UIManager.put("Component.arc", 18);
        UIManager.put("TextComponent.arc", 18);
        UIManager.put("Component.focusColor", LARANJA);
        UIManager.put("Component.focusWidth", 0);
UIManager.put("Component.innerFocusWidth", 0);
UIManager.put("Component.focusColor", LARANJA);
UIManager.put("Component.borderColor", BORDA);
UIManager.put("Component.focusedBorderColor", LARANJA);
        UIManager.put("Component.accentColor", LARANJA);

        // ComboBoxes
        UIManager.put("ComboBox.background", COMPONENTE);
        UIManager.put("ComboBox.foreground", TEXTO);

        // CheckBox
        UIManager.put("CheckBox.background", FUNDO);
        UIManager.put("CheckBox.foreground", TEXTO);

        // Tabelas
        UIManager.put("Table.background", COMPONENTE);
        UIManager.put("Table.foreground", TEXTO);

        UIManager.put("Table.selectionBackground", LARANJA);
        UIManager.put("Table.selectionForeground", TEXTO);

        UIManager.put("Table.gridColor", BORDA);
        UIManager.put("Table.rowHeight", 35);

        UIManager.put("Table.showHorizontalLines", true);
        UIManager.put("Table.showVerticalLines", false);

        // Cabeçalho das tabelas
        UIManager.put("TableHeader.background", CABECALHO);
        UIManager.put("TableHeader.foreground", TEXTO);

        // Scroll
        UIManager.put("ScrollPane.background", FUNDO);
    }

    // ========================================
    // BOTÕES
    // ========================================

    public static void configurarBotao(
            JButton botao, String tipo) {

        

        botao.setFont(FONTE_BOTAO);
        botao.setForeground(TEXTO);
        botao.setFocusPainted(false);

        botao.setCursor(
                new Cursor(Cursor.HAND_CURSOR));

        Color cor;

        switch (tipo.toLowerCase()) {

            case "azul":
            case "laranja":
                cor = LARANJA;
                break;

            case "verde":
                cor = VERDE;
                break;

            case "vermelho":
                cor = VERMELHO;
                break;

            case "cinza":
                cor = CINZA;
                break;

            default:
                cor = COMPONENTE;
                break;
        }

        botao.setBackground(cor);
        botao.putClientProperty(
    "JButton.buttonType",
    "roundRect"
);
    }

    // ========================================
    // CAMPOS DE TEXTO
    // ========================================

    public static void configurarCampo(JTextField campo) {

   campo.setBackground(COMPONENTE);
    campo.setForeground(TEXTO);
    campo.setCaretColor(TEXTO);
    campo.setFont(FONTE_PADRAO);
    campo.setBorder(UIManager.getBorder("TextField.border"));
campo.putClientProperty("JComponent.roundRect", true);

    // Restaura a borda original do FlatLaf
    campo.setBorder(UIManager.getBorder("TextField.border"));

    // Ativa o formato arredondado
    campo.putClientProperty("JComponent.roundRect", true);
}

    // ========================================
    // COMBOBOX
    // ========================================

    public static void configurarCombo(
            JComboBox<?> combo) {

        combo.setBackground(COMPONENTE);
        combo.setForeground(TEXTO);
        combo.setFont(FONTE_PADRAO);

        combo.putClientProperty(
                "JComponent.roundRect", true);
    }

    // ========================================
    // ÁREAS DE TEXTO
    // ========================================

    public static void configurarArea(
            JTextArea area) {

        area.setBackground(COMPONENTE);
        area.setForeground(TEXTO);
        area.setCaretColor(TEXTO);
        area.setFont(FONTE_PADRAO);

        area.setLineWrap(true);
        area.setWrapStyleWord(true);
    }

    // ========================================
    // TABELAS
    // ========================================

    public static void configurarTabela(
            JTable tabela) {

        tabela.setBackground(COMPONENTE);
        tabela.setForeground(TEXTO);
        tabela.setFont(FONTE_PADRAO);

        tabela.setSelectionBackground(LARANJA);
        tabela.setSelectionForeground(TEXTO);

        tabela.setGridColor(BORDA);
        tabela.setRowHeight(35);

        tabela.setShowVerticalLines(false);
        tabela.setShowHorizontalLines(true);
        tabela.setFillsViewportHeight(true);

        JTableHeaderConfig(tabela);
    }

    private static void JTableHeaderConfig(
            JTable tabela) {

        tabela.getTableHeader().setBackground(CABECALHO);
        tabela.getTableHeader().setForeground(TEXTO);

        tabela.getTableHeader().setFont(FONTE_BOTAO);

        tabela.getTableHeader()
                .setReorderingAllowed(false);
    }

    // ========================================
    // INDICADORES
    // ========================================

    public static void configurarIndicador(
            JTextField campo) {

        configurarCampo(campo);

        campo.setFont(FONTE_INDICADOR);

        campo.setHorizontalAlignment(
                JTextField.CENTER);

        campo.setEditable(false);
    }

    // ========================================
    // BORDAS COM TÍTULO
    // ========================================

    public static void configurarBorda(
            JComponent componente, String titulo) {

        TitledBorder borda =
                BorderFactory.createTitledBorder(
                    BorderFactory.createLineBorder(
                            BORDA, 1),
                    titulo
                );

        borda.setTitleColor(TEXTO_SECUNDARIO);
        borda.setTitleFont(FONTE_PADRAO);

        componente.setBorder(borda);
    }

    // Personaliza bordas criadas no NetBeans
    public static void atualizarBorda(
            JComponent componente) {

        Border bordaAtual = componente.getBorder();

        if (bordaAtual instanceof TitledBorder borda) {

            borda.setTitleColor(TEXTO_SECUNDARIO);
            borda.setTitleFont(FONTE_PADRAO);

            componente.repaint();
        }
    }

    // ========================================
    // TÍTULOS
    // ========================================

    public static void configurarTitulo(
            JLabel label) {

        label.setForeground(TEXTO);
        label.setFont(FONTE_TITULO);
    }

    // ========================================
    // PAINÉIS
    // ========================================

    public static void configurarPainel(
            JPanel painel) {

        painel.setBackground(FUNDO);
    }

    // ========================================
    // APLICAR ESTILO AUTOMATICAMENTE
    // ========================================

    public static void aplicarTela(
            Container tela) {

        // Fundo da janela
        if (tela instanceof JFrame janela) {
            janela.getContentPane().setBackground(FUNDO);
        }

        // Percorre os componentes
        for (Component componente : tela.getComponents()) {

            // Botões
            if (componente instanceof JButton botao) {

                String nome = botao.getText() == null
                        ? ""
                        : botao.getText().trim().toLowerCase();

                if (nome.contains("excluir")
                        || nome.contains("cancelar")) {

                    configurarBotao(botao, "vermelho");

                } else if (
                        nome.contains("cadastrar")
                        || nome.contains("salvar")
                        || nome.contains("alterar")
                        || nome.contains("confirmar")) {

                    configurarBotao(botao, "laranja");

                } else if (
                        nome.contains("fechar")
                        || nome.contains("voltar")
                        || nome.contains("limpar")) {

                    configurarBotao(botao, "cinza");

                } else {

                    configurarBotao(botao, "laranja");
                }
            }

            // Tabelas
            if (componente instanceof JTable tabela) {
                configurarTabela(tabela);
            }

            // ComboBox
            if (componente instanceof JComboBox<?> combo) {
                configurarCombo(combo);
            }

            // Campos de texto
            if (componente instanceof JTextField campo) {
                configurarCampo(campo);
            }

            // Áreas de texto
            if (componente instanceof JTextArea area) {
                configurarArea(area);
            }

            // Bordas existentes
            if (componente instanceof JComponent comp) {
                atualizarBorda(comp);
            }

            // Componentes internos
            if (componente instanceof Container container) {
                aplicarTela(container);
            }
        }
    }
    public static ImageIcon carregarLogo(int largura, int altura) {
    java.net.URL recurso = Estilo.class.getResource(
            "/imagens/logo_automanager.png");

    if (recurso == null) {
        throw new IllegalStateException("Logo não encontrada");
    }

    Image imagem = new ImageIcon(recurso).getImage();

    Image redimensionada = imagem.getScaledInstance(
            largura, altura, Image.SCALE_SMOOTH);

    return new ImageIcon(redimensionada);
}

public static void configurarIcone(JFrame janela) {
    java.net.URL recurso = Estilo.class.getResource(
            "/imagens/icone_automanager.png");

    if (recurso != null) {
        janela.setIconImage(new ImageIcon(recurso).getImage());
    }
}

public static void configurarFoco(JTextField campo) {
 // Mantém a borda nativa do FlatLaf.
    // Não adiciona outra borda nem FocusListener.
    campo.putClientProperty("JComponent.roundRect", true);

    campo.repaint();

}

public static void configurarHover(JButton botao, Color corHover) {

       // Remove o efeito hover manual antigo, caso exista.
    // O FlatLaf cuidará do estado do botão.
    botao.putClientProperty(
            "JButton.hoverBackground", corHover);

    botao.putClientProperty(
            "JButton.pressedBackground",
            corHover.darker());

    botao.setRolloverEnabled(true);
    botao.repaint();
}
}
