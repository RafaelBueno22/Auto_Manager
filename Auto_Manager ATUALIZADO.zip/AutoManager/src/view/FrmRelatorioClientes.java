package view;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import util.Estilo;
import util.Mensagem;

public class FrmRelatorioClientes extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(FrmRelatorioClientes.class.getName());

    
    public FrmRelatorioClientes() {
        initComponents();
        
        tblClientes.setModel(new DefaultTableModel(
        new Object[][] {},
        new String[]{
            "ID", "Nome", "CPF",
            "Telefone", "Email", "Situação"
        }
    ) {
        @Override
        public boolean isCellEditable(int linha, int coluna) {
            return false;
        }
    });

    criarInterface();
    btnRelatorio.doClick();

    }

    
    
    
    
    
    
private void criarInterface() {

    setTitle("AutoManager  | Relatório de Clientes");
    setSize(1350, 900);
setMinimumSize(new Dimension(1100, 750));
    setLocationRelativeTo(null);

    Estilo.configurarIcone(this);

    JPanel principal = new JPanel(new BorderLayout(0, 14));
    principal.setBackground(Estilo.FUNDO);
    principal.setBorder(new EmptyBorder(22, 32, 22, 32));

    // CABEÇALHO
    JPanel cabecalho = new JPanel(new BorderLayout());
    cabecalho.setOpaque(false);

    cabecalho.add(
        new JLabel(Estilo.carregarLogo(280, 94)),
        BorderLayout.WEST
    );

    JLabel secao = new JLabel("RELATÓRIOS / CLIENTES");
    secao.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 15));
    secao.setForeground(Estilo.LARANJA);
    cabecalho.add(secao, BorderLayout.EAST);

    JPanel topo = new JPanel(new BorderLayout(0, 12));
    topo.setOpaque(false);
    topo.add(cabecalho, BorderLayout.CENTER);

    JPanel divisor = new JPanel();
    divisor.setBackground(Estilo.LARANJA);
    divisor.setPreferredSize(new Dimension(0, 2));
    topo.add(divisor, BorderLayout.SOUTH);

    principal.add(topo, BorderLayout.NORTH);

    // CONTEÚDO
    JPanel conteudo = new JPanel(new BorderLayout(0, 20));
    conteudo.setOpaque(false);

    JPanel parteSuperior = new JPanel();
    parteSuperior.setOpaque(false);
    parteSuperior.setLayout(
        new BoxLayout(parteSuperior, BoxLayout.Y_AXIS)
    );

    JLabel titulo = new JLabel("Relatório de Clientes");
    titulo.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 27));
    titulo.setForeground(Estilo.TEXTO);
    titulo.setAlignmentX(Component.LEFT_ALIGNMENT);

    JLabel subtitulo = new JLabel(
        "CONSULTE OS CLIENTES CADASTRADOS NO SISTEMA"
    );
    subtitulo.setForeground(Estilo.TEXTO_SECUNDARIO);
    subtitulo.setAlignmentX(Component.LEFT_ALIGNMENT);

    parteSuperior.add(titulo);
    parteSuperior.add(Box.createVerticalStrut(6));
    parteSuperior.add(subtitulo);
    parteSuperior.add(Box.createVerticalStrut(22));

    // FILTRO
    JPanel cardFiltro = criarCardRelatorio();

    cbSituacao.setModel(new DefaultComboBoxModel<>(
        new String[]{"Todos", "Ativos", "Inativos"}
    ));

    Estilo.configurarCombo(cbSituacao);
    cbSituacao.setBorder(
        UIManager.getBorder("ComboBox.border")
    );

    Estilo.configurarBotao(btnRelatorio, "laranja");
    btnRelatorio.setText("GERAR RELATÓRIO");
    btnRelatorio.setPreferredSize(new Dimension(200, 46));

    JPanel filtro = new JPanel(new BorderLayout(18, 0));
    filtro.setOpaque(false);

    JPanel campoFiltro = new JPanel(new BorderLayout(0, 8));
    campoFiltro.setOpaque(false);

    JLabel lblSituacao = new JLabel("Situação");
    lblSituacao.setForeground(Estilo.TEXTO);
    lblSituacao.setFont(Estilo.FONTE_PADRAO);

    campoFiltro.add(lblSituacao, BorderLayout.NORTH);
    campoFiltro.add(cbSituacao, BorderLayout.CENTER);

    JPanel painelBotao = new JPanel(
        new FlowLayout(FlowLayout.RIGHT, 0, 19)
    );
    painelBotao.setOpaque(false);
    painelBotao.add(btnRelatorio);

    filtro.add(campoFiltro, BorderLayout.CENTER);
    filtro.add(painelBotao, BorderLayout.EAST);

    cardFiltro.add(filtro, BorderLayout.CENTER);
    cardFiltro.setPreferredSize(new Dimension(0, 100));
    cardFiltro.setMaximumSize(
        new Dimension(Integer.MAX_VALUE, 100)
    );

    parteSuperior.add(cardFiltro);
    conteudo.add(parteSuperior, BorderLayout.NORTH);

    // TABELA
    JPanel cardTabela = criarCardRelatorio();

    Estilo.configurarTabela(tblClientes);
    tblClientes.setRowHeight(45);
    tblClientes.setShowVerticalLines(false);
    tblClientes.setShowHorizontalLines(false);
    tblClientes.setFillsViewportHeight(true);
    tblClientes.setAutoCreateRowSorter(true);

    tblClientes.getTableHeader().setReorderingAllowed(false);
    tblClientes.getTableHeader().setPreferredSize(
        new Dimension(0, 44)
    );

    tblClientes.setDefaultRenderer(
        Object.class, new RenderizadorClientesRelatorio()
    );
    tblClientes.setDefaultRenderer(
        Integer.class, new RenderizadorClientesRelatorio()
    );
    tblClientes.setDefaultRenderer(
        String.class, new RenderizadorClientesRelatorio()
    );

    int[] larguras = {65, 230, 160, 170, 260, 120};

    for (int i = 0; i < larguras.length; i++) {
        tblClientes.getColumnModel()
            .getColumn(i).setPreferredWidth(larguras[i]);
    }

    jScrollPane1.setBorder(null);
    jScrollPane1.getViewport().setBackground(Estilo.PAINEL);

    cardTabela.add(jScrollPane1, BorderLayout.CENTER);
    conteudo.add(cardTabela, BorderLayout.CENTER);

    // INDICADORES
    JPanel indicadores = new JPanel(
        new GridLayout(1, 3, 18, 0)
    );
    indicadores.setOpaque(false);

    indicadores.add(criarIndicador(
        "TOTAL DE CLIENTES", txtTotal, Estilo.LARANJA
    ));

    indicadores.add(criarIndicador(
        "CLIENTES ATIVOS", txtAtivos, Estilo.VERDE
    ));

    indicadores.add(criarIndicador(
        "CLIENTES INATIVOS", txtInativos, Estilo.VERMELHO
    ));

    indicadores.setPreferredSize(new Dimension(0, 100));

    conteudo.add(indicadores, BorderLayout.SOUTH);
    principal.add(conteudo, BorderLayout.CENTER);

    // RODAPÉ
    JPanel rodape = new JPanel(
        new FlowLayout(FlowLayout.RIGHT, 0, 0)
    );
    rodape.setOpaque(false);

    Estilo.configurarBotao(btnFechar, "cinza");
    btnFechar.setText("FECHAR");
    btnFechar.setPreferredSize(new Dimension(160, 44));

    rodape.add(btnFechar);
    principal.add(rodape, BorderLayout.SOUTH);

    setContentPane(principal);
    revalidate();
    repaint();
}

// CARD PADRÃO
private JPanel criarCardRelatorio() {

    JPanel painel = new JPanel(new BorderLayout());
    painel.setBackground(Estilo.PAINEL);
    painel.setBorder(
        new EmptyBorder(18, 20, 18, 20)
    );
    painel.setAlignmentX(Component.LEFT_ALIGNMENT);

    return painel;
}

// INDICADOR
private JPanel criarIndicador(
        String titulo, JTextField campo, Color cor) {

    JPanel painel = criarCardRelatorio();

    // Barra colorida
    JPanel detalhe = new JPanel();
    detalhe.setBackground(cor);
    detalhe.setPreferredSize(new Dimension(4, 0));

    painel.add(detalhe, BorderLayout.WEST);

    // Título
    JLabel label = new JLabel(titulo);
    label.setForeground(Estilo.TEXTO_SECUNDARIO);
    label.setFont(
        new Font(Font.SANS_SERIF, Font.BOLD, 13)
    );
    label.setAlignmentX(Component.LEFT_ALIGNMENT);

    // Número
    campo.setEditable(false);
    campo.setFocusable(false);
    campo.setHorizontalAlignment(JTextField.LEFT);
    campo.setFont(
        new Font(Font.SANS_SERIF, Font.BOLD, 34)
    );
    campo.setForeground(Estilo.TEXTO);
    campo.setBackground(Estilo.PAINEL);
    campo.setBorder(null);
    campo.setAlignmentX(Component.LEFT_ALIGNMENT);

    // Impede que o campo fique muito alto
    campo.setPreferredSize(new Dimension(150, 42));
    campo.setMaximumSize(
        new Dimension(Integer.MAX_VALUE, 42)
    );

    // Organiza título e número juntos
    JPanel informacoes = new JPanel();
    informacoes.setOpaque(false);
    informacoes.setLayout(
        new BoxLayout(informacoes, BoxLayout.Y_AXIS)
    );

    informacoes.add(label);
    informacoes.add(Box.createVerticalStrut(5));
    informacoes.add(campo);

    JPanel margem = new JPanel(new BorderLayout());
    margem.setOpaque(false);
    margem.setBorder(
        new EmptyBorder(0, 16, 0, 0)
    );

    margem.add(informacoes, BorderLayout.CENTER);
    painel.add(margem, BorderLayout.CENTER);

    return painel;
}

// RENDERIZADOR DA TABELA
private class RenderizadorClientesRelatorio
        extends DefaultTableCellRenderer {

    @Override
    public Component getTableCellRendererComponent(
            JTable tabela,
            Object valor,
            boolean selecionado,
            boolean foco,
            int linha,
            int coluna) {

        super.getTableCellRendererComponent(
            tabela, valor, selecionado,
            foco, linha, coluna
        );

        setBorder(new EmptyBorder(0, 12, 0, 12));

        if (selecionado) {
            setBackground(new Color(124, 62, 29));
            setForeground(Color.WHITE);
        } else {

            setBackground(
                linha % 2 == 0
                    ? Estilo.PAINEL
                    : new Color(40, 46, 57)
            );

            if (coluna == 5 && valor != null) {
                setForeground(
                    "Ativo".equals(valor.toString())
                        ? new Color(74, 222, 128)
                        : new Color(248, 113, 113)
                );
            } else {
                setForeground(Estilo.TEXTO);
            }
        }

        return this;
    }
    
    
}

    
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton3 = new javax.swing.JButton();
        cbSituacao = new javax.swing.JComboBox<>();
        btnRelatorio = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblClientes = new javax.swing.JTable();
        txtTotal = new javax.swing.JTextField();
        txtAtivos = new javax.swing.JTextField();
        txtInativos = new javax.swing.JTextField();
        btnFechar = new javax.swing.JButton();

        jButton3.setText("Gerar Relatorio");

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        cbSituacao.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Todos", "Ativos", "Inativos" }));
        cbSituacao.setBorder(javax.swing.BorderFactory.createTitledBorder("Situacao"));
        cbSituacao.addActionListener(this::cbSituacaoActionPerformed);

        btnRelatorio.setText("Gerar Relatorio");
        btnRelatorio.addActionListener(this::btnRelatorioActionPerformed);

        tblClientes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Nome", "CPF", "Telefone", "Email", "Situação"
            }
        ));
        jScrollPane1.setViewportView(tblClientes);

        txtTotal.setEditable(false);
        txtTotal.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        txtTotal.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtTotal.setBorder(javax.swing.BorderFactory.createTitledBorder("Total"));

        txtAtivos.setEditable(false);
        txtAtivos.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        txtAtivos.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtAtivos.setBorder(javax.swing.BorderFactory.createTitledBorder("Ativos"));

        txtInativos.setEditable(false);
        txtInativos.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        txtInativos.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtInativos.setBorder(javax.swing.BorderFactory.createTitledBorder("Inativos"));

        btnFechar.setText("Fechar");
        btnFechar.addActionListener(this::btnFecharActionPerformed);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1)
            .addGroup(layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(cbSituacao, javax.swing.GroupLayout.PREFERRED_SIZE, 520, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(52, 52, 52)
                .addComponent(btnRelatorio, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(68, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGap(44, 44, 44)
                .addComponent(txtTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(112, 112, 112)
                .addComponent(txtAtivos, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(txtInativos, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(70, 70, 70))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnFechar, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cbSituacao, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnRelatorio, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 225, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtAtivos, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtInativos, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 33, Short.MAX_VALUE)
                .addComponent(btnFechar, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cbSituacaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbSituacaoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbSituacaoActionPerformed

    private void btnRelatorioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRelatorioActionPerformed
         String situacao = cbSituacao.getSelectedItem().toString();

    String sql = """
        SELECT id, nome, cpf, telefone, email, ativo
        FROM cliente
        """;

    if (situacao.equals("Ativos")) {
        sql += " WHERE ativo = TRUE ";
    } else if (situacao.equals("Inativos")) {
        sql += " WHERE ativo = FALSE ";
    }

    sql += " ORDER BY nome";

    DefaultTableModel modelo =
            (DefaultTableModel) tblClientes.getModel();

    try (Connection conex = Conexao.conectar();
         PreparedStatement stmt = conex.prepareStatement(sql);
         ResultSet rs = stmt.executeQuery()) {

        modelo.setRowCount(0);

        while (rs.next()) {

            modelo.addRow(new Object[]{
                rs.getInt("id"),
                rs.getString("nome"),
                rs.getString("cpf"),
                rs.getString("telefone"),
                rs.getString("email"),
                rs.getBoolean("ativo") ? "Ativo" : "Inativo"
            });
        }

    } catch (SQLException erro) {
        JOptionPane.showMessageDialog(this,
                "Erro ao gerar relatório: " + erro.getMessage());
        return;
    }

    String sqlTotais = """
        SELECT COUNT(*) AS total,
               COUNT(*) FILTER (WHERE ativo = TRUE) AS ativos,
               COUNT(*) FILTER (WHERE ativo = FALSE) AS inativos
        FROM cliente
        """;

    try (Connection conex = Conexao.conectar();
         PreparedStatement stmt = conex.prepareStatement(sqlTotais);
         ResultSet rs = stmt.executeQuery()) {

        if (rs.next()) {
            txtTotal.setText(rs.getString("total"));
            txtAtivos.setText(rs.getString("ativos"));
            txtInativos.setText(rs.getString("inativos"));
        }

    } catch (SQLException erro) {
        JOptionPane.showMessageDialog(this,
                "Erro ao carregar indicadores: " + erro.getMessage());
    }
    }//GEN-LAST:event_btnRelatorioActionPerformed

    private void btnFecharActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFecharActionPerformed
        dispose();
    }//GEN-LAST:event_btnFecharActionPerformed

 
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        Estilo.configurarTema();
        java.awt.EventQueue.invokeLater(() -> new FrmRelatorioClientes().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnFechar;
    private javax.swing.JButton btnRelatorio;
    private javax.swing.JComboBox<String> cbSituacao;
    private javax.swing.JButton jButton3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblClientes;
    private javax.swing.JTextField txtAtivos;
    private javax.swing.JTextField txtInativos;
    private javax.swing.JTextField txtTotal;
    // End of variables declaration//GEN-END:variables
}
