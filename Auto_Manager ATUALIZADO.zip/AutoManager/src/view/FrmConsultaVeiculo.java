package view;

import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import util.Estilo;
import util.SwitchAtivo;

public class FrmConsultaVeiculo extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(FrmConsultaVeiculo.class.getName());
    
    private SwitchAtivo switchAtivo;
private JLabel lblSituacao;
    private ArrayList<Integer> idClientes = new ArrayList<>();
    
        private void carregarClientes(){
            String sql = """
                         SELECT id, nome
                         FROM cliente
                         ORDER BY nome
                         """;
            
            cbCliente.removeAllItems();
            idClientes.clear();
            
            try(Connection conex = Conexao.conectar();
                PreparedStatement stmt = conex.prepareStatement(sql);
                ResultSet rs = stmt.executeQuery()){
                
                while(rs.next()){
                    int id = rs.getInt("id");
                    String nome = rs.getString("nome");
                    
                    cbCliente.addItem(nome);
                    idClientes.add(id);
                    
                    
                }
                
                cbCliente.setSelectedIndex(-1);
            }catch(SQLException erro){
                JOptionPane.showMessageDialog(this, "Erro ao carregar clientes: " +erro.getMessage());
            }
            
        }

       private void atualizarTabela(){
           String sql = """
                        SELECT v.id, c.nome AS cliente, v.placa,
                               v.marca, v.modelo, v.ano, v.cor,
                               v.observacao, v.ativo
                        FROM veiculo v
                        JOIN cliente c ON v.cliente_id = c.id
                        ORDER BY v.id
                        """;
           
           DefaultTableModel modelo = (DefaultTableModel) tblVeiculos.getModel();
           modelo.setRowCount(0);
           
           try(Connection conex = Conexao.conectar();
               PreparedStatement stmt = conex.prepareStatement(sql);
               ResultSet rs = stmt.executeQuery()){
               
               while(rs.next()){
                   modelo.addRow(new Object []{
                       rs.getInt("id"),
                       rs.getString("cliente"),
                       rs.getString("placa"),
                       rs.getString("marca"),
                       rs.getString("modelo"),
                       rs.getInt("ano"),
                       rs.getString("cor"),
                       rs.getString("observacao"),
                       rs.getBoolean("ativo")
                   });
               }
           }catch(SQLException erro){
               JOptionPane.showMessageDialog(this, "Erro ao carregar veículo: " +erro.getMessage());
           }
       }

    public FrmConsultaVeiculo() {
        initComponents();
        
        tblVeiculos.setModel(new DefaultTableModel(
        new Object[][]{},
        new String[]{
            "ID", "Proprietário", "Placa", "Marca",
            "Modelo", "Ano", "Cor", "Observação", "Situação"
        }
    ) {
        @Override
        public boolean isCellEditable(int linha, int coluna) {
            return false;
        }
    });

    tblVeiculos.setSelectionMode(
        javax.swing.ListSelectionModel.SINGLE_SELECTION
    );

    carregarClientes();
    criarInterface();
    atualizarTabela();
        
        
    }
    
    
private void criarInterface() {

    setTitle("AutoManager | Consulta de Veículos");
    setSize(1350, 900);
setResizable(false);
setLocationRelativeTo(null);

    Estilo.configurarIcone(this);

    JPanel principal = new JPanel(new BorderLayout(0, 16));
    principal.setBackground(Estilo.FUNDO);
    principal.setBorder(new EmptyBorder(22, 32, 22, 32));

    // CABEÇALHO
    JPanel cabecalho = new JPanel(new BorderLayout());
    cabecalho.setOpaque(false);

    cabecalho.add(
        new JLabel(Estilo.carregarLogo(280, 94)),
        BorderLayout.WEST
    );

    JLabel secao = new JLabel("VEÍCULOS / CONSULTA");
    secao.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 15));
    secao.setForeground(Estilo.LARANJA);
    cabecalho.add(secao, BorderLayout.EAST);

    JPanel topo = new JPanel(new BorderLayout(0, 12));
    topo.setOpaque(false);
    topo.add(cabecalho, BorderLayout.CENTER);

    JPanel linhaLaranja = new JPanel();
    linhaLaranja.setBackground(Estilo.LARANJA);
    linhaLaranja.setPreferredSize(new Dimension(0, 2));
    topo.add(linhaLaranja, BorderLayout.SOUTH);

    principal.add(topo, BorderLayout.NORTH);

    // CONTEÚDO
    JPanel conteudo = new JPanel();
    conteudo.setOpaque(false);
    conteudo.setLayout(
        new BoxLayout(conteudo, BoxLayout.Y_AXIS)
    );
    conteudo.setBorder(
        new EmptyBorder(0, 0, 25, 0)
    );

    JLabel titulo = new JLabel("Consulta de Veículos");
    titulo.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 27));
    titulo.setForeground(Estilo.TEXTO);
    titulo.setAlignmentX(Component.LEFT_ALIGNMENT);

    JLabel subtitulo = new JLabel(
        "PESQUISE, VISUALIZE, ALTERE OU EXCLUA VEÍCULOS"
    );
    subtitulo.setForeground(Estilo.TEXTO_SECUNDARIO);
    subtitulo.setAlignmentX(Component.LEFT_ALIGNMENT);

    conteudo.add(titulo);
    conteudo.add(Box.createVerticalStrut(6));
    conteudo.add(subtitulo);
    conteudo.add(Box.createVerticalStrut(20));

    // PESQUISA
    JPanel pesquisa = criarCardVeiculo();

    Estilo.configurarCombo(cbPesquisarPor);
    cbPesquisarPor.setBorder(
        UIManager.getBorder("ComboBox.border")
    );
    cbPesquisarPor.setPreferredSize(new Dimension(170, 42));

    Estilo.configurarCampo(txtPesquisar);
    Estilo.configurarFoco(txtPesquisar);
    txtPesquisar.putClientProperty(
        "JTextField.placeholderText",
        "Digite o ID, placa, marca, modelo ou cliente"
    );
    txtPesquisar.setPreferredSize(new Dimension(300, 42));

    Estilo.configurarBotao(btnLocalizar, "laranja");
    Estilo.configurarBotao(btnAtualizar, "cinza");

    btnLocalizar.setText("BUSCAR");
    btnAtualizar.setText("ATUALIZAR");

    btnLocalizar.setPreferredSize(new Dimension(140, 42));
    btnAtualizar.setPreferredSize(new Dimension(145, 42));

    JPanel entrada = new JPanel(new BorderLayout(12, 0));
    entrada.setOpaque(false);
    entrada.add(cbPesquisarPor, BorderLayout.WEST);
    entrada.add(txtPesquisar, BorderLayout.CENTER);

    JPanel botoesPesquisa = new JPanel(
        new FlowLayout(FlowLayout.RIGHT, 10, 0)
    );
    botoesPesquisa.setOpaque(false);
    botoesPesquisa.add(btnLocalizar);
    botoesPesquisa.add(btnAtualizar);

    JPanel busca = new JPanel(new BorderLayout(12, 0));
    busca.setOpaque(false);
    busca.add(entrada, BorderLayout.CENTER);
    busca.add(botoesPesquisa, BorderLayout.EAST);

    pesquisa.add(busca, BorderLayout.NORTH);
    pesquisa.setMaximumSize(
        new Dimension(Integer.MAX_VALUE, 80)
    );

    conteudo.add(pesquisa);
    conteudo.add(Box.createVerticalStrut(18));

    // TABELA
    JPanel cardTabela = criarCardVeiculo();

    Estilo.configurarTabela(tblVeiculos);
    tblVeiculos.setRowHeight(38);
    tblVeiculos.setShowVerticalLines(false);
    tblVeiculos.setShowHorizontalLines(false);
    tblVeiculos.setFillsViewportHeight(true);
    tblVeiculos.setSelectionBackground(
        new Color(124, 62, 29)
    );
    tblVeiculos.setSelectionForeground(Color.WHITE);

    tblVeiculos.getTableHeader().setReorderingAllowed(false);
    tblVeiculos.getTableHeader().setPreferredSize(
        new Dimension(0, 42)
    );

    tblVeiculos.setAutoCreateRowSorter(true);
    tblVeiculos.setDefaultRenderer(
        Object.class, new RenderizadorVeiculo()
    );
    tblVeiculos.setDefaultRenderer(
        Boolean.class, new RenderizadorVeiculo()
    );
    tblVeiculos.setDefaultRenderer(
        Integer.class, new RenderizadorVeiculo()
    );

    
    tblVeiculos.setAutoResizeMode(
        JTable.AUTO_RESIZE_SUBSEQUENT_COLUMNS
    );
    int[] larguras = {
    55, 160, 100, 110, 135,
    65, 90, 210, 85
};

for (int i = 0; i < larguras.length; i++) {
    tblVeiculos.getColumnModel()
        .getColumn(i)
        .setPreferredWidth(larguras[i]);
}

    jScrollPane1.setBorder(null);
    jScrollPane1.getViewport().setBackground(Estilo.PAINEL);
    jScrollPane1.setPreferredSize(new Dimension(0, 220));
    jScrollPane1.setHorizontalScrollBarPolicy(
        JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED
    );

    cardTabela.add(jScrollPane1, BorderLayout.CENTER);
    cardTabela.setMaximumSize(
        new Dimension(Integer.MAX_VALUE, 260)
    );

    conteudo.add(cardTabela);
    conteudo.add(Box.createVerticalStrut(18));

    // PAINEL DE EDIÇÃO
    JPanel edicao = criarCardVeiculo();

    JPanel corpoEdicao = new JPanel(new BorderLayout(0, 16));
    corpoEdicao.setOpaque(false);

    JLabel tituloEdicao = new JLabel(
        "EDITAR VEÍCULO SELECIONADO"
    );
    tituloEdicao.setForeground(Estilo.TEXTO);
    tituloEdicao.setFont(
        new Font(Font.SANS_SERIF, Font.BOLD, 14)
    );

    corpoEdicao.add(tituloEdicao, BorderLayout.NORTH);

    JTextField[] campos = {
        txtID, txtPlaca, txtMarca,
        txtModelo, txtAno, txtCor
    };

    for (JTextField campo : campos) {
        Estilo.configurarCampo(campo);

        campo.setBorder(
            UIManager.getBorder("TextField.border")
        );
        campo.putClientProperty(
            "JComponent.roundRect", true
        );

        if (campo != txtID) {
            Estilo.configurarFoco(campo);
        }
    }

    txtID.setEditable(false);
    txtID.setFocusable(false);
    txtID.setBackground(new Color(35, 40, 49));

    Estilo.configurarCombo(cbCliente);
    cbCliente.setBorder(
        UIManager.getBorder("ComboBox.border")
    );

    Estilo.configurarArea(txtObs);
    txtObs.setBorder(new EmptyBorder(10, 12, 10, 12));
    txtObs.setLineWrap(true);
    txtObs.setWrapStyleWord(true);

    jScrollPane2.setBorder(
        UIManager.getBorder("ScrollPane.border")
    );
    jScrollPane2.getViewport().setBackground(
        Estilo.COMPONENTE
    );
    jScrollPane2.setPreferredSize(new Dimension(0, 85));

    // CAMPOS
    JPanel grade = new JPanel(
        new GridLayout(4, 2, 16, 12)
    );
    grade.setOpaque(false);
    
    // Altura fixa para cada linha
grade.setPreferredSize(new Dimension(0, 340));

    grade.add(criarCampoVeiculo("ID", txtID));
    grade.add(criarCampoVeiculo("Proprietário", cbCliente));

    grade.add(criarCampoVeiculo("Placa", txtPlaca));
    grade.add(criarCampoVeiculo("Marca", txtMarca));

    grade.add(criarCampoVeiculo("Modelo", txtModelo));
    grade.add(criarCampoVeiculo("Ano", txtAno));

    grade.add(criarCampoVeiculo("Cor", txtCor));
    grade.add(criarCampoVeiculo("Observações", jScrollPane2));

    corpoEdicao.add(grade, BorderLayout.CENTER);
    edicao.setPreferredSize(new Dimension(0, 470));

edicao.setMaximumSize(
    new Dimension(Integer.MAX_VALUE, 470)
);

    // INTERRUPTOR ATIVO / INATIVO
    switchAtivo = new SwitchAtivo();
    switchAtivo.setSelected(chkAtivo.isSelected());

    lblSituacao = new JLabel(
        switchAtivo.isSelected()
            ? "Veículo ativo"
            : "Veículo inativo"
    );
    lblSituacao.setForeground(Estilo.TEXTO);
    lblSituacao.setFont(Estilo.FONTE_PADRAO);

    switchAtivo.addActionListener(e -> {
        boolean ativo = switchAtivo.isSelected();
        chkAtivo.setSelected(ativo);
        lblSituacao.setText(
            ativo ? "Veículo ativo" : "Veículo inativo"
        );
    });

    JPanel situacao = new JPanel(
        new FlowLayout(FlowLayout.LEFT, 12, 0)
    );
    situacao.setOpaque(false);
    situacao.add(switchAtivo);
    situacao.add(lblSituacao);

    corpoEdicao.add(situacao, BorderLayout.SOUTH);

    edicao.add(corpoEdicao, BorderLayout.CENTER);

    // ESSENCIAL: adiciona o painel à tela
    conteudo.add(edicao);

    // ROLAGEM CENTRAL
    JScrollPane scrollCentral = new JScrollPane(conteudo);
    scrollCentral.setBorder(null);
    scrollCentral.setOpaque(false);
    scrollCentral.getViewport().setOpaque(false);
    scrollCentral.getVerticalScrollBar().setUnitIncrement(16);
    scrollCentral.setHorizontalScrollBarPolicy(
        JScrollPane.HORIZONTAL_SCROLLBAR_NEVER
    );

    principal.add(scrollCentral, BorderLayout.CENTER);

    // RODAPÉ
    JPanel rodape = new JPanel(
        new FlowLayout(FlowLayout.RIGHT, 12, 0)
    );
    rodape.setOpaque(false);

    Estilo.configurarBotao(btnFechar, "cinza");
    Estilo.configurarBotao(btnExcluir, "vermelho");
    Estilo.configurarBotao(btnAlterar, "laranja");

    btnFechar.setText("FECHAR");
    btnExcluir.setText("EXCLUIR");
    btnAlterar.setText("ALTERAR");

    btnFechar.setPreferredSize(new Dimension(155, 44));
    btnExcluir.setPreferredSize(new Dimension(155, 44));
    btnAlterar.setPreferredSize(new Dimension(155, 44));

    rodape.add(btnFechar);
    rodape.add(btnExcluir);
    rodape.add(btnAlterar);

    principal.add(rodape, BorderLayout.SOUTH);

    txtPesquisar.addActionListener(
        e -> btnLocalizar.doClick()
    );

    setContentPane(principal);

    revalidate();
    repaint();
}


private JPanel criarCardVeiculo() {
    JPanel painel = new JPanel(new BorderLayout());
    painel.setBackground(Estilo.PAINEL);
    painel.setBorder(
        new EmptyBorder(18, 20, 18, 20)
    );
    painel.setAlignmentX(Component.LEFT_ALIGNMENT);
    return painel;
}

private JPanel criarCampoVeiculo(
        String titulo, JComponent campo) {

    JPanel painel = new JPanel(new BorderLayout(0, 6));
    painel.setOpaque(false);

    JLabel label = new JLabel(titulo);
    label.setForeground(Estilo.TEXTO);

    painel.add(label, BorderLayout.NORTH);
    painel.add(campo, BorderLayout.CENTER);

    return painel;
}

private class RenderizadorVeiculo
        extends DefaultTableCellRenderer {

    @Override
    public Component getTableCellRendererComponent(
            JTable tabela,
            Object valor,
            boolean selecionado,
            boolean foco,
            int linha,
            int coluna) {

        Object exibicao = valor;

        if (coluna == 8 && valor instanceof Boolean ativo) {
            exibicao = ativo ? "Ativo" : "Inativo";
        }

        super.getTableCellRendererComponent(
            tabela, exibicao, selecionado,
            foco, linha, coluna
        );

        setBorder(new EmptyBorder(0, 12, 0, 12));

        if (selecionado) {
            setBackground(new Color(124, 62, 29));
            setForeground(Color.WHITE);
        } else {
            setBackground(
                linha % 2 == 0
                    ? Estilo.PAINEL
                    : new Color(40, 46, 57)
            );

            if (coluna == 8 && valor instanceof Boolean ativo) {
                setForeground(
                    ativo
                        ? new Color(74, 222, 128)
                        : new Color(248, 113, 113)
                );
            } else {
                setForeground(Estilo.TEXTO);
            }
        }

        return this;
    }
}


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        cbPesquisarPor = new javax.swing.JComboBox<>();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        txtPesquisar = new javax.swing.JTextField();
        btnLocalizar = new javax.swing.JButton();
        btnAtualizar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblVeiculos = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtID = new javax.swing.JTextField();
        cbCliente = new javax.swing.JComboBox<>();
        txtPlaca = new javax.swing.JTextField();
        txtMarca = new javax.swing.JTextField();
        txtModelo = new javax.swing.JTextField();
        txtCor = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtObs = new javax.swing.JTextArea();
        chkAtivo = new javax.swing.JCheckBox();
        btnAlterar = new javax.swing.JButton();
        btnFechar = new javax.swing.JButton();
        btnExcluir = new javax.swing.JButton();
        txtAno = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        cbPesquisarPor.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ID", "Placa", "Marca", "Modelo", "Cliente", " " }));
        cbPesquisarPor.setBorder(javax.swing.BorderFactory.createTitledBorder("Filtro:"));
        cbPesquisarPor.addActionListener(this::cbPesquisarPorActionPerformed);

        jPanel1.setBackground(new java.awt.Color(0, 0, 255));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 88, Short.MAX_VALUE)
        );

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel1.setText("Pesquisar Veículos");

        txtPesquisar.setBorder(javax.swing.BorderFactory.createTitledBorder("Pesquisar"));

        btnLocalizar.setText("Localizar");
        btnLocalizar.addActionListener(this::btnLocalizarActionPerformed);

        btnAtualizar.setText("Atualizar");
        btnAtualizar.addActionListener(this::btnAtualizarActionPerformed);

        tblVeiculos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Cliente", "Placa", "Marca", "Modelo", "Ano", "Cor", "Observação", "Ativo"
            }
        ));
        tblVeiculos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblVeiculosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblVeiculos);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel2.setText("Veículos Cadastrados");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel3.setText("Dados do Veículo");

        txtID.setEditable(false);
        txtID.setBorder(javax.swing.BorderFactory.createTitledBorder("ID"));

        cbCliente.setBorder(javax.swing.BorderFactory.createTitledBorder("Cliente:"));

        txtPlaca.setBorder(javax.swing.BorderFactory.createTitledBorder("Placa"));

        txtMarca.setBorder(javax.swing.BorderFactory.createTitledBorder("Marca:"));

        txtModelo.setBorder(javax.swing.BorderFactory.createTitledBorder("Modelo:"));

        txtCor.setBorder(javax.swing.BorderFactory.createTitledBorder("Cor:"));

        txtObs.setColumns(20);
        txtObs.setRows(5);
        txtObs.setBorder(javax.swing.BorderFactory.createTitledBorder("Observação:"));
        jScrollPane2.setViewportView(txtObs);

        chkAtivo.setSelected(true);
        chkAtivo.setText("Ativo");

        btnAlterar.setText("Alterar");
        btnAlterar.addActionListener(this::btnAlterarActionPerformed);

        btnFechar.setText("Fechar");
        btnFechar.addActionListener(this::btnFecharActionPerformed);

        btnExcluir.setText("Excluir");
        btnExcluir.addActionListener(this::btnExcluirActionPerformed);

        txtAno.setBorder(javax.swing.BorderFactory.createTitledBorder("Ano:"));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jScrollPane1)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(cbPesquisarPor, javax.swing.GroupLayout.PREFERRED_SIZE, 382, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(47, 47, 47)
                                .addComponent(txtPesquisar, javax.swing.GroupLayout.PREFERRED_SIZE, 463, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(43, 43, 43)
                                .addComponent(btnLocalizar, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(44, 44, 44)
                                .addComponent(btnAtualizar, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel1)
                            .addComponent(jLabel3)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(txtPlaca)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtID, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(cbCliente, javax.swing.GroupLayout.Alignment.LEADING, 0, 333, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtModelo, javax.swing.GroupLayout.PREFERRED_SIZE, 333, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtMarca, javax.swing.GroupLayout.PREFERRED_SIZE, 333, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txtCor, javax.swing.GroupLayout.DEFAULT_SIZE, 140, Short.MAX_VALUE)
                                    .addComponent(txtAno))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(52, 52, 52)
                                .addComponent(chkAtivo)))
                        .addGap(87, 87, 87))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnAlterar, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnExcluir, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnFechar, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnLocalizar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnAtualizar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(txtPesquisar)
                    .addComponent(cbPesquisarPor))
                .addGap(31, 31, 31)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel3)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(cbCliente, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
                                    .addComponent(txtMarca)
                                    .addComponent(txtAno))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txtPlaca, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
                                    .addComponent(txtCor)
                                    .addComponent(txtModelo)))
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 112, Short.MAX_VALUE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(101, 101, 101)
                        .addComponent(chkAtivo)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 66, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAlterar, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnExcluir, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnFechar, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cbPesquisarPorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbPesquisarPorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbPesquisarPorActionPerformed

    private void btnFecharActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFecharActionPerformed
        dispose();
    }//GEN-LAST:event_btnFecharActionPerformed

    private void btnAtualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAtualizarActionPerformed
        atualizarTabela();
    }//GEN-LAST:event_btnAtualizarActionPerformed

    private void btnExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExcluirActionPerformed
        int linha = tblVeiculos.getSelectedRow();
        if(linha == -1){
           JOptionPane.showMessageDialog(this, "Selecione um Veículo.");
        return; 
        
        }
        
        int id = Integer.parseInt(txtID.getText().trim());
        
        int confirmar = JOptionPane.showConfirmDialog(this,
                                                      "Deseja realmente excluir este veículo?",
                                                      "Confirmar exclusão",
                                                      JOptionPane.YES_NO_OPTION);
        
        if(confirmar != JOptionPane.YES_OPTION) return;   
        
        String sqlVerificar = """
                              SELECT COUNT (*)
                              FROM ordem_servico
                              WHERE veiculo_id = ?
                              """;
        
        try(Connection conex = Conexao.conectar()){
            int quantidade = 0;
            
            try(PreparedStatement stmt = conex.prepareStatement(sqlVerificar)){
                stmt.setInt(1, id);
                
                try(ResultSet rs = stmt.executeQuery()){
                    if(rs.next()){
                        quantidade = rs.getInt(1);
                    }
                }
            }    
            
            if(quantidade > 0){
               int opcao = JOptionPane.showConfirmDialog(this,
                                                         "Este veículo possui " + quantidade
                                                       + " Ordem(ns) de Serviço vinculada(s).\n"
                                                       + "Não é possível excluí-lo sem perder o histórico.\n\n"
                                                       + "Deseja desativar o veículo?",
                                                         "Veículo com histórico",
                                                          JOptionPane.YES_NO_OPTION);
               
               if(opcao != JOptionPane.YES_OPTION)return;
               
               String sqlDesativar = """
                                     UPDATE veiculo
                                     SET ativo = FALSE
                                     WHERE id = ?
                                     """;
               
               try(PreparedStatement stmt = conex.prepareStatement(sqlDesativar)){
                   stmt.setInt(1, id);
                     
                   int linhas = stmt.executeUpdate();
                    

                   if(linhas > 0){
                       JOptionPane.showMessageDialog(this, "Veículo desativado com sucesso!");
                   }
               }
       
            
        }else{
                String sqlExcluir = """
                                    DELETE FROM veiculo
                                    WHERE id = ?
                                    """;
                
                try(PreparedStatement stmt = conex.prepareStatement(sqlExcluir)){
                
                    stmt.setInt(1, id);
                    
                    int linhas = stmt.executeUpdate();
                    
                
                if(linhas > 0){
                    JOptionPane.showMessageDialog(this, "Veículo excluído com sucesso!");
                
                }else{
                    JOptionPane.showMessageDialog(this, "Veículo não encontrado!");
                }
              }
           }
        atualizarTabela();
        
    }catch(SQLException erro){
        JOptionPane.showMessageDialog(this, "Erro ao excluir veículo: " + erro.getMessage());
      }
    }//GEN-LAST:event_btnExcluirActionPerformed

    private void btnLocalizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLocalizarActionPerformed
        String pesquisa = txtPesquisar.getText().trim();
        
        if(pesquisa.isEmpty()){
            JOptionPane.showMessageDialog(
                    this,
                    "Digite o nome ou parte do nome do Veiculo.",
                    "Pesquisa Vazia",
                     JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        DefaultTableModel modelo = (DefaultTableModel) tblVeiculos.getModel();
        
        modelo.setRowCount(0);
        
        String tipo_pesquisa = cbPesquisarPor.getSelectedItem().toString();
        
        String sql = "";
        
        if(tipo_pesquisa == "ID"){
            sql = """
                  SELECT v.*, c.nome AS cliente
                  FROM veiculo v
                  JOIN cliente c ON v.cliente_id = c.id
                  WHERE v.id = ?
                  ORDER BY v.id
                  """;
        }else if(tipo_pesquisa == "Placa" ){
            sql = """
                   SELECT v.*, c.nome AS cliente
                   FROM veiculo v
                   JOIN cliente c ON v.cliente_id = c.id
                   WHERE v.placa ILIKE ?
                   ORDER BY v.placa
                  """;
        }else if (tipo_pesquisa == "Marca"){
            sql = """
                 SELECT v.*, c.nome AS cliente
                 FROM veiculo v
                 JOIN cliente c ON v.cliente_id = c.id
                 WHERE v.marca ILIKE ?
                 ORDER BY v.marca
                 """;
        }else if(tipo_pesquisa == "Modelo"){
            sql = """
                  SELECT v.*, c.nome AS cliente
                  FROM veiculo v
                  JOIN cliente c ON v.cliente_id = c.id
                  WHERE v.modelo ILIKE ?
                  ORDER BY v.modelo
                  """;
        }else if(tipo_pesquisa == "Cliente"){
            sql = """
                  SELECT v.*, c.nome AS cliente
                  FROM veiculo v
                  JOIN cliente c ON v.cliente_id = c.id
                  WHERE c.nome ILIKE ?
                  ORDER BY c.nome
                  """;
        }else{
            JOptionPane.showMessageDialog(this, "Selecione um tipo de pesquisa válido!");
            return;
        }
        
        try {
            if(tipo_pesquisa == "ID"){
               int id = Integer.parseInt(txtPesquisar.getText().toString());
                
    }
        } catch (NumberFormatException erro) {
        JOptionPane.showMessageDialog(this,
                "Informe valores numéricos válidos!");
        return;

        }
        try (
             Connection conex = Conexao.conectar();
             PreparedStatement stmt = conex.prepareStatement(sql)){
            if(tipo_pesquisa == "ID"){
               int id = Integer.parseInt(txtPesquisar.getText().toString());
                stmt.setInt(1, id);
            }else{
        stmt.setString(1, "%" +pesquisa+ "%");
    }  
            try (ResultSet resultado = stmt.executeQuery()){
                while (resultado.next()){
                    modelo.addRow(new Object [] {
                    resultado.getInt("id"),
                    resultado.getString("cliente"),
                    resultado.getString("placa"),
                    resultado.getString("marca"),
                    resultado.getString("modelo"),
                    resultado.getString("ano"),
                    resultado.getString("cor"),
                    resultado.getString("observacao"),
                    resultado.getBoolean("ativo")});
                }
            }
            if(modelo.getRowCount() ==0) {
                  JOptionPane.showMessageDialog(this,
                            "Nenhum Veículo encontrado para: " + pesquisa,
                            "Resultado da Pesquisa",
                            JOptionPane.INFORMATION_MESSAGE);
            }
        }catch(SQLException erro) {
            JOptionPane.showMessageDialog(this, 
                                          "Erro ao localizar o Veículo:\n" + erro.getMessage(),
                                          "Erro no banco de dados",
                                          JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnLocalizarActionPerformed

    private void btnAlterarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAlterarActionPerformed
        int linha = tblVeiculos.getSelectedRow();
        if(linha == -1){
            JOptionPane.showMessageDialog(this, "Selecione um Veiculo.");
            return;
        }
        
        int posicao = cbCliente.getSelectedIndex();

            if (posicao == -1 || posicao >= idClientes.size()) {
                JOptionPane.showMessageDialog(this,
                    "Selecione um cliente!");
            return;
        }


        
        int id = Integer.parseInt(tblVeiculos.getValueAt(linha, 0).toString());
        int idCliente = idClientes.get(posicao);
        String placa = txtPlaca.getText().trim();
        String marca = txtMarca.getText().trim();
        String modelo = txtModelo.getText().trim();
        String cor = txtCor.getText().trim();
        String obs = txtObs.getText().trim();
        Boolean ativo = chkAtivo.isSelected();
        
        int ano;

            try {
                ano = Integer.parseInt(txtAno.getText().trim());

                     if (ano < 1900 || ano > 2100) {
                              JOptionPane.showMessageDialog(this,
                                "O ano deve estar entre 1900 e 2100!");
                     return;
                 }

                } catch (NumberFormatException erro) {
                         JOptionPane.showMessageDialog(this,
                                   "Informe um ano válido!");
                            return;
            }
        
        int confirmacao = JOptionPane.showConfirmDialog(this,
                                                        "Deseja realmente alterar os dados deste Veiculo?",
                                                        "Confirmar alteração",
                                                        JOptionPane.YES_NO_OPTION);
        
        if(confirmacao != JOptionPane.YES_OPTION) return;
        
        String sql = """
                     UPDATE veiculo
                     SET cliente_id = ?,
                     placa = ?,
                     marca = ?,
                     modelo = ?,
                     ano = ?,
                     cor = ?,
                     observacao = ?,
                     ativo = ?
                     WHERE id = ?
                     """;
        
        try(Connection conex = Conexao.conectar();
            PreparedStatement stmt = conex.prepareStatement(sql)){
                
                stmt.setInt(1, idCliente);
                stmt.setString(2, placa);
                stmt.setString(3, marca);
                stmt.setString(4, modelo);
                stmt.setInt(5, ano);
                stmt.setString(6, cor);
                stmt.setString(7, obs);
                stmt.setBoolean(8, ativo);
                stmt.setInt(9, id);
                
            int linhasAlteradas = stmt.executeUpdate();
            
                if(linhasAlteradas > 0){
                    JOptionPane.showMessageDialog(this,
                                                  "Veiculo alterado com sucesso");
                    atualizarTabela();
                }else{
                    JOptionPane.showMessageDialog(this,
                                                  "veiculo não encontrado");
                }
                
        }catch(SQLException erro){
            JOptionPane.showMessageDialog(this,
                                          "Erro ao alterar veiculo: " +erro.getMessage());
        }
        
    }//GEN-LAST:event_btnAlterarActionPerformed

    private void tblVeiculosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblVeiculosMouseClicked
        
        
       int linha = tblVeiculos.getSelectedRow();
    if (linha == -1) return;

    txtID.setText(String.valueOf(
        tblVeiculos.getValueAt(linha, 0)
    ));

    String nomeCliente = String.valueOf(
        tblVeiculos.getValueAt(linha, 1)
    );
    cbCliente.setSelectedItem(nomeCliente);

    txtPlaca.setText(String.valueOf(
        tblVeiculos.getValueAt(linha, 2)
    ));
    txtMarca.setText(String.valueOf(
        tblVeiculos.getValueAt(linha, 3)
    ));
    txtModelo.setText(String.valueOf(
        tblVeiculos.getValueAt(linha, 4)
    ));
    txtAno.setText(String.valueOf(
        tblVeiculos.getValueAt(linha, 5)
    ));
    txtCor.setText(String.valueOf(
        tblVeiculos.getValueAt(linha, 6)
    ));

    Object observacao = tblVeiculos.getValueAt(linha, 7);
    txtObs.setText(
        observacao == null ? "" : observacao.toString()
    );

    boolean ativo = Boolean.TRUE.equals(
        tblVeiculos.getValueAt(linha, 8)
    );

    chkAtivo.setSelected(ativo);

    if (switchAtivo != null) {
        switchAtivo.setSelected(ativo);
    }

    if (lblSituacao != null) {
        lblSituacao.setText(
            ativo ? "Veículo ativo" : "Veículo inativo"
        );
    }
        
    }//GEN-LAST:event_tblVeiculosMouseClicked

    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        Estilo.configurarTema();
        java.awt.EventQueue.invokeLater(() -> new FrmConsultaVeiculo().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAlterar;
    private javax.swing.JButton btnAtualizar;
    private javax.swing.JButton btnExcluir;
    private javax.swing.JButton btnFechar;
    private javax.swing.JButton btnLocalizar;
    private javax.swing.JComboBox<String> cbCliente;
    private javax.swing.JComboBox<String> cbPesquisarPor;
    private javax.swing.JCheckBox chkAtivo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable tblVeiculos;
    private javax.swing.JTextField txtAno;
    private javax.swing.JTextField txtCor;
    private javax.swing.JTextField txtID;
    private javax.swing.JTextField txtMarca;
    private javax.swing.JTextField txtModelo;
    private javax.swing.JTextArea txtObs;
    private javax.swing.JTextField txtPesquisar;
    private javax.swing.JTextField txtPlaca;
    // End of variables declaration//GEN-END:variables
}
