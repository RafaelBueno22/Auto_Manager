package view;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import util.Estilo;
import util.Mensagem;

public class FrmRelatorioVeiculos extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(FrmRelatorioVeiculos.class.getName());

    private void carregarFiltros(){
        
        cbCliente.removeAllItems();
        cbMarca.removeAllItems();
        
        cbCliente.addItem("Todos");
        cbMarca.addItem("Todos");
        
        String sqlClientes = """
                     SELECT DISTINCT c.nome
                     FROM cliente c
                     JOIN veiculo v ON v.cliente_id = c.id
                     ORDER BY c.nome
                     """;
        
        String sqlMarcas = """
                           SELECT DISTINCT marca
                           FROM veiculo
                           ORDER BY marca
                           """;
        
        try(Connection conex = Conexao.conectar()){
            
            try(PreparedStatement stmt = conex.prepareStatement(sqlClientes);
                ResultSet rs = stmt.executeQuery()){
                
                while(rs.next()){
                    cbCliente.addItem(rs.getString("nome"));
                }
            }
            try(PreparedStatement stmt = conex.prepareStatement(sqlMarcas);
                ResultSet rs = stmt.executeQuery()){
                
                while(rs.next()){
                cbMarca.addItem(rs.getString("marca"));
            }
           
            }     
        }catch(SQLException erro){
            JOptionPane.showMessageDialog(this, "Erro ao carregar filtros: " +erro.getMessage());
        }
    }
    
    public FrmRelatorioVeiculos() {
        initComponents();
        
        tblVeiculos.setModel(new DefaultTableModel(
        new Object[][] {},
        new String[]{
            "ID", "Placa", "Cliente", "Marca",
            "Modelo", "Ano", "Cor", "Situação"
        }
    ) {
        @Override
        public boolean isCellEditable(int linha, int coluna) {
            return false;
        }
    });

    carregarFiltros();
    criarInterface();
    btnRelatorio.doClick();
    }
    
    
private void criarInterface() {

    setTitle("AutoManager | Relatório de Veículos");
    setSize(1350, 900);
    setResizable(false);
    setLocationRelativeTo(null);

    Estilo.configurarIcone(this);

    JPanel principal = new JPanel(new BorderLayout(0, 14));
    principal.setBackground(Estilo.FUNDO);
    principal.setBorder(new EmptyBorder(22, 32, 22, 32));

    // CABEÇALHO
    JPanel cabecalho = new JPanel(new BorderLayout());
    cabecalho.setOpaque(false);

    cabecalho.add(
        new JLabel(Estilo.carregarLogo(280, 94)),
        BorderLayout.WEST
    );

    JLabel secao = new JLabel("RELATÓRIOS / VEÍCULOS");
    secao.setForeground(Estilo.LARANJA);
    secao.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 15));
    cabecalho.add(secao, BorderLayout.EAST);

    JPanel topo = new JPanel(new BorderLayout(0, 12));
    topo.setOpaque(false);
    topo.add(cabecalho, BorderLayout.CENTER);

    JPanel divisor = new JPanel();
    divisor.setBackground(Estilo.LARANJA);
    divisor.setPreferredSize(new Dimension(0, 2));
    topo.add(divisor, BorderLayout.SOUTH);

    principal.add(topo, BorderLayout.NORTH);

    // CONTEÚDO
    JPanel conteudo = new JPanel(new BorderLayout(0, 14));
    conteudo.setOpaque(false);

    JPanel superior = new JPanel();
    superior.setOpaque(false);
    superior.setLayout(
        new BoxLayout(superior, BoxLayout.Y_AXIS)
    );

    JLabel titulo = new JLabel("Relatório de Veículos");
    titulo.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 27));
    titulo.setForeground(Estilo.TEXTO);
    titulo.setAlignmentX(Component.LEFT_ALIGNMENT);

    JLabel subtitulo = new JLabel(
        "CONSULTE OS VEÍCULOS CADASTRADOS NO SISTEMA"
    );
    subtitulo.setForeground(Estilo.TEXTO_SECUNDARIO);
    subtitulo.setAlignmentX(Component.LEFT_ALIGNMENT);

    superior.add(titulo);
    superior.add(Box.createVerticalStrut(6));
    superior.add(subtitulo);
    superior.add(Box.createVerticalStrut(18));

    // FILTROS
    JPanel cardFiltro = criarCardRelatorioVeiculo();

    Estilo.configurarCombo(cbCliente);
    Estilo.configurarCombo(cbMarca);
    Estilo.configurarCombo(cbSituacao);

    cbCliente.setBorder(
        UIManager.getBorder("ComboBox.border")
    );
    cbMarca.setBorder(
        UIManager.getBorder("ComboBox.border")
    );
    cbSituacao.setBorder(
        UIManager.getBorder("ComboBox.border")
    );

    cbSituacao.setModel(new DefaultComboBoxModel<>(
        new String[]{"Todos", "Ativos", "Inativos"}
    ));

    JPanel filtros = new JPanel(
        new GridLayout(1, 3, 16, 0)
    );
    filtros.setOpaque(false);

    filtros.add(campoFiltroVeiculo("Cliente", cbCliente));
    filtros.add(campoFiltroVeiculo("Marca", cbMarca));
    filtros.add(campoFiltroVeiculo("Situação", cbSituacao));

    Estilo.configurarBotao(btnRelatorio, "laranja");
    btnRelatorio.setText("GERAR RELATÓRIO");
    btnRelatorio.setPreferredSize(new Dimension(190, 44));

    JPanel painelBotao = new JPanel(
        new FlowLayout(FlowLayout.RIGHT, 0, 0)
    );
    painelBotao.setOpaque(false);
    painelBotao.add(btnRelatorio);

    JPanel corpoFiltro = new JPanel(new BorderLayout(18, 0));
    corpoFiltro.setOpaque(false);
    corpoFiltro.add(filtros, BorderLayout.CENTER);
    corpoFiltro.add(painelBotao, BorderLayout.EAST);

    cardFiltro.add(corpoFiltro, BorderLayout.CENTER);
    cardFiltro.setPreferredSize(new Dimension(0, 100));
    cardFiltro.setMaximumSize(
        new Dimension(Integer.MAX_VALUE, 100)
    );

    superior.add(cardFiltro);
    conteudo.add(superior, BorderLayout.NORTH);

    // TABELA
    JPanel cardTabela = criarCardRelatorioVeiculo();

    Estilo.configurarTabela(tblVeiculos);
    tblVeiculos.setRowHeight(42);
    tblVeiculos.setShowVerticalLines(false);
    tblVeiculos.setShowHorizontalLines(false);
    tblVeiculos.setFillsViewportHeight(true);
    tblVeiculos.setAutoCreateRowSorter(true);
    tblVeiculos.setSelectionMode(
        ListSelectionModel.SINGLE_SELECTION
    );

    tblVeiculos.getTableHeader().setReorderingAllowed(false);
    tblVeiculos.getTableHeader().setPreferredSize(
        new Dimension(0, 44)
    );

    RenderizadorVeiculosRelatorio renderizador =
        new RenderizadorVeiculosRelatorio();

    tblVeiculos.setDefaultRenderer(Object.class, renderizador);
    tblVeiculos.setDefaultRenderer(String.class, renderizador);
    tblVeiculos.setDefaultRenderer(Integer.class, renderizador);

    tblVeiculos.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

    int[] larguras = {
        65, 130, 240, 180,
        230, 100, 140, 120
    };

    for (int i = 0; i < larguras.length; i++) {
        tblVeiculos.getColumnModel()
            .getColumn(i).setPreferredWidth(larguras[i]);
    }

    jScrollPane1.setBorder(null);
    jScrollPane1.getViewport().setBackground(Estilo.PAINEL);
    jScrollPane1.setHorizontalScrollBarPolicy(
        JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED
    );

    cardTabela.add(jScrollPane1, BorderLayout.CENTER);
    cardTabela.setMinimumSize(new Dimension(0, 350));

    conteudo.add(cardTabela, BorderLayout.CENTER);

    // INDICADOR
    JPanel painelIndicadores = new JPanel(
        new GridLayout(1, 3, 18, 0)
    );
    painelIndicadores.setOpaque(false);

    painelIndicadores.add(criarIndicadorVeiculo(
        "TOTAL DE VEÍCULOS", txtTotal, Estilo.LARANJA
    ));

    // Mantém o indicador alinhado à esquerda
    JPanel vazio1 = new JPanel();
    vazio1.setOpaque(false);
    JPanel vazio2 = new JPanel();
    vazio2.setOpaque(false);

    painelIndicadores.add(vazio1);
    painelIndicadores.add(vazio2);

    painelIndicadores.setPreferredSize(
        new Dimension(0, 100)
    );

    conteudo.add(painelIndicadores, BorderLayout.SOUTH);
    principal.add(conteudo, BorderLayout.CENTER);

    // RODAPÉ
    JPanel rodape = new JPanel(
        new FlowLayout(FlowLayout.RIGHT, 0, 0)
    );
    rodape.setOpaque(false);

    Estilo.configurarBotao(btnFechar, "cinza");
    btnFechar.setText("FECHAR");
    btnFechar.setPreferredSize(new Dimension(160, 44));

    rodape.add(btnFechar);
    principal.add(rodape, BorderLayout.SOUTH);

    setContentPane(principal);
    revalidate();
    repaint();
}

// CARD PADRÃO
private JPanel criarCardRelatorioVeiculo() {
    JPanel painel = new JPanel(new BorderLayout());
    painel.setBackground(Estilo.PAINEL);
    painel.setBorder(new EmptyBorder(18, 20, 18, 20));
    painel.setAlignmentX(Component.LEFT_ALIGNMENT);
    return painel;
}

// FILTRO COM TÍTULO
private JPanel campoFiltroVeiculo(
        String titulo, JComponent componente) {

    JPanel painel = new JPanel(new BorderLayout(0, 8));
    painel.setOpaque(false);

    JLabel label = new JLabel(titulo);
    label.setForeground(Estilo.TEXTO);
    label.setFont(Estilo.FONTE_PADRAO);

    painel.add(label, BorderLayout.NORTH);
    painel.add(componente, BorderLayout.CENTER);

    return painel;
}

// INDICADOR
private JPanel criarIndicadorVeiculo(
        String titulo, JTextField campo, Color cor) {

    JPanel painel = criarCardRelatorioVeiculo();

    JPanel detalhe = new JPanel();
    detalhe.setBackground(cor);
    detalhe.setPreferredSize(new Dimension(4, 0));
    painel.add(detalhe, BorderLayout.WEST);

    JLabel label = new JLabel(titulo);
    label.setForeground(Estilo.TEXTO_SECUNDARIO);
    label.setFont(
        new Font(Font.SANS_SERIF, Font.BOLD, 13)
    );
    label.setAlignmentX(Component.LEFT_ALIGNMENT);

    campo.setEditable(false);
    campo.setFocusable(false);
    campo.setHorizontalAlignment(JTextField.LEFT);
    campo.setFont(
        new Font(Font.SANS_SERIF, Font.BOLD, 34)
    );
    campo.setForeground(Estilo.TEXTO);
    campo.setBackground(Estilo.PAINEL);
    campo.setBorder(null);
    campo.setAlignmentX(Component.LEFT_ALIGNMENT);

    campo.setPreferredSize(new Dimension(150, 42));
    campo.setMaximumSize(
        new Dimension(Integer.MAX_VALUE, 42)
    );

    JPanel informacoes = new JPanel();
    informacoes.setOpaque(false);
    informacoes.setLayout(
        new BoxLayout(informacoes, BoxLayout.Y_AXIS)
    );

    informacoes.add(label);
    informacoes.add(Box.createVerticalStrut(5));
    informacoes.add(campo);

    JPanel margem = new JPanel(new BorderLayout());
    margem.setOpaque(false);
    margem.setBorder(
        new EmptyBorder(0, 16, 0, 0)
    );

    margem.add(informacoes, BorderLayout.CENTER);
    painel.add(margem, BorderLayout.CENTER);

    return painel;
}

// RENDERIZADOR DA TABELA
private class RenderizadorVeiculosRelatorio
        extends DefaultTableCellRenderer {

    @Override
    public Component getTableCellRendererComponent(
            JTable tabela, Object valor,
            boolean selecionado, boolean foco,
            int linha, int coluna) {

        super.getTableCellRendererComponent(
            tabela,
            valor == null ? "" : valor,
            selecionado, foco, linha, coluna
        );

        setBorder(new EmptyBorder(0, 12, 0, 12));

        if (selecionado) {
            setBackground(new Color(124, 62, 29));
            setForeground(Color.WHITE);
        } else {
            setBackground(
                linha % 2 == 0
                    ? Estilo.PAINEL
                    : new Color(40, 46, 57)
            );

            if (coluna == 7 && valor != null) {
                setForeground(
                    "Ativo".equals(valor.toString())
                        ? Estilo.VERDE
                        : Estilo.VERMELHO
                );
            } else {
                setForeground(Estilo.TEXTO);
            }
        }

        return this;
    }
}


  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tblVeiculos = new javax.swing.JTable();
        txtTotal = new javax.swing.JTextField();
        btnFechar = new javax.swing.JButton();
        cbSituacao = new javax.swing.JComboBox<>();
        btnRelatorio = new javax.swing.JButton();
        cbCliente = new javax.swing.JComboBox<>();
        cbMarca = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        tblVeiculos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Placa", "Cliente", "Marca", "Modelo", "Ano", "Cor", "Situação"
            }
        ));
        jScrollPane1.setViewportView(tblVeiculos);

        txtTotal.setEditable(false);
        txtTotal.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        txtTotal.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtTotal.setBorder(javax.swing.BorderFactory.createTitledBorder("Total de veiculos"));

        btnFechar.setText("Fechar");
        btnFechar.addActionListener(this::btnFecharActionPerformed);

        cbSituacao.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Todos", "Ativos", "Inativos" }));
        cbSituacao.setBorder(javax.swing.BorderFactory.createTitledBorder("Situacao"));

        btnRelatorio.setText("Gerar Relatorio");
        btnRelatorio.addActionListener(this::btnRelatorioActionPerformed);

        cbCliente.setBorder(javax.swing.BorderFactory.createTitledBorder("Cliente"));

        cbMarca.setBorder(javax.swing.BorderFactory.createTitledBorder("Marca"));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 783, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnFechar, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(47, 47, 47)
                .addComponent(txtTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(cbSituacao, javax.swing.GroupLayout.Alignment.LEADING, 0, 400, Short.MAX_VALUE)
                    .addComponent(cbCliente, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(cbMarca, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnRelatorio, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(71, 71, 71))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(cbMarca)
                    .addComponent(cbCliente, javax.swing.GroupLayout.DEFAULT_SIZE, 49, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(cbSituacao, javax.swing.GroupLayout.DEFAULT_SIZE, 49, Short.MAX_VALUE)
                    .addComponent(btnRelatorio, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 225, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(txtTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 29, Short.MAX_VALUE)
                .addComponent(btnFechar, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnRelatorioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRelatorioActionPerformed
        String cliente = cbCliente.getSelectedItem().toString();
        String marca = cbMarca.getSelectedItem().toString();
        String situacao = cbSituacao.getSelectedItem().toString();
        
        String sql = """
                     SELECT v.id, v.placa, c.nome AS cliente,
                            v.marca, v.modelo, v.ano, v.cor, v.ativo
                     FROM veiculo v
                     JOIN cliente c ON v.cliente_id = c.id
                     WHERE 1 = 1
                     """;
        
        if(!cliente.equals("Todos")){
            sql += " AND c.nome = ?";
        }
        
        if(!marca.equals("Todos")){
            sql += " AND v.marca = ?";
        }
        
        if(situacao.equals("Ativos")){
            sql += " AND v.ativo = TRUE";
        }else if(situacao.equals("Inativos")){
            sql += " AND v.ativo = FALSE";
        }
        
        sql += " ORDER BY v.id";
        
        DefaultTableModel modelo = (DefaultTableModel) tblVeiculos.getModel();
        
        try(Connection conex = Conexao.conectar();
            PreparedStatement stmt = conex.prepareStatement(sql)){
            
            int parametro = 1;
            
            if(!cliente.equals("Todos")){
                
                stmt.setString(parametro, cliente);
                parametro++;
            }
            if(!marca.equals("Todos")){
                stmt.setString(parametro, marca);
                parametro++;
            }
            
            try(ResultSet rs = stmt.executeQuery()){
                
                modelo.setRowCount(0);
                
                while (rs.next()){
                    
                    modelo.addRow(new Object []{
                        rs.getInt("id"), rs.getString("placa"),
                        rs.getString("cliente"), rs.getString("marca"),
                        rs.getString("modelo"), rs.getInt("ano"),
                        rs.getString("cor"), rs.getBoolean("ativo") ? "Ativo" : "Inativo"
                    });
                }
            }
            txtTotal.setText(String.valueOf(modelo.getRowCount()));
        }catch(SQLException erro){
            JOptionPane.showMessageDialog(this, "Erro ao gerar o relatorio: " +erro.getMessage());
        }
    }//GEN-LAST:event_btnRelatorioActionPerformed

    private void btnFecharActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFecharActionPerformed
        dispose();
    }//GEN-LAST:event_btnFecharActionPerformed

    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        Estilo.configurarTema();
        java.awt.EventQueue.invokeLater(() -> new FrmRelatorioVeiculos().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnFechar;
    private javax.swing.JButton btnRelatorio;
    private javax.swing.JComboBox<String> cbCliente;
    private javax.swing.JComboBox<String> cbMarca;
    private javax.swing.JComboBox<String> cbSituacao;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblVeiculos;
    private javax.swing.JTextField txtTotal;
    // End of variables declaration//GEN-END:variables
}
