package view;
import conexao.Conexao;
import java.math.BigDecimal;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import util.Estilo;
import util.Mensagem;
import util.SwitchAtivo;
import util.BordaArredondada;


public class FrmCadastroServico extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(FrmCadastroServico.class.getName());

    private void limparCampos(){
        txtDescricao.setText("");
        txtCategoria.setText("");
        txtValorBase.setText("");
        txtTempoEstimado.setText("");
        txtObservacao.setText("");
        chkAtivo.setSelected(true);
        if (switchAtivo != null) {
        switchAtivo.setSelected(true);
    }
        txtDescricao.requestFocus();
    }
    public FrmCadastroServico() {
        initComponents();
        criarInterface();
    }

    
private SwitchAtivo switchAtivo;

private void criarInterface() {

    setTitle("AutoManager | Cadastro de Serviços");
    setSize(1050, 720);
    setResizable(false);
    setLocationRelativeTo(null);

    Estilo.configurarIcone(this);

    JPanel principal = new JPanel(new BorderLayout(0, 18));
    principal.setBackground(Estilo.FUNDO);
    principal.setBorder(new EmptyBorder(24, 35, 24, 35));

    // CABEÇALHO
    JPanel cabecalho = new JPanel(new BorderLayout());
    cabecalho.setOpaque(false);

    JLabel logo = new JLabel(Estilo.carregarLogo(280, 94));
    cabecalho.add(logo, BorderLayout.WEST);

    JLabel secao = new JLabel("SERVIÇOS / 04");
    secao.setForeground(Estilo.LARANJA);
    secao.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 15));
    cabecalho.add(secao, BorderLayout.EAST);

    JPanel topo = new JPanel(new BorderLayout(0, 12));
    topo.setOpaque(false);
    topo.add(cabecalho, BorderLayout.CENTER);

    JPanel linha = new JPanel();
    linha.setBackground(Estilo.LARANJA);
    linha.setPreferredSize(new Dimension(0, 2));
    topo.add(linha, BorderLayout.SOUTH);

    principal.add(topo, BorderLayout.NORTH);

    // ÁREA CENTRAL
    JPanel centro = new JPanel();
    centro.setOpaque(false);
    centro.setLayout(new BoxLayout(centro, BoxLayout.Y_AXIS));

    JLabel titulo = new JLabel("Cadastro de Serviços");
    titulo.setForeground(Estilo.TEXTO);
    titulo.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 27));
    titulo.setAlignmentX(Component.LEFT_ALIGNMENT);

    JLabel subtitulo = new JLabel(
        "CADASTRO E GERENCIAMENTO DE SERVIÇOS"
    );
    subtitulo.setForeground(Estilo.TEXTO_SECUNDARIO);
    subtitulo.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));
    subtitulo.setAlignmentX(Component.LEFT_ALIGNMENT);

    centro.add(titulo);
    centro.add(Box.createVerticalStrut(5));
    centro.add(subtitulo);
    centro.add(Box.createVerticalStrut(20));

    // CARD PRINCIPAL
    JPanel card = new JPanel(new BorderLayout(0, 16));
    card.setBackground(Estilo.PAINEL);
    card.setBorder(new EmptyBorder(20, 22, 20, 22));
    card.setAlignmentX(Component.LEFT_ALIGNMENT);

    JPanel cabecalhoCard = new JPanel(
        new FlowLayout(FlowLayout.LEFT, 10, 0)
    );
    cabecalhoCard.setOpaque(false);

    JPanel barra = new JPanel();
    barra.setBackground(Estilo.LARANJA);
    barra.setPreferredSize(new Dimension(4, 18));

    JLabel tituloCard = new JLabel("INFORMAÇÕES DO SERVIÇO");
    tituloCard.setForeground(Estilo.TEXTO);
    tituloCard.setFont(
        new Font(Font.SANS_SERIF, Font.BOLD, 13)
    );

    cabecalhoCard.add(barra);
    cabecalhoCard.add(tituloCard);
    card.add(cabecalhoCard, BorderLayout.NORTH);

    // CAMPOS
    JPanel campos = new JPanel(new GridBagLayout());
    campos.setOpaque(false);

    JTextField[] camposTexto = {
        txtId,
        txtDescricao,
        txtCategoria,
        txtValorBase,
        txtTempoEstimado
    };

    for (JTextField campo : camposTexto) {
        Estilo.configurarCampo(campo);

        if (campo != txtId) {
            Estilo.configurarFoco(campo);
        }
    }

    txtId.setEditable(false);
    txtId.setFocusable(false);
    txtId.setText("");
    txtId.setBackground(new Color(35, 40, 49));
    txtId.setForeground(Estilo.TEXTO_SECUNDARIO);

    txtId.putClientProperty(
        "JTextField.placeholderText",
        "Gerado automaticamente"
    );

    txtDescricao.putClientProperty(
        "JTextField.placeholderText",
        "Ex.: Troca de óleo"
    );

    txtCategoria.putClientProperty(
        "JTextField.placeholderText",
        "Ex.: Manutenção preventiva"
    );

    txtValorBase.putClientProperty(
        "JTextField.placeholderText",
        "Ex.: 150,00"
    );

    txtTempoEstimado.putClientProperty(
        "JTextField.placeholderText",
        "Ex.: 1,5"
    );

    adicionarCampo(campos, "ID", txtId, 0, 0);
    adicionarCampo(campos, "Descrição", txtDescricao, 1, 0);
    adicionarCampo(campos, "Categoria", txtCategoria, 0, 1);
    adicionarCampo(campos, "Valor base (R$)", txtValorBase, 1, 1);
    adicionarCampo(
        campos,
        "Tempo estimado (horas)",
        txtTempoEstimado,
        0, 2
    );

    JPanel conteudoCard = new JPanel(new BorderLayout(0, 15));
    conteudoCard.setOpaque(false);
    conteudoCard.add(campos, BorderLayout.NORTH);

    // OBSERVAÇÕES
    JPanel areaObservacao = new JPanel(new BorderLayout(0, 6));
    areaObservacao.setOpaque(false);

    JLabel lblObservacao = new JLabel("Observações");
    lblObservacao.setForeground(Estilo.TEXTO);

    Estilo.configurarArea(txtObservacao);

    txtObservacao.setBorder(
        BorderFactory.createEmptyBorder(10, 14, 10, 14)
    );

    jScrollPane1.setBorder(
        new BordaArredondada(Estilo.BORDA, 18)
    );

    jScrollPane1.setBackground(Estilo.COMPONENTE);
    jScrollPane1.getViewport().setBackground(Estilo.COMPONENTE);
    jScrollPane1.setPreferredSize(new Dimension(0, 85));

    jScrollPane1.setVerticalScrollBarPolicy(
        JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED
    );

    txtObservacao.addFocusListener(
        new java.awt.event.FocusAdapter() {

            @Override
            public void focusGained(java.awt.event.FocusEvent e) {
                jScrollPane1.setBorder(
                    new BordaArredondada(Estilo.LARANJA, 18)
                );
            }

            @Override
            public void focusLost(java.awt.event.FocusEvent e) {
                jScrollPane1.setBorder(
                    new BordaArredondada(Estilo.BORDA, 18)
                );
            }
        }
    );

    areaObservacao.add(lblObservacao, BorderLayout.NORTH);
    areaObservacao.add(jScrollPane1, BorderLayout.CENTER);

    conteudoCard.add(areaObservacao, BorderLayout.CENTER);

    // INTERRUPTOR ATIVO
    switchAtivo = new SwitchAtivo();
    switchAtivo.setSelected(chkAtivo.isSelected());

    switchAtivo.addActionListener(e ->
        chkAtivo.setSelected(switchAtivo.isSelected())
    );

    JPanel situacao = new JPanel(
        new FlowLayout(FlowLayout.LEFT, 10, 0)
    );
    situacao.setOpaque(false);

    JLabel lblAtivo = new JLabel("Serviço ativo");
    lblAtivo.setForeground(Estilo.TEXTO);

    situacao.add(switchAtivo);
    situacao.add(lblAtivo);

    conteudoCard.add(situacao, BorderLayout.SOUTH);

    card.add(conteudoCard, BorderLayout.CENTER);
    centro.add(card);

    // ROLAGEM CENTRAL
    JScrollPane scrollCentral = new JScrollPane(centro);
    scrollCentral.setBorder(null);
    scrollCentral.setOpaque(false);
    scrollCentral.getViewport().setOpaque(false);

    scrollCentral.setHorizontalScrollBarPolicy(
        JScrollPane.HORIZONTAL_SCROLLBAR_NEVER
    );

    scrollCentral.setVerticalScrollBarPolicy(
        JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED
    );

    scrollCentral.getVerticalScrollBar().setUnitIncrement(16);

    principal.add(scrollCentral, BorderLayout.CENTER);

    // RODAPÉ
    JPanel rodape = new JPanel(
        new FlowLayout(FlowLayout.RIGHT, 12, 0)
    );
    rodape.setOpaque(false);

    Estilo.configurarBotao(btnLimpar, "cinza");
    Estilo.configurarBotao(btnFechar, "vermelho");
    Estilo.configurarBotao(btnCadastrar, "laranja");

    Estilo.configurarHover(
        btnLimpar, new Color(100, 116, 139)
    );
    Estilo.configurarHover(
        btnFechar, new Color(220, 38, 38)
    );
    Estilo.configurarHover(
        btnCadastrar, new Color(234, 88, 12)
    );

    btnLimpar.setText("LIMPAR");
    btnFechar.setText("FECHAR");
    btnCadastrar.setText("CADASTRAR SERVIÇO");

    btnLimpar.setPreferredSize(new Dimension(125, 42));
    btnFechar.setPreferredSize(new Dimension(125, 42));
    btnCadastrar.setPreferredSize(new Dimension(220, 42));

    rodape.add(btnLimpar);
    rodape.add(btnFechar);
    rodape.add(btnCadastrar);

    principal.add(rodape, BorderLayout.SOUTH);

    setContentPane(principal);

    SwingUtilities.invokeLater(() ->
        scrollCentral.getViewport().setViewPosition(
            new Point(0, 0)
        )
    );

    revalidate();
    repaint();
}

// ORGANIZA OS CAMPOS EM DUAS COLUNAS
private void adicionarCampo(
        JPanel painel,
        String titulo,
        JComponent campo,
        int coluna,
        int linha) {

    JPanel grupo = new JPanel(new BorderLayout(0, 6));
    grupo.setOpaque(false);

    JLabel label = new JLabel(titulo);
    label.setForeground(Estilo.TEXTO);
    label.setFont(
        new Font(Font.SANS_SERIF, Font.PLAIN, 13)
    );

    grupo.add(label, BorderLayout.NORTH);
    grupo.add(campo, BorderLayout.CENTER);

    GridBagConstraints gbc = new GridBagConstraints();
    gbc.gridx = coluna;
    gbc.gridy = linha;
    gbc.weightx = 1;
    gbc.fill = GridBagConstraints.HORIZONTAL;
    gbc.insets = new Insets(6, 7, 6, 7);

    painel.add(grupo, gbc);
}

    
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txtId = new javax.swing.JTextField();
        txtDescricao = new javax.swing.JTextField();
        txtCategoria = new javax.swing.JTextField();
        txtValorBase = new javax.swing.JTextField();
        txtTempoEstimado = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtObservacao = new javax.swing.JTextArea();
        chkAtivo = new javax.swing.JCheckBox();
        btnLimpar = new javax.swing.JButton();
        btnFechar = new javax.swing.JButton();
        btnCadastrar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        txtId.setEditable(false);
        txtId.setBorder(javax.swing.BorderFactory.createTitledBorder("ID"));

        txtDescricao.setBorder(javax.swing.BorderFactory.createTitledBorder("Descricao"));

        txtCategoria.setBorder(javax.swing.BorderFactory.createTitledBorder("Categoria"));

        txtValorBase.setBorder(javax.swing.BorderFactory.createTitledBorder("Valor Base"));

        txtTempoEstimado.setBorder(javax.swing.BorderFactory.createTitledBorder("Tempo Estimado"));

        txtObservacao.setColumns(20);
        txtObservacao.setRows(5);
        txtObservacao.setBorder(javax.swing.BorderFactory.createTitledBorder("Observacao"));
        jScrollPane1.setViewportView(txtObservacao);

        chkAtivo.setSelected(true);
        chkAtivo.setText("Ativo");

        btnLimpar.setBackground(new java.awt.Color(204, 204, 0));
        btnLimpar.setText("Limpar");
        btnLimpar.addActionListener(this::btnLimparActionPerformed);

        btnFechar.setBackground(new java.awt.Color(102, 0, 0));
        btnFechar.setText("Fechar");
        btnFechar.addActionListener(this::btnFecharActionPerformed);

        btnCadastrar.setBackground(new java.awt.Color(0, 102, 0));
        btnCadastrar.setText("Cadastrar");
        btnCadastrar.addActionListener(this::btnCadastrarActionPerformed);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(txtTempoEstimado, javax.swing.GroupLayout.DEFAULT_SIZE, 173, Short.MAX_VALUE)
                            .addComponent(txtValorBase)
                            .addComponent(txtCategoria)
                            .addComponent(txtDescricao)
                            .addComponent(txtId))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(157, 157, 157))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(chkAtivo)
                                .addGap(189, 189, 189)
                                .addComponent(btnFechar)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnLimpar)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnCadastrar)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(txtId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(txtDescricao, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(txtCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(txtValorBase, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(txtTempoEstimado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 28, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(chkAtivo)
                    .addComponent(btnCadastrar)
                    .addComponent(btnLimpar)
                    .addComponent(btnFechar))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnLimparActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimparActionPerformed
        limparCampos();
    }//GEN-LAST:event_btnLimparActionPerformed

    private void btnFecharActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFecharActionPerformed
        dispose();
    }//GEN-LAST:event_btnFecharActionPerformed

    private void btnCadastrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCadastrarActionPerformed
        String descricao = txtDescricao.getText().trim();
        String categoria = txtCategoria.getText().trim();
        String observacao = txtObservacao.getText().trim();
        boolean ativo = chkAtivo.isSelected();

    if (descricao.isEmpty() || categoria.isBlank()) {
        Mensagem.aviso(this, "Descrição e categoria são obrigatórias!");
        return;
    }
    
    BigDecimal valorBase;
    BigDecimal tempoEstimado = null;
    
    try {
        valorBase = new BigDecimal(
                txtValorBase.getText().trim().replace(",", ".")
        );

        if (valorBase.compareTo(BigDecimal.ZERO) < 0) {
            Mensagem.aviso(this, "O valor não pode ser negativo!");
            return;
        }

        String tempoTexto = txtTempoEstimado.getText().trim();

        if (!tempoTexto.isEmpty()) {
            tempoEstimado = new BigDecimal(
                    tempoTexto.replace(",", ".")
            );

            if (tempoEstimado.compareTo(BigDecimal.ZERO) <= 0) {
                Mensagem.aviso(this, "O tempo deve ser maior que zero!");
                return;
            }
        }

    } catch (NumberFormatException erro) {
        Mensagem.aviso(this, "Informe valores numéricos válidos!");
        return;
    }
    
        String sqlInsert = """
                           INSERT INTO servico
                           (descricao,categoria,valor_base,tempo_estimado_horas,observacao,ativo)
                           VALUES (?,?,?,?,?,?)
                           """;
        
        try {
            Connection conex = Conexao.conectar();
            PreparedStatement stmt = conex.prepareStatement(sqlInsert);
            
            stmt.setString(1, descricao);
            stmt.setString(2, categoria);
            stmt.setBigDecimal(3, valorBase);
            
            if (tempoEstimado == null) {
            stmt.setNull(4, java.sql.Types.NUMERIC);
        } else {
            stmt.setBigDecimal(4, tempoEstimado);
        }
            
            stmt.setString(5, observacao);
            stmt.setBoolean(6, ativo);
            
            int linhas = stmt.executeUpdate();
            if(linhas >0){
            Mensagem.sucesso(this, "Serviço cadastrado com sucesso!");
            limparCampos();
            }
                    
                   
        } catch (SQLException erro) {
            
            Mensagem.erro(
    this,
    "Não foi possível cadastrar o serviço: "
        + erro.getMessage()
);
        }       

        

    }//GEN-LAST:event_btnCadastrarActionPerformed
        
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        Estilo.configurarTema();
        java.awt.EventQueue.invokeLater(() -> new FrmCadastroServico().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCadastrar;
    private javax.swing.JButton btnFechar;
    private javax.swing.JButton btnLimpar;
    private javax.swing.JCheckBox chkAtivo;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField txtCategoria;
    private javax.swing.JTextField txtDescricao;
    private javax.swing.JTextField txtId;
    private javax.swing.JTextArea txtObservacao;
    private javax.swing.JTextField txtTempoEstimado;
    private javax.swing.JTextField txtValorBase;
    // End of variables declaration//GEN-END:variables
}
