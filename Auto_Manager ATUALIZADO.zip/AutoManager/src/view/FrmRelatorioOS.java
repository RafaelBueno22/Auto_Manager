package view;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.math.BigDecimal;
import java.text.NumberFormat;
import java.util.Locale;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import util.Estilo;
import util.Mensagem;

public class FrmRelatorioOS extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(FrmRelatorioOS.class.getName());

        
    
    
    public FrmRelatorioOS() {
        initComponents();
        
         tblOS.setModel(new DefaultTableModel(
        new Object[][] {},
        new String[]{
            "Nº OS", "Placa", "Cliente", "Mecânico",
            "Serviço", "Data Abertura", "Status",
            "Valor Cobrado", "Data Conclusão"
        }
    ) {
        @Override
        public boolean isCellEditable(int linha, int coluna) {
            return false;
        }
    });

    criarInterface();
    btnRelatorio.doClick();
    }
    
    
    
    
    
    
private void criarInterface() {

    setTitle("AutoManager | Relatório de Ordens de Serviço");
    setSize(1350, 900);
    setResizable(false);
    setLocationRelativeTo(null);

    Estilo.configurarIcone(this);

    JPanel principal = new JPanel(new BorderLayout(0, 14));
    principal.setBackground(Estilo.FUNDO);
    principal.setBorder(new EmptyBorder(22, 32, 22, 32));

    // CABEÇALHO
    JPanel cabecalho = new JPanel(new BorderLayout());
    cabecalho.setOpaque(false);

    cabecalho.add(
        new JLabel(Estilo.carregarLogo(280, 94)),
        BorderLayout.WEST
    );

    JLabel secao = new JLabel("RELATÓRIOS / ORDENS DE SERVIÇO");
    secao.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 15));
    secao.setForeground(Estilo.LARANJA);
    cabecalho.add(secao, BorderLayout.EAST);

    JPanel topo = new JPanel(new BorderLayout(0, 12));
    topo.setOpaque(false);
    topo.add(cabecalho, BorderLayout.CENTER);

    JPanel divisor = new JPanel();
    divisor.setBackground(Estilo.LARANJA);
    divisor.setPreferredSize(new Dimension(0, 2));
    topo.add(divisor, BorderLayout.SOUTH);

    principal.add(topo, BorderLayout.NORTH);

    // CONTEÚDO
    JPanel conteudo = new JPanel(new BorderLayout(0, 14));
    conteudo.setOpaque(false);

    JPanel superior = new JPanel();
    superior.setOpaque(false);
    superior.setLayout(
        new BoxLayout(superior, BoxLayout.Y_AXIS)
    );

    JLabel titulo = new JLabel("Relatório de Ordens de Serviço");
    titulo.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 27));
    titulo.setForeground(Estilo.TEXTO);
    titulo.setAlignmentX(Component.LEFT_ALIGNMENT);

    JLabel subtitulo = new JLabel(
        "ACOMPANHE AS ORDENS DE SERVIÇO E SEUS RESULTADOS"
    );
    subtitulo.setForeground(Estilo.TEXTO_SECUNDARIO);
    subtitulo.setAlignmentX(Component.LEFT_ALIGNMENT);

    superior.add(titulo);
    superior.add(Box.createVerticalStrut(6));
    superior.add(subtitulo);
    superior.add(Box.createVerticalStrut(18));

    // FILTROS
    JPanel cardFiltro = criarCardRelatorioOS();

    Estilo.configurarCampo(txtDataInicio);
    Estilo.configurarCampo(txtDataFim);
    Estilo.configurarCombo(cbStatus);

    cbStatus.setBorder(
        UIManager.getBorder("ComboBox.border")
    );

    cbStatus.setModel(new DefaultComboBoxModel<>(
        new String[]{
            "Todos", "ABERTA", "EM_ANDAMENTO",
            "CONCLUIDA", "CANCELADA"
        }
    ));

    txtDataInicio.putClientProperty(
        "JTextField.placeholderText", "DD/MM/AAAA"
    );
    txtDataFim.putClientProperty(
        "JTextField.placeholderText", "DD/MM/AAAA"
    );

    JPanel filtros = new JPanel(
        new GridLayout(1, 3, 16, 0)
    );
    filtros.setOpaque(false);

    filtros.add(campoFiltroOS(
        "Data inicial", txtDataInicio
    ));
    filtros.add(campoFiltroOS(
        "Data final", txtDataFim
    ));
    filtros.add(campoFiltroOS(
        "Status", cbStatus
    ));

    Estilo.configurarBotao(btnRelatorio, "laranja");
    btnRelatorio.setText("GERAR RELATÓRIO");
    btnRelatorio.setPreferredSize(new Dimension(190, 44));

    JPanel botaoFiltro = new JPanel(
        new FlowLayout(FlowLayout.RIGHT, 0, 0)
    );
    botaoFiltro.setOpaque(false);
    botaoFiltro.add(btnRelatorio);

    JPanel corpoFiltro = new JPanel(new BorderLayout(18, 0));
    corpoFiltro.setOpaque(false);
    corpoFiltro.add(filtros, BorderLayout.CENTER);
    corpoFiltro.add(botaoFiltro, BorderLayout.EAST);

    cardFiltro.add(corpoFiltro, BorderLayout.CENTER);
    cardFiltro.setPreferredSize(new Dimension(0, 100));
    cardFiltro.setMaximumSize(
        new Dimension(Integer.MAX_VALUE, 100)
    );

    superior.add(cardFiltro);
    conteudo.add(superior, BorderLayout.NORTH);

    // TABELA
    JPanel cardTabela = criarCardRelatorioOS();

    Estilo.configurarTabela(tblOS);
    tblOS.setRowHeight(42);
    tblOS.setShowVerticalLines(false);
    tblOS.setShowHorizontalLines(false);
    tblOS.setFillsViewportHeight(true);
    tblOS.setAutoCreateRowSorter(true);
    tblOS.setSelectionMode(
        ListSelectionModel.SINGLE_SELECTION
    );

    tblOS.getTableHeader().setReorderingAllowed(false);
    tblOS.getTableHeader().setPreferredSize(
        new Dimension(0, 44)
    );

    RenderizadorTabelaOS renderizador =
        new RenderizadorTabelaOS();

    tblOS.setDefaultRenderer(Object.class, renderizador);
    tblOS.setDefaultRenderer(String.class, renderizador);
    tblOS.setDefaultRenderer(Integer.class, renderizador);
    tblOS.setDefaultRenderer(Timestamp.class, renderizador);
    tblOS.setDefaultRenderer(BigDecimal.class, renderizador);

    tblOS.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

    int[] larguras = {
        75, 105, 185, 170, 205,
        170, 145, 150, 175
    };

    for (int i = 0; i < larguras.length; i++) {
        tblOS.getColumnModel()
            .getColumn(i).setPreferredWidth(larguras[i]);
    }

    jScrollPane1.setBorder(null);
    jScrollPane1.getViewport().setBackground(Estilo.PAINEL);
    jScrollPane1.setHorizontalScrollBarPolicy(
        JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED
    );

    cardTabela.add(jScrollPane1, BorderLayout.CENTER);
    cardTabela.setMinimumSize(new Dimension(0, 250));

    conteudo.add(cardTabela, BorderLayout.CENTER);

    // INDICADORES: DUAS LINHAS COM TRÊS CARDS
    JPanel indicadores = new JPanel(
        new GridLayout(2, 3, 14, 12)
    );
    indicadores.setOpaque(false);

    indicadores.add(criarIndicadorOS(
        "TOTAL DE OS", txtTotal, Estilo.LARANJA
    ));

    indicadores.add(criarIndicadorOS(
        "OS ABERTAS", txtAbertas, new Color(59, 130, 246)
    ));

    indicadores.add(criarIndicadorOS(
        "EM ANDAMENTO", txtAndamento,
        new Color(251, 191, 36)
    ));

    indicadores.add(criarIndicadorOS(
        "CONCLUÍDAS", txtConcluidas, Estilo.VERDE
    ));

    indicadores.add(criarIndicadorOS(
        "CANCELADAS", txtCanceladas, Estilo.VERMELHO
    ));

    indicadores.add(criarIndicadorOS(
        "VALOR DAS CONCLUÍDAS",
        txtValorConcluidas, Estilo.LARANJA
    ));

    indicadores.setPreferredSize(new Dimension(0, 205));

    conteudo.add(indicadores, BorderLayout.SOUTH);
    principal.add(conteudo, BorderLayout.CENTER);

    // RODAPÉ
    JPanel rodape = new JPanel(
        new FlowLayout(FlowLayout.RIGHT, 0, 0)
    );
    rodape.setOpaque(false);

    Estilo.configurarBotao(btnFechar, "cinza");
    btnFechar.setText("FECHAR");
    btnFechar.setPreferredSize(new Dimension(160, 44));

    rodape.add(btnFechar);
    principal.add(rodape, BorderLayout.SOUTH);

    setContentPane(principal);
    revalidate();
    repaint();
}

// CARD
private JPanel criarCardRelatorioOS() {
    JPanel painel = new JPanel(new BorderLayout());
    painel.setBackground(Estilo.PAINEL);
    painel.setBorder(new EmptyBorder(14, 18, 14, 18));
    painel.setAlignmentX(Component.LEFT_ALIGNMENT);
    return painel;
}

// CAMPO COM TÍTULO
private JPanel campoFiltroOS(
        String titulo, JComponent componente) {

    JPanel painel = new JPanel(new BorderLayout(0, 8));
    painel.setOpaque(false);

    JLabel label = new JLabel(titulo);
    label.setFont(Estilo.FONTE_PADRAO);
    label.setForeground(Estilo.TEXTO);

    painel.add(label, BorderLayout.NORTH);
    painel.add(componente, BorderLayout.CENTER);

    return painel;
}

// INDICADOR COM NÚMERO PRÓXIMO DO TÍTULO
private JPanel criarIndicadorOS(
        String titulo, JTextField campo, Color cor) {

    JPanel painel = criarCardRelatorioOS();

    JPanel detalhe = new JPanel();
    detalhe.setBackground(cor);
    detalhe.setPreferredSize(new Dimension(4, 0));
    painel.add(detalhe, BorderLayout.WEST);

    JLabel label = new JLabel(titulo);
    label.setForeground(Estilo.TEXTO_SECUNDARIO);
    label.setFont(
        new Font(Font.SANS_SERIF, Font.BOLD, 12)
    );
    label.setAlignmentX(Component.LEFT_ALIGNMENT);

    campo.setEditable(false);
    campo.setFocusable(false);
    campo.setHorizontalAlignment(JTextField.LEFT);
    campo.setFont(
        new Font(Font.SANS_SERIF, Font.BOLD, 27)
    );
    campo.setForeground(Estilo.TEXTO);
    campo.setBackground(Estilo.PAINEL);
    campo.setBorder(null);
    campo.setAlignmentX(Component.LEFT_ALIGNMENT);

    campo.setPreferredSize(new Dimension(140, 35));
    campo.setMaximumSize(
        new Dimension(Integer.MAX_VALUE, 35)
    );

    JPanel informacoes = new JPanel();
    informacoes.setOpaque(false);
    informacoes.setLayout(
        new BoxLayout(informacoes, BoxLayout.Y_AXIS)
    );

    informacoes.add(label);
    informacoes.add(Box.createVerticalStrut(3));
    informacoes.add(campo);

    JPanel margem = new JPanel(new BorderLayout());
    margem.setOpaque(false);
    margem.setBorder(new EmptyBorder(0, 14, 0, 0));
    margem.add(informacoes, BorderLayout.CENTER);

    painel.add(margem, BorderLayout.CENTER);

    return painel;
}

// RENDERIZADOR DA TABELA
private class RenderizadorTabelaOS
        extends DefaultTableCellRenderer {

    private final NumberFormat moeda =
        NumberFormat.getCurrencyInstance(
            Locale.forLanguageTag("pt-BR")
        );

    private final DateTimeFormatter formatoData =
        DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    @Override
    public Component getTableCellRendererComponent(
            JTable tabela, Object valor,
            boolean selecionado, boolean foco,
            int linha, int coluna) {

        Object exibicao = valor;

        if (valor instanceof Timestamp data) {
            exibicao = data.toLocalDateTime()
                .format(formatoData);
        } else if (valor instanceof BigDecimal numero) {
            exibicao = moeda.format(numero);
        } else if (valor == null) {
            exibicao = "";
        }

        super.getTableCellRendererComponent(
            tabela, exibicao, selecionado,
            foco, linha, coluna
        );

        setBorder(new EmptyBorder(0, 12, 0, 12));

        if (selecionado) {
            setBackground(new Color(124, 62, 29));
            setForeground(Color.WHITE);
        } else {
            setBackground(
                linha % 2 == 0
                    ? Estilo.PAINEL
                    : new Color(40, 46, 57)
            );

            if (coluna == 6 && valor != null) {
                switch (valor.toString()) {
                    case "CONCLUIDA" ->
                        setForeground(Estilo.VERDE);
                    case "CANCELADA" ->
                        setForeground(Estilo.VERMELHO);
                    case "EM_ANDAMENTO" ->
                        setForeground(new Color(251, 191, 36));
                    case "ABERTA" ->
                        setForeground(new Color(96, 165, 250));
                    default ->
                        setForeground(Estilo.TEXTO);
                }
            } else {
                setForeground(Estilo.TEXTO);
            }
        }

        return this;
    }
}

    
    
    
    

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tblOS = new javax.swing.JTable();
        txtTotal = new javax.swing.JTextField();
        txtAbertas = new javax.swing.JTextField();
        btnFechar = new javax.swing.JButton();
        btnRelatorio = new javax.swing.JButton();
        txtAndamento = new javax.swing.JTextField();
        txtCanceladas = new javax.swing.JTextField();
        txtConcluidas = new javax.swing.JTextField();
        txtValorConcluidas = new javax.swing.JTextField();
        cbStatus = new javax.swing.JComboBox<>();
        txtDataInicio = new javax.swing.JFormattedTextField();
        txtDataFim = new javax.swing.JFormattedTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        tblOS.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Nº OS", "Placa", "Cliente", "Mecânico", "Serviço", "Data Abertura", "Status", "Valor Cobrado", "Data Conclusão"
            }
        ));
        jScrollPane1.setViewportView(tblOS);

        txtTotal.setEditable(false);
        txtTotal.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        txtTotal.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtTotal.setBorder(javax.swing.BorderFactory.createTitledBorder("Total de OS"));

        txtAbertas.setEditable(false);
        txtAbertas.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        txtAbertas.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtAbertas.setBorder(javax.swing.BorderFactory.createTitledBorder("Abertas"));

        btnFechar.setText("Fechar");
        btnFechar.addActionListener(this::btnFecharActionPerformed);

        btnRelatorio.setText("Gerar Relatorio");
        btnRelatorio.addActionListener(this::btnRelatorioActionPerformed);

        txtAndamento.setEditable(false);
        txtAndamento.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        txtAndamento.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtAndamento.setBorder(javax.swing.BorderFactory.createTitledBorder("Em andamento"));

        txtCanceladas.setEditable(false);
        txtCanceladas.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        txtCanceladas.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtCanceladas.setBorder(javax.swing.BorderFactory.createTitledBorder("Canceladas"));

        txtConcluidas.setEditable(false);
        txtConcluidas.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        txtConcluidas.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtConcluidas.setBorder(javax.swing.BorderFactory.createTitledBorder("Concluidas"));

        txtValorConcluidas.setEditable(false);
        txtValorConcluidas.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        txtValorConcluidas.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtValorConcluidas.setBorder(javax.swing.BorderFactory.createTitledBorder("Valor das Concluidas"));

        cbStatus.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Todos", "ABERTA", "EM_ANDAMENTO", "CONCLUIDA", "CANCELADA" }));
        cbStatus.setBorder(javax.swing.BorderFactory.createTitledBorder("Status"));

        txtDataInicio.setBorder(javax.swing.BorderFactory.createTitledBorder("Data Inicial"));
        try {
            txtDataInicio.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##/##/####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }

        txtDataFim.setBorder(javax.swing.BorderFactory.createTitledBorder("Data Final"));
        try {
            txtDataFim.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##/##/####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(txtDataInicio, javax.swing.GroupLayout.PREFERRED_SIZE, 245, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txtDataFim, javax.swing.GroupLayout.DEFAULT_SIZE, 292, Short.MAX_VALUE)
                        .addGap(18, 18, 18)
                        .addComponent(cbStatus, javax.swing.GroupLayout.PREFERRED_SIZE, 245, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtTotal, javax.swing.GroupLayout.DEFAULT_SIZE, 395, Short.MAX_VALUE)
                            .addComponent(txtAndamento)
                            .addComponent(txtCanceladas))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(txtConcluidas, javax.swing.GroupLayout.DEFAULT_SIZE, 395, Short.MAX_VALUE)
                            .addComponent(btnFechar, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtAbertas)
                            .addComponent(txtValorConcluidas)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnRelatorio, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(49, 49, 49)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE, false)
                    .addComponent(txtDataInicio, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtDataFim, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbStatus, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(btnRelatorio, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 264, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtAbertas, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtAndamento, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtConcluidas, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 13, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtValorConcluidas, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtCanceladas, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(btnFechar, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnFecharActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFecharActionPerformed
        dispose();
    }//GEN-LAST:event_btnFecharActionPerformed

    private void btnRelatorioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRelatorioActionPerformed
        String status = cbStatus.getSelectedItem().toString();

        String textoInicio = txtDataInicio.getText().trim();
        String textoFim = txtDataFim.getText().trim();

        LocalDate dataInicio = null;
        LocalDate dataFim = null;

        DateTimeFormatter formato = DateTimeFormatter
            .ofPattern("dd/MM/uuuu")
            .withResolverStyle(ResolverStyle.STRICT);

    try {

        String numerosInicio = textoInicio.replaceAll("\\D", "");
        String numerosFim = textoFim.replaceAll("\\D", "");

        
        if (numerosInicio.isEmpty() != numerosFim.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Informe as duas datas ou deixe ambas vazias!");
            return;
        }

        if (!numerosInicio.isEmpty()) {

            dataInicio = LocalDate.parse(textoInicio, formato);
            dataFim = LocalDate.parse(textoFim, formato);

            if (dataFim.isBefore(dataInicio)) {
                JOptionPane.showMessageDialog(this,
                        "A data final não pode ser anterior à inicial!");
                return;
            }
        }

    } catch (DateTimeParseException erro) {
        JOptionPane.showMessageDialog(this,
                "Data inválida! Use DD/MM/AAAA.");
        return;
    }

    String sql = """
        SELECT os.id, v.placa, c.nome AS cliente,
               m.nome AS mecanico, s.descricao AS servico,
               os.data_abertura, os.status,
               os.valor_cobrado, os.data_conclusao
        FROM ordem_servico os
        JOIN veiculo v ON os.veiculo_id = v.id
        JOIN cliente c ON v.cliente_id = c.id
        JOIN mecanico m ON os.mecanico_id = m.id
        JOIN servico s ON os.servico_id = s.id
        WHERE 1 = 1
        """;

    String sqlTotais = """
        SELECT COUNT(*) AS total,
               COUNT(*) FILTER (WHERE status = 'ABERTA') AS abertas,
               COUNT(*) FILTER (WHERE status = 'EM_ANDAMENTO') AS andamento,
               COUNT(*) FILTER (WHERE status = 'CONCLUIDA') AS concluidas,
               COUNT(*) FILTER (WHERE status = 'CANCELADA') AS canceladas,
               COALESCE(SUM(valor_cobrado)
                   FILTER (WHERE status = 'CONCLUIDA'), 0) AS valor_concluidas
        FROM ordem_servico
        WHERE 1 = 1
        """;

    if (dataInicio != null) {
        sql += " AND os.data_abertura >= ? AND os.data_abertura < ? ";
        sqlTotais += " AND data_abertura >= ? AND data_abertura < ? ";
    }

    if (!status.equals("Todos")) {
        sql += " AND os.status = ? ";
        sqlTotais += " AND status = ? ";
    }

    sql += " ORDER BY os.id";

    DefaultTableModel modelo =
            (DefaultTableModel) tblOS.getModel();

    try (Connection conex = Conexao.conectar();
         PreparedStatement stmt = conex.prepareStatement(sql);
         PreparedStatement stmtTotais =
                 conex.prepareStatement(sqlTotais)) {

        int parametro = 1;

        if (dataInicio != null) {

            Timestamp inicio = Timestamp.valueOf(
                    dataInicio.atStartOfDay());

            Timestamp fim = Timestamp.valueOf(
                    dataFim.plusDays(1).atStartOfDay());

            stmt.setTimestamp(parametro, inicio);
            stmtTotais.setTimestamp(parametro, inicio);
            parametro++;

            stmt.setTimestamp(parametro, fim);
            stmtTotais.setTimestamp(parametro, fim);
            parametro++;
        }

        if (!status.equals("Todos")) {
            stmt.setString(parametro, status);
            stmtTotais.setString(parametro, status);
        }

        try (ResultSet rs = stmt.executeQuery()) {

            modelo.setRowCount(0);

            while (rs.next()) {

                modelo.addRow(new Object[]{
                    rs.getInt("id"), rs.getString("placa"),
                    rs.getString("cliente"), rs.getString("mecanico"),
                    rs.getString("servico"), rs.getTimestamp("data_abertura"),
                    rs.getString("status"), rs.getBigDecimal("valor_cobrado"),
                    rs.getTimestamp("data_conclusao")
                });
            }
        }

        try (ResultSet rs = stmtTotais.executeQuery()) {

            if (rs.next()) {

                txtTotal.setText(rs.getString("total"));
                txtAbertas.setText(rs.getString("abertas"));
                txtAndamento.setText(rs.getString("andamento"));
                txtConcluidas.setText(rs.getString("concluidas"));
                txtCanceladas.setText(rs.getString("canceladas"));
                NumberFormat formatoMoeda =
    NumberFormat.getCurrencyInstance(
        Locale.forLanguageTag("pt-BR")
    );

txtValorConcluidas.setText(
    formatoMoeda.format(
        rs.getBigDecimal("valor_concluidas")
    )
);
            }
        }

        } catch (SQLException erro) {

           JOptionPane.showMessageDialog(this, "Erro ao gerar relatório de OS: "  +erro.getMessage());
      }
    }//GEN-LAST:event_btnRelatorioActionPerformed

    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        Estilo.configurarTema();
        java.awt.EventQueue.invokeLater(() -> new FrmRelatorioOS().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnFechar;
    private javax.swing.JButton btnRelatorio;
    private javax.swing.JComboBox<String> cbStatus;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblOS;
    private javax.swing.JTextField txtAbertas;
    private javax.swing.JTextField txtAndamento;
    private javax.swing.JTextField txtCanceladas;
    private javax.swing.JTextField txtConcluidas;
    private javax.swing.JFormattedTextField txtDataFim;
    private javax.swing.JFormattedTextField txtDataInicio;
    private javax.swing.JTextField txtTotal;
    private javax.swing.JTextField txtValorConcluidas;
    // End of variables declaration//GEN-END:variables
}
