package view;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.text.SimpleDateFormat;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import util.Estilo;
import util.Mensagem;

public class FrmRelatorioMecanicos extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(FrmRelatorioMecanicos.class.getName());

    private void carregarEspecialidade(){
        
        cbEspecialidade.removeAllItems();
        cbEspecialidade.addItem("Todos");
        
        String sql = """
                     SELECT DISTINCT especialidade
                     FROM mecanico
                     WHERE especialidade IS NOT NULL
                     ORDER BY especialidade
                     """;
        
        try(Connection conex = Conexao.conectar();
            PreparedStatement stmt = conex.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery()){
            
            while(rs.next()){
                
                cbEspecialidade.addItem(rs.getString("especialidade"));
            }
        }catch(SQLException erro){
            
            JOptionPane.showMessageDialog(this, "Erro ao carregar especialidades: " +erro.getMessage());
        }
    }
   
    public FrmRelatorioMecanicos() {
        initComponents();
        
        tblMecanicos.setModel(new DefaultTableModel(
        new Object[][] {},
        new String[]{
            "ID", "Nome", "Especialidade", "Telefone",
            "Data Admissão", "Observação", "Situação"
        }
    ) {
        @Override
        public boolean isCellEditable(int linha, int coluna) {
            return false;
        }
    });

    carregarEspecialidade();
    criarInterface();
    btnRelatorio.doClick();
    }

    
    
private void criarInterface() {

    setTitle("AutoManager | Relatório de Mecânicos");
    setSize(1350, 900);
    setResizable(false);
    setLocationRelativeTo(null);

    Estilo.configurarIcone(this);

    JPanel principal = new JPanel(new BorderLayout(0, 14));
    principal.setBackground(Estilo.FUNDO);
    principal.setBorder(new EmptyBorder(22, 32, 22, 32));

    // CABEÇALHO
    JPanel cabecalho = new JPanel(new BorderLayout());
    cabecalho.setOpaque(false);

    cabecalho.add(
        new JLabel(Estilo.carregarLogo(280, 94)),
        BorderLayout.WEST
    );

    JLabel secao = new JLabel("RELATÓRIOS / MECÂNICOS");
    secao.setForeground(Estilo.LARANJA);
    secao.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 15));
    cabecalho.add(secao, BorderLayout.EAST);

    JPanel topo = new JPanel(new BorderLayout(0, 12));
    topo.setOpaque(false);
    topo.add(cabecalho, BorderLayout.CENTER);

    JPanel divisor = new JPanel();
    divisor.setBackground(Estilo.LARANJA);
    divisor.setPreferredSize(new Dimension(0, 2));
    topo.add(divisor, BorderLayout.SOUTH);

    principal.add(topo, BorderLayout.NORTH);

    // CONTEÚDO
    JPanel conteudo = new JPanel(new BorderLayout(0, 14));
    conteudo.setOpaque(false);

    JPanel superior = new JPanel();
    superior.setOpaque(false);
    superior.setLayout(
        new BoxLayout(superior, BoxLayout.Y_AXIS)
    );

    JLabel titulo = new JLabel("Relatório de Mecânicos");
    titulo.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 27));
    titulo.setForeground(Estilo.TEXTO);
    titulo.setAlignmentX(Component.LEFT_ALIGNMENT);

    JLabel subtitulo = new JLabel(
        "CONSULTE OS MECÂNICOS CADASTRADOS NO SISTEMA"
    );
    subtitulo.setForeground(Estilo.TEXTO_SECUNDARIO);
    subtitulo.setAlignmentX(Component.LEFT_ALIGNMENT);

    superior.add(titulo);
    superior.add(Box.createVerticalStrut(6));
    superior.add(subtitulo);
    superior.add(Box.createVerticalStrut(18));

    // FILTROS
    JPanel cardFiltro = criarCardRelatorioMecanico();

    Estilo.configurarCombo(cbEspecialidade);
    Estilo.configurarCombo(cbSituacao);

    cbEspecialidade.setBorder(
        UIManager.getBorder("ComboBox.border")
    );
    cbSituacao.setBorder(
        UIManager.getBorder("ComboBox.border")
    );

    cbSituacao.setModel(new DefaultComboBoxModel<>(
        new String[]{"Todos", "Ativos", "Inativos"}
    ));

    JPanel filtros = new JPanel(
        new GridLayout(1, 2, 16, 0)
    );
    filtros.setOpaque(false);

    filtros.add(campoFiltroMecanico(
        "Especialidade", cbEspecialidade
    ));
    filtros.add(campoFiltroMecanico(
        "Situação", cbSituacao
    ));

    Estilo.configurarBotao(btnRelatorio, "laranja");
    btnRelatorio.setText("GERAR RELATÓRIO");
    btnRelatorio.setPreferredSize(new Dimension(195, 44));

    JPanel botaoFiltro = new JPanel(
        new FlowLayout(FlowLayout.RIGHT, 0, 0)
    );
    botaoFiltro.setOpaque(false);
    botaoFiltro.add(btnRelatorio);

    JPanel corpoFiltro = new JPanel(new BorderLayout(18, 0));
    corpoFiltro.setOpaque(false);
    corpoFiltro.add(filtros, BorderLayout.CENTER);
    corpoFiltro.add(botaoFiltro, BorderLayout.EAST);

    cardFiltro.add(corpoFiltro, BorderLayout.CENTER);
    cardFiltro.setPreferredSize(new Dimension(0, 100));
    cardFiltro.setMaximumSize(
        new Dimension(Integer.MAX_VALUE, 100)
    );

    superior.add(cardFiltro);
    conteudo.add(superior, BorderLayout.NORTH);

    // TABELA
    JPanel cardTabela = criarCardRelatorioMecanico();

    Estilo.configurarTabela(tblMecanicos);
    tblMecanicos.setRowHeight(42);
    tblMecanicos.setShowVerticalLines(false);
    tblMecanicos.setShowHorizontalLines(false);
    tblMecanicos.setFillsViewportHeight(true);
    tblMecanicos.setAutoCreateRowSorter(true);
    tblMecanicos.setSelectionMode(
        ListSelectionModel.SINGLE_SELECTION
    );

    tblMecanicos.getTableHeader().setReorderingAllowed(false);
    tblMecanicos.getTableHeader().setPreferredSize(
        new Dimension(0, 44)
    );

    tblMecanicos.setDefaultRenderer(
        Object.class, new RenderizadorRelatorioMecanico()
    );
    tblMecanicos.setDefaultRenderer(
        String.class, new RenderizadorRelatorioMecanico()
    );
    tblMecanicos.setDefaultRenderer(
        Integer.class, new RenderizadorRelatorioMecanico()
    );
    tblMecanicos.setDefaultRenderer(
        java.sql.Date.class, new RenderizadorRelatorioMecanico()
    );

    tblMecanicos.setAutoResizeMode(
        JTable.AUTO_RESIZE_OFF
    );

    int[] larguras = {
        65, 220, 200, 160, 160, 310, 110
    };

    for (int i = 0; i < larguras.length; i++) {
        tblMecanicos.getColumnModel()
            .getColumn(i).setPreferredWidth(larguras[i]);
    }

    jScrollPane1.setBorder(null);
    jScrollPane1.getViewport().setBackground(Estilo.PAINEL);
    jScrollPane1.setHorizontalScrollBarPolicy(
        JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED
    );

    cardTabela.add(jScrollPane1, BorderLayout.CENTER);
    cardTabela.setMinimumSize(new Dimension(0, 350));

    conteudo.add(cardTabela, BorderLayout.CENTER);

    // INDICADORES
    JPanel indicadores = new JPanel(
        new GridLayout(1, 3, 18, 0)
    );
    indicadores.setOpaque(false);

    indicadores.add(criarIndicadorMecanico(
        "TOTAL DE MECÂNICOS", txtTotal, Estilo.LARANJA
    ));

    indicadores.add(criarIndicadorMecanico(
        "MECÂNICOS ATIVOS", txtAtivos, Estilo.VERDE
    ));

    indicadores.add(criarIndicadorMecanico(
        "MECÂNICOS INATIVOS", txtInativos, Estilo.VERMELHO
    ));

    indicadores.setPreferredSize(new Dimension(0, 100));
    conteudo.add(indicadores, BorderLayout.SOUTH);

    principal.add(conteudo, BorderLayout.CENTER);

    // RODAPÉ
    JPanel rodape = new JPanel(
        new FlowLayout(FlowLayout.RIGHT, 0, 0)
    );
    rodape.setOpaque(false);

    Estilo.configurarBotao(btnFechar, "cinza");
    btnFechar.setText("FECHAR");
    btnFechar.setPreferredSize(new Dimension(160, 44));

    rodape.add(btnFechar);
    principal.add(rodape, BorderLayout.SOUTH);

    setContentPane(principal);

    revalidate();
    repaint();
}

// CARD
private JPanel criarCardRelatorioMecanico() {
    JPanel painel = new JPanel(new BorderLayout());
    painel.setBackground(Estilo.PAINEL);
    painel.setBorder(new EmptyBorder(18, 20, 18, 20));
    painel.setAlignmentX(Component.LEFT_ALIGNMENT);
    return painel;
}

// FILTRO COM TÍTULO
private JPanel campoFiltroMecanico(
        String titulo, JComponent componente) {

    JPanel painel = new JPanel(new BorderLayout(0, 8));
    painel.setOpaque(false);

    JLabel label = new JLabel(titulo);
    label.setForeground(Estilo.TEXTO);
    label.setFont(Estilo.FONTE_PADRAO);

    painel.add(label, BorderLayout.NORTH);
    painel.add(componente, BorderLayout.CENTER);

    return painel;
}

// INDICADOR COM TÍTULO E NÚMERO PRÓXIMOS
private JPanel criarIndicadorMecanico(
        String titulo, JTextField campo, Color cor) {

    JPanel painel = criarCardRelatorioMecanico();

    JPanel detalhe = new JPanel();
    detalhe.setBackground(cor);
    detalhe.setPreferredSize(new Dimension(4, 0));
    painel.add(detalhe, BorderLayout.WEST);

    JLabel label = new JLabel(titulo);
    label.setForeground(Estilo.TEXTO_SECUNDARIO);
    label.setFont(
        new Font(Font.SANS_SERIF, Font.BOLD, 13)
    );
    label.setAlignmentX(Component.LEFT_ALIGNMENT);

    campo.setEditable(false);
    campo.setFocusable(false);
    campo.setHorizontalAlignment(JTextField.LEFT);
    campo.setFont(
        new Font(Font.SANS_SERIF, Font.BOLD, 34)
    );
    campo.setForeground(Estilo.TEXTO);
    campo.setBackground(Estilo.PAINEL);
    campo.setBorder(null);
    campo.setAlignmentX(Component.LEFT_ALIGNMENT);

    campo.setPreferredSize(new Dimension(150, 42));
    campo.setMaximumSize(
        new Dimension(Integer.MAX_VALUE, 42)
    );

    JPanel informacoes = new JPanel();
    informacoes.setOpaque(false);
    informacoes.setLayout(
        new BoxLayout(informacoes, BoxLayout.Y_AXIS)
    );

    informacoes.add(label);
    informacoes.add(Box.createVerticalStrut(5));
    informacoes.add(campo);

    JPanel margem = new JPanel(new BorderLayout());
    margem.setOpaque(false);
    margem.setBorder(
        new EmptyBorder(0, 16, 0, 0)
    );
    margem.add(informacoes, BorderLayout.CENTER);

    painel.add(margem, BorderLayout.CENTER);

    return painel;
}

// RENDERIZADOR DA TABELA
private class RenderizadorRelatorioMecanico
        extends DefaultTableCellRenderer {

    @Override
    public Component getTableCellRendererComponent(
            JTable tabela, Object valor,
            boolean selecionado, boolean foco,
            int linha, int coluna) {

        Object exibicao = valor;

        if (valor instanceof java.sql.Date data) {
            exibicao = new SimpleDateFormat("dd/MM/yyyy")
                .format(data);
        }

        super.getTableCellRendererComponent(
            tabela, exibicao, selecionado,
            foco, linha, coluna
        );

        setBorder(new EmptyBorder(0, 12, 0, 12));

        if (selecionado) {
            setBackground(new Color(124, 62, 29));
            setForeground(Color.WHITE);
        } else {
            setBackground(
                linha % 2 == 0
                    ? Estilo.PAINEL
                    : new Color(40, 46, 57)
            );

            if (coluna == 6 && valor != null) {
                setForeground(
                    "Ativo".equals(valor.toString())
                        ? new Color(74, 222, 128)
                        : new Color(248, 113, 113)
                );
            } else {
                setForeground(Estilo.TEXTO);
            }
        }

        return this;
    }
}

    
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tblMecanicos = new javax.swing.JTable();
        txtTotal = new javax.swing.JTextField();
        txtAtivos = new javax.swing.JTextField();
        txtInativos = new javax.swing.JTextField();
        btnFechar = new javax.swing.JButton();
        cbEspecialidade = new javax.swing.JComboBox<>();
        btnRelatorio = new javax.swing.JButton();
        cbSituacao = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        tblMecanicos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Nome", "Especialidade", "Telefone", "Data Admissão", "Observação", "Situação"
            }
        ));
        jScrollPane1.setViewportView(tblMecanicos);

        txtTotal.setEditable(false);
        txtTotal.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        txtTotal.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtTotal.setBorder(javax.swing.BorderFactory.createTitledBorder("Total"));

        txtAtivos.setEditable(false);
        txtAtivos.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        txtAtivos.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtAtivos.setBorder(javax.swing.BorderFactory.createTitledBorder("Ativos"));

        txtInativos.setEditable(false);
        txtInativos.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N
        txtInativos.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtInativos.setBorder(javax.swing.BorderFactory.createTitledBorder("Inativos"));

        btnFechar.setText("Fechar");
        btnFechar.addActionListener(this::btnFecharActionPerformed);

        cbEspecialidade.setBorder(javax.swing.BorderFactory.createTitledBorder("Especialidade"));

        btnRelatorio.setText("Gerar Relatorio");
        btnRelatorio.addActionListener(this::btnRelatorioActionPerformed);

        cbSituacao.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Todos", "Ativos", "Inativos" }));
        cbSituacao.setBorder(javax.swing.BorderFactory.createTitledBorder("Situacao"));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1)
            .addGroup(layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addComponent(txtTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(111, 111, 111)
                .addComponent(txtAtivos, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(txtInativos, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(71, 71, 71))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(btnFechar, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(btnRelatorio, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(31, 31, 31))))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(cbEspecialidade, javax.swing.GroupLayout.PREFERRED_SIZE, 375, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(cbSituacao, javax.swing.GroupLayout.PREFERRED_SIZE, 375, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(9, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(70, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cbEspecialidade, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbSituacao, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(btnRelatorio, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 225, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtInativos, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtAtivos, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(btnFechar, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnRelatorioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRelatorioActionPerformed
        String especialidade = cbEspecialidade.getSelectedItem().toString();
        String situacao = cbSituacao.getSelectedItem().toString();
        
        String sql = """
                     SELECT id, nome, especialidade, telefone,
                            data_admissao, observacao, ativo
                     FROM mecanico
                     WHERE 1 = 1
                     """;
        
        if(!especialidade.equals("Todos")){
            
            sql += " AND especialidade = ?";
        }
        
        if(situacao.equals("Ativos")){
            
            sql += " AND ativo = TRUE";
            
        }else if(situacao.equals("Inativos")){
            
            sql += " AND ativo = FALSE";
        }
        
        sql += " ORDER BY nome";
        
        DefaultTableModel modelo = (DefaultTableModel) tblMecanicos.getModel();
        
        try(Connection conex = Conexao.conectar();
            PreparedStatement stmt = conex.prepareStatement(sql)){
            
            if(!especialidade.equals("Todos")){
                
                stmt.setString(1, especialidade);
            }
            
            try(ResultSet rs = stmt.executeQuery()){
                
                modelo.setRowCount(0);
                
                while(rs.next()){
                    
                    modelo.addRow(new Object[]{
                        
                     rs.getInt("id"), rs.getString("nome"),
                     rs.getString("especialidade"), rs.getString("telefone"),
                     rs.getDate("data_admissao"), rs.getString("observacao"),
                     rs.getBoolean("ativo")? "Ativo" : "Inativo"   
                    });
                }
            }
        }catch(SQLException erro){
            
            JOptionPane.showMessageDialog(this, "Erro ao gerar relatorio: " +erro.getMessage());
            return;
        }
        
        String sqlTotais = """
                           SELECT COUNT(*) AS total,
                           COUNT(*) FILTER (WHERE ativo = TRUE) AS ativos,
                           COUNT(*) FILTER (WHERE ativo = FALSE) AS inativos
                           FROM mecanico
                           """;
        
         try (Connection conex = Conexao.conectar();
         PreparedStatement stmt = conex.prepareStatement(sqlTotais);
         ResultSet rs = stmt.executeQuery()) {

                if (rs.next()) {
                    txtTotal.setText(rs.getString("total"));
                    txtAtivos.setText(rs.getString("ativos"));
                    txtInativos.setText(rs.getString("inativos"));
            }

    } catch (SQLException erro) {
        JOptionPane.showMessageDialog(this, "Erro ao carregar indicadores: " +erro.getMessage());
    }
              
    }//GEN-LAST:event_btnRelatorioActionPerformed

    private void btnFecharActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFecharActionPerformed
        dispose();
    }//GEN-LAST:event_btnFecharActionPerformed

    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        Estilo.configurarTema();
        java.awt.EventQueue.invokeLater(() -> new FrmRelatorioMecanicos().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnFechar;
    private javax.swing.JButton btnRelatorio;
    private javax.swing.JComboBox<String> cbEspecialidade;
    private javax.swing.JComboBox<String> cbSituacao;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblMecanicos;
    private javax.swing.JTextField txtAtivos;
    private javax.swing.JTextField txtInativos;
    private javax.swing.JTextField txtTotal;
    // End of variables declaration//GEN-END:variables
}
