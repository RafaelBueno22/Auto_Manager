package view;

import java.sql.Connection;
import conexao.Conexao;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
import java.sql.SQLException;
import util.Estilo;
import util.SwitchAtivo;
import util.Mensagem;
import util.BordaArredondada;



public class FrmCadastroCliente extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(FrmCadastroCliente.class.getName());

    private void limparCampos(){
                txtNome.setText("");
                txtCPF.setText("");
                txtTelefone.setText("");
                txtEmail.setText("");
                txtEndereco.setText("");
                chkAtivo.setSelected(true);
                if (switchAtivo != null) {
    switchAtivo.setSelected(true);
}
                txtNome.requestFocus();
                
    }
    
    private SwitchAtivo switchAtivo;
    
                private void criarInterface() {

    setTitle("AutoManager - Cadastro de Clientes");
    setDefaultCloseOperation(DISPOSE_ON_CLOSE);

    // PAINEL PRINCIPAL
    javax.swing.JPanel principal = new javax.swing.JPanel(
            new java.awt.BorderLayout(0, 22));

    principal.setBackground(Estilo.FUNDO);
    principal.setBorder(
            javax.swing.BorderFactory.createEmptyBorder(
                    28, 42, 28, 42));

    // CABEÇALHO
    javax.swing.JPanel cabecalho = new javax.swing.JPanel(
            new java.awt.BorderLayout(0, 18));

    cabecalho.setBackground(Estilo.FUNDO);

    javax.swing.JPanel marca = new javax.swing.JPanel(
            new java.awt.BorderLayout());

    marca.setBackground(Estilo.FUNDO);

    javax.swing.JLabel logo = new javax.swing.JLabel();
            logo.setIcon(Estilo.carregarLogo(350, 117));

    logo.setFont(new java.awt.Font(
            java.awt.Font.SANS_SERIF,
            java.awt.Font.BOLD, 28));

    logo.setForeground(Estilo.LARANJA);

    javax.swing.JLabel identificador = new javax.swing.JLabel(
            "CLIENTES / 01");

    identificador.setFont(Estilo.FONTE_BOTAO);
    identificador.setForeground(Estilo.LARANJA);

    marca.add(logo, java.awt.BorderLayout.WEST);
    marca.add(identificador, java.awt.BorderLayout.EAST);

    javax.swing.JPanel linha = new javax.swing.JPanel();
    linha.setBackground(Estilo.LARANJA);
    linha.setPreferredSize(new java.awt.Dimension(0, 3));

    javax.swing.JPanel titulos = new javax.swing.JPanel();
    titulos.setBackground(Estilo.FUNDO);
    titulos.setLayout(new javax.swing.BoxLayout(
            titulos, javax.swing.BoxLayout.Y_AXIS));

    javax.swing.JLabel titulo = new javax.swing.JLabel(
            "Cadastro de Clientes");

    Estilo.configurarTitulo(titulo);
    titulo.setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);

    javax.swing.JLabel subtitulo = new javax.swing.JLabel(
            "CONTROLE E GERENCIAMENTO DE CLIENTES");

    subtitulo.setFont(Estilo.FONTE_PADRAO);
    subtitulo.setForeground(Estilo.TEXTO_SECUNDARIO);
    subtitulo.setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);

    titulos.add(titulo);
    titulos.add(javax.swing.Box.createVerticalStrut(6));
    titulos.add(subtitulo);

    javax.swing.JPanel topo = new javax.swing.JPanel(
            new java.awt.BorderLayout(0, 18));

    topo.setBackground(Estilo.FUNDO);
    topo.add(marca, java.awt.BorderLayout.NORTH);
    topo.add(linha, java.awt.BorderLayout.CENTER);
    topo.add(titulos, java.awt.BorderLayout.SOUTH);

    cabecalho.add(topo, java.awt.BorderLayout.CENTER);
    principal.add(cabecalho, java.awt.BorderLayout.NORTH);

    // PAINEL DO FORMULÁRIO
    javax.swing.JPanel formulario = new javax.swing.JPanel(
            new java.awt.GridBagLayout());

    formulario.setBackground(Estilo.PAINEL);
    formulario.setBorder(
            javax.swing.BorderFactory.createEmptyBorder(
                    24, 30, 24, 30));

    java.awt.GridBagConstraints gbc =
            new java.awt.GridBagConstraints();

    gbc.insets = new java.awt.Insets(10, 10, 10, 10);
    gbc.fill = java.awt.GridBagConstraints.HORIZONTAL;
    gbc.weightx = 1;

    // TÍTULO DA SEÇÃO
    javax.swing.JLabel secao = new javax.swing.JLabel(
            "INFORMAÇÕES DO CLIENTE");

secao.setFont(Estilo.FONTE_SUBTITULO);
secao.setForeground(Estilo.TEXTO);

javax.swing.JPanel barraLaranja = new javax.swing.JPanel();
barraLaranja.setBackground(Estilo.LARANJA);
barraLaranja.setPreferredSize(new java.awt.Dimension(4, 24));

javax.swing.JPanel cabecalhoSecao = new javax.swing.JPanel(
        new java.awt.FlowLayout(
                java.awt.FlowLayout.LEFT, 12, 0));

cabecalhoSecao.setBackground(Estilo.PAINEL);
cabecalhoSecao.add(barraLaranja);
cabecalhoSecao.add(secao);

    secao.setFont(Estilo.FONTE_SUBTITULO);
    secao.setForeground(Estilo.TEXTO);

    gbc.gridx = 0;
    gbc.gridy = 0;
    gbc.gridwidth = 2;
    gbc.weighty = 0;

    formulario.add(cabecalhoSecao, gbc);

    // ESTILO DOS CAMPOS EXISTENTES
    javax.swing.JTextField[] campos = {
        txtID, txtNome, txtCPF,
        txtTelefone, txtEmail, txtEndereco
    };

    for (javax.swing.JTextField campo : campos) {
        Estilo.configurarCampo(campo);
        Estilo.configurarFoco(campo);
    }

    txtID.setEditable(false);
    txtID.setFocusable(false);

    adicionarCampo(formulario, gbc, "ID", txtID, 0, 1);
    adicionarCampo(formulario, gbc, "NOME COMPLETO", txtNome, 1, 1);
    adicionarCampo(formulario, gbc, "CPF", txtCPF, 0, 2);
    adicionarCampo(formulario, gbc, "TELEFONE", txtTelefone, 1, 2);
    adicionarCampo(formulario, gbc, "E-MAIL", txtEmail, 0, 3);
    adicionarCampo(formulario, gbc, "ENDEREÇO", txtEndereco, 1, 3);

    // INTERRUPTOR DE SITUAÇÃO
switchAtivo = new SwitchAtivo();
switchAtivo.setSelected(chkAtivo.isSelected());

javax.swing.JLabel lblSituacao =
        new javax.swing.JLabel("Cliente ativo");

lblSituacao.setFont(Estilo.FONTE_PADRAO);
lblSituacao.setForeground(Estilo.TEXTO);

javax.swing.JPanel painelSituacao =
        new javax.swing.JPanel(
                new java.awt.FlowLayout(
                        java.awt.FlowLayout.LEFT, 12, 0));

painelSituacao.setBackground(Estilo.PAINEL);
painelSituacao.add(switchAtivo);
painelSituacao.add(lblSituacao);

// Atualiza o texto e o checkbox original
switchAtivo.addActionListener(e -> {
    boolean ativo = switchAtivo.isSelected();

    chkAtivo.setSelected(ativo);

    lblSituacao.setText(
            ativo ? "Cliente ativo" : "Cliente inativo");
});

// Posicionamento
gbc.gridx = 0;
gbc.gridy = 4;
gbc.gridwidth = 2;
gbc.weighty = 0;
gbc.anchor = java.awt.GridBagConstraints.WEST;

formulario.add(painelSituacao, gbc);

    gbc.gridx = 0;
    gbc.gridy = 4;
    gbc.gridwidth = 2;
    gbc.weighty = 0;
    gbc.anchor = java.awt.GridBagConstraints.WEST;

    formulario.add(chkAtivo, gbc);

    // Evita esticar o formulário verticalmente
    javax.swing.JPanel centro = new javax.swing.JPanel(
            new java.awt.BorderLayout());

    centro.setBackground(Estilo.FUNDO);
    centro.add(formulario, java.awt.BorderLayout.NORTH);

    principal.add(centro, java.awt.BorderLayout.CENTER);

    // RODAPÉ
    javax.swing.JPanel rodape = new javax.swing.JPanel(
            new java.awt.FlowLayout(
                    java.awt.FlowLayout.RIGHT, 12, 0));

    rodape.setBackground(Estilo.FUNDO);

    Estilo.configurarBotao(btnCadastrar, "laranja");
    Estilo.configurarBotao(btnLimpar, "cinza");
    Estilo.configurarBotao(btnFechar, "vermelho");

    btnCadastrar.setText("CADASTRAR CLIENTE");
    btnLimpar.setText("LIMPAR");
    btnFechar.setText("FECHAR");

    btnCadastrar.setPreferredSize(
            new java.awt.Dimension(210, 46));

    btnLimpar.setPreferredSize(
            new java.awt.Dimension(145, 46));

    btnFechar.setPreferredSize(
            new java.awt.Dimension(145, 46));

    rodape.add(btnLimpar);
    rodape.add(btnFechar);
    rodape.add(btnCadastrar);

    principal.add(rodape, java.awt.BorderLayout.SOUTH);

    // APLICA O NOVO CONTEÚDO
    setContentPane(principal);

    revalidate();
    repaint();
}
                
        
                private void adicionarCampo(
        javax.swing.JPanel painel,
        java.awt.GridBagConstraints gbc,
        String titulo,
        javax.swing.JTextField campo,
        int coluna,
        int linha) {

    // Painel individual de cada campo
    javax.swing.JPanel grupo = new javax.swing.JPanel();

    grupo.setLayout(new javax.swing.BoxLayout(
            grupo,
            javax.swing.BoxLayout.Y_AXIS));

    grupo.setBackground(Estilo.PAINEL);

    // Nome do campo
    javax.swing.JLabel label = new javax.swing.JLabel(titulo);

    label.setFont(Estilo.FONTE_PADRAO);
    label.setForeground(Estilo.TEXTO_SECUNDARIO);
    label.setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);

    // Configuração do campo
    campo.setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);

    campo.setPreferredSize(
            new java.awt.Dimension(350, 44));

    campo.setMaximumSize(
            new java.awt.Dimension(Integer.MAX_VALUE, 44));

    // Adiciona os elementos
    grupo.add(label);
    grupo.add(javax.swing.Box.createVerticalStrut(8));
    grupo.add(campo);

    // Posicionamento no formulário
    gbc.gridx = coluna;
    gbc.gridy = linha;
    gbc.gridwidth = 1;
    gbc.weightx = 1;
    gbc.weighty = 0;
    gbc.fill = java.awt.GridBagConstraints.HORIZONTAL;
    gbc.anchor = java.awt.GridBagConstraints.CENTER;

    painel.add(grupo, gbc);
    
    
    // PLACEHOLDERS DOS CAMPOS

txtID.putClientProperty(
        "JTextField.placeholderText",
        "Gerado automaticamente");

txtNome.putClientProperty(
        "JTextField.placeholderText",
        "Digite o nome completo do cliente");

txtEmail.putClientProperty(
        "JTextField.placeholderText",
        "exemplo@email.com");

txtEndereco.putClientProperty(
        "JTextField.placeholderText",
        "Rua, número, bairro e cidade");

// BOTÃO CADASTRAR - LARANJA
Estilo.configurarBotao(btnCadastrar, "laranja");

Estilo.configurarHover(
        btnCadastrar,
        new java.awt.Color(234, 88, 12));

// BOTÃO LIMPAR - CINZA
Estilo.configurarBotao(btnLimpar, "cinza");

Estilo.configurarHover(
        btnLimpar,
        new java.awt.Color(100, 116, 139));

// BOTÃO FECHAR - VERMELHO
Estilo.configurarBotao(btnFechar, "vermelho");

Estilo.configurarHover(
        btnFechar,
        new java.awt.Color(220, 38, 38));

btnFechar.setBackground(
        new java.awt.Color(185, 28, 28));
                }
                
                
    
    public FrmCadastroCliente() {
        initComponents();
        
        
        Estilo.configurarIcone(this);
        
        criarInterface();
     setSize(1050, 820);
    setMinimumSize(new java.awt.Dimension(1050, 720));

    // Impede maximizar e redimensionar
    setResizable(false);

    // Centraliza a janela
    setLocationRelativeTo(null);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        btnCadastrar = new javax.swing.JButton();
        btnLimpar = new javax.swing.JButton();
        btnFechar = new javax.swing.JButton();
        txtNome = new javax.swing.JTextField();
        txtCPF = new javax.swing.JFormattedTextField();
        txtTelefone = new javax.swing.JFormattedTextField();
        txtEmail = new javax.swing.JTextField();
        txtEndereco = new javax.swing.JTextField();
        chkAtivo = new javax.swing.JCheckBox();
        txtID = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(36, 7, 122));

        btnCadastrar.setBackground(new java.awt.Color(0, 102, 0));
        btnCadastrar.setText("Cadastrar ");
        btnCadastrar.addActionListener(this::btnCadastrarActionPerformed);

        btnLimpar.setBackground(new java.awt.Color(204, 204, 0));
        btnLimpar.setText("Limpar");
        btnLimpar.addActionListener(this::btnLimparActionPerformed);

        btnFechar.setBackground(new java.awt.Color(102, 0, 0));
        btnFechar.setText("Fechar");
        btnFechar.addActionListener(this::btnFecharActionPerformed);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnLimpar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCadastrar, javax.swing.GroupLayout.DEFAULT_SIZE, 120, Short.MAX_VALUE)
                    .addComponent(btnFechar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addComponent(btnCadastrar, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addComponent(btnLimpar, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addComponent(btnFechar, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        txtNome.setToolTipText("Digite o seu nome aqui:");
        txtNome.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Nome", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Verdana", 0, 12))); // NOI18N
        txtNome.addActionListener(this::txtNomeActionPerformed);

        txtCPF.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "CPF", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Verdana", 0, 12))); // NOI18N
        try {
            txtCPF.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("###.###.###-##")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        txtCPF.setToolTipText("Digite o seu CPF aqui:");

        txtTelefone.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Telefone", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Verdana", 0, 12))); // NOI18N
        try {
            txtTelefone.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("(##)#####-####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        txtTelefone.setToolTipText("Digite o seu telefone aqui:");

        txtEmail.setToolTipText("Digite o seu email aqui:");
        txtEmail.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Email", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Verdana", 0, 12))); // NOI18N
        txtEmail.addActionListener(this::txtEmailActionPerformed);

        txtEndereco.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Endereço", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Verdana", 0, 12))); // NOI18N

        chkAtivo.setSelected(true);
        chkAtivo.setText("Ativo");

        txtID.setEditable(false);
        txtID.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "ID", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Verdana", 0, 12))); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addComponent(chkAtivo)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(txtNome, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 292, Short.MAX_VALUE)
                            .addComponent(txtID, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtCPF, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtTelefone, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtEmail, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtEndereco, javax.swing.GroupLayout.Alignment.LEADING))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(txtID, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(txtNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(txtCPF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(txtTelefone, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(txtEndereco, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(chkAtivo)
                .addContainerGap(16, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtNomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNomeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNomeActionPerformed

    private void txtEmailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtEmailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtEmailActionPerformed

    private void btnCadastrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCadastrarActionPerformed
       
            String nome = txtNome.getText().trim().toUpperCase();
            String cpf = txtCPF.getText().trim();
            String telefone = txtTelefone.getText().trim();
            String email = txtEmail.getText().trim();
            String endereco = txtEndereco.getText().trim();
            boolean ativo = chkAtivo.isSelected();
        
        String sqlInsert = """
                           INSERT INTO cliente
                           (nome,cpf,telefone,email,endereco,ativo)
                           VALUES (?,?,?,?,?,?)
                           """;
        
        try {
            Connection conex = Conexao.conectar();
            PreparedStatement stmt = conex.prepareStatement(sqlInsert);
            
            stmt.setString(1, nome);
            stmt.setString(2, cpf);
            stmt.setString(3, telefone);
            stmt.setString(4, email);
            stmt.setString(5, endereco);
            stmt.setBoolean(6, ativo);
            
            int linhas = stmt.executeUpdate();
            
            if (linhas >0){
                 Mensagem.sucesso(
            this,
            "Cliente cadastrado com sucesso!"
    );
                limparCampos();
                
            }
                    
        } catch (SQLException erro) {
            Mensagem.erro(
            this,
            "Não foi possível cadastrar o cliente: "
            + erro.getMessage()
    );
        }
        
    }//GEN-LAST:event_btnCadastrarActionPerformed

    private void btnLimparActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimparActionPerformed
                limparCampos();
                
    }//GEN-LAST:event_btnLimparActionPerformed

    private void btnFecharActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFecharActionPerformed
        dispose();
    }//GEN-LAST:event_btnFecharActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new FrmCadastroCliente().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCadastrar;
    private javax.swing.JButton btnFechar;
    private javax.swing.JButton btnLimpar;
    private javax.swing.JCheckBox chkAtivo;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JFormattedTextField txtCPF;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtEndereco;
    private javax.swing.JTextField txtID;
    private javax.swing.JTextField txtNome;
    private javax.swing.JFormattedTextField txtTelefone;
    // End of variables declaration//GEN-END:variables
}
