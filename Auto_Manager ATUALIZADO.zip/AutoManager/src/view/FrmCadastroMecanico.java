package view;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import util.Estilo;
import util.Mensagem;
import util.SwitchAtivo;
import util.BordaArredondada;

public class FrmCadastroMecanico extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(FrmCadastroMecanico.class.getName());

    
    public FrmCadastroMecanico() {
        initComponents();
        criarInterface();
    }
    
    
private SwitchAtivo switchAtivo;

private void criarInterface() {

    setTitle("AutoManager | Cadastro de Mecânicos");
    setSize(1050, 720);
    setResizable(false);
    setLocationRelativeTo(null);

    Estilo.configurarIcone(this);

    JPanel principal = new JPanel(new BorderLayout(0, 18));
    principal.setBackground(Estilo.FUNDO);
    principal.setBorder(new EmptyBorder(24, 35, 24, 35));

    // CABEÇALHO
    JPanel cabecalho = new JPanel(new BorderLayout());
    cabecalho.setOpaque(false);

    JLabel logo = new JLabel(Estilo.carregarLogo(280, 94));
    cabecalho.add(logo, BorderLayout.WEST);

    JLabel secao = new JLabel("MECÂNICOS / 03");
    secao.setForeground(Estilo.LARANJA);
    secao.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 15));
    cabecalho.add(secao, BorderLayout.EAST);

    JPanel topo = new JPanel(new BorderLayout(0, 12));
    topo.setOpaque(false);
    topo.add(cabecalho, BorderLayout.CENTER);

    JPanel linha = new JPanel();
    linha.setBackground(Estilo.LARANJA);
    linha.setPreferredSize(new Dimension(0, 2));
    topo.add(linha, BorderLayout.SOUTH);

    principal.add(topo, BorderLayout.NORTH);

    // ÁREA CENTRAL
    JPanel centro = new JPanel();
    centro.setOpaque(false);
    centro.setLayout(new BoxLayout(centro, BoxLayout.Y_AXIS));

    JLabel titulo = new JLabel("Cadastro de Mecânicos");
    titulo.setForeground(Estilo.TEXTO);
    titulo.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 27));
    titulo.setAlignmentX(Component.LEFT_ALIGNMENT);

    JLabel subtitulo = new JLabel(
        "CONTROLE E GERENCIAMENTO DE MECÂNICOS"
    );
    subtitulo.setForeground(Estilo.TEXTO_SECUNDARIO);
    subtitulo.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));
    subtitulo.setAlignmentX(Component.LEFT_ALIGNMENT);

    centro.add(titulo);
    centro.add(Box.createVerticalStrut(5));
    centro.add(subtitulo);
    centro.add(Box.createVerticalStrut(20));

    // CARD PRINCIPAL
    JPanel card = new JPanel(new BorderLayout(0, 16));
    card.setBackground(Estilo.PAINEL);
    card.setBorder(new EmptyBorder(20, 22, 20, 22));
    card.setAlignmentX(Component.LEFT_ALIGNMENT);

    JPanel cabecalhoCard = new JPanel(
        new FlowLayout(FlowLayout.LEFT, 10, 0)
    );
    cabecalhoCard.setOpaque(false);

    JPanel barra = new JPanel();
    barra.setBackground(Estilo.LARANJA);
    barra.setPreferredSize(new Dimension(4, 18));

    JLabel tituloCard = new JLabel("INFORMAÇÕES DO MECÂNICO");
    tituloCard.setForeground(Estilo.TEXTO);
    tituloCard.setFont(
        new Font(Font.SANS_SERIF, Font.BOLD, 13)
    );

    cabecalhoCard.add(barra);
    cabecalhoCard.add(tituloCard);
    card.add(cabecalhoCard, BorderLayout.NORTH);

    // CAMPOS
    JPanel campos = new JPanel(new GridBagLayout());
    campos.setOpaque(false);

    JTextField[] camposTexto = {
        txtId, txtNome, txtEspecialidade,
        txtTelefone, txtDataAdmissao
    };

    for (JTextField campo : camposTexto) {
        Estilo.configurarCampo(campo);

        if (campo != txtId) {
            Estilo.configurarFoco(campo);
        }
    }

    txtId.setEditable(false);
    txtId.setFocusable(false);
    txtId.setText("");
    txtId.setBackground(new Color(35, 40, 49));
    txtId.setForeground(Estilo.TEXTO_SECUNDARIO);

    txtId.putClientProperty(
        "JTextField.placeholderText",
        "Gerado automaticamente"
    );

    txtNome.putClientProperty(
        "JTextField.placeholderText",
        "Digite o nome completo"
    );

    txtEspecialidade.putClientProperty(
        "JTextField.placeholderText",
        "Ex.: Motor, elétrica, suspensão"
    );

    adicionarCampo(campos, "ID", txtId, 0, 0);
    adicionarCampo(campos, "Nome completo", txtNome, 1, 0);
    adicionarCampo(campos, "Especialidade", txtEspecialidade, 0, 1);
    adicionarCampo(campos, "Telefone", txtTelefone, 1, 1);
    adicionarCampo(campos, "Data de admissão", txtDataAdmissao, 0, 2);

    JPanel conteudoCard = new JPanel(new BorderLayout(0, 15));
    conteudoCard.setOpaque(false);
    conteudoCard.add(campos, BorderLayout.NORTH);

    // OBSERVAÇÕES
    JPanel areaObservacao = new JPanel(new BorderLayout(0, 6));
    areaObservacao.setOpaque(false);

    JLabel lblObservacao = new JLabel("Observações");
    lblObservacao.setForeground(Estilo.TEXTO);

    Estilo.configurarArea(txtObservacao);

    txtObservacao.setBorder(
        BorderFactory.createEmptyBorder(10, 14, 10, 14)
    );

    jScrollPane1.setBorder(
        new BordaArredondada(Estilo.BORDA, 18)
    );

    jScrollPane1.setBackground(Estilo.COMPONENTE);
    jScrollPane1.getViewport().setBackground(Estilo.COMPONENTE);

    jScrollPane1.setPreferredSize(new Dimension(0, 85));

    txtObservacao.addFocusListener(
        new java.awt.event.FocusAdapter() {

            @Override
            public void focusGained(java.awt.event.FocusEvent e) {
                jScrollPane1.setBorder(
                    new BordaArredondada(Estilo.LARANJA, 18)
                );
            }

            @Override
            public void focusLost(java.awt.event.FocusEvent e) {
                jScrollPane1.setBorder(
                    new BordaArredondada(Estilo.BORDA, 18)
                );
            }
        }
    );

    areaObservacao.add(lblObservacao, BorderLayout.NORTH);
    areaObservacao.add(jScrollPane1, BorderLayout.CENTER);

    conteudoCard.add(areaObservacao, BorderLayout.CENTER);

    // INTERRUPTOR ATIVO
    switchAtivo = new SwitchAtivo();
    switchAtivo.setSelected(chkAtivo.isSelected());

    switchAtivo.addActionListener(e ->
        chkAtivo.setSelected(switchAtivo.isSelected())
    );

    JPanel situacao = new JPanel(
        new FlowLayout(FlowLayout.LEFT, 10, 0)
    );
    situacao.setOpaque(false);

    JLabel lblAtivo = new JLabel("Mecânico ativo");
    lblAtivo.setForeground(Estilo.TEXTO);

    situacao.add(switchAtivo);
    situacao.add(lblAtivo);

    conteudoCard.add(situacao, BorderLayout.SOUTH);

    card.add(conteudoCard, BorderLayout.CENTER);
    centro.add(card);

    // ROLAGEM
    JScrollPane scrollCentral = new JScrollPane(centro);
    scrollCentral.setBorder(null);
    scrollCentral.setOpaque(false);
    scrollCentral.getViewport().setOpaque(false);

    scrollCentral.setHorizontalScrollBarPolicy(
        JScrollPane.HORIZONTAL_SCROLLBAR_NEVER
    );

    scrollCentral.setVerticalScrollBarPolicy(
        JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED
    );

    scrollCentral.getVerticalScrollBar().setUnitIncrement(16);

    principal.add(scrollCentral, BorderLayout.CENTER);

    // BOTÕES
    JPanel rodape = new JPanel(
        new FlowLayout(FlowLayout.RIGHT, 12, 0)
    );
    rodape.setOpaque(false);

    Estilo.configurarBotao(btnLimpar, "cinza");
    Estilo.configurarBotao(btnFechar, "vermelho");
    Estilo.configurarBotao(btnCadastrar, "laranja");

    Estilo.configurarHover(
        btnLimpar, new Color(100, 116, 139)
    );
    Estilo.configurarHover(
        btnFechar, new Color(220, 38, 38)
    );
    Estilo.configurarHover(
        btnCadastrar, new Color(234, 88, 12)
    );

    btnLimpar.setText("LIMPAR");
    btnFechar.setText("FECHAR");
    btnCadastrar.setText("CADASTRAR MECÂNICO");

    btnLimpar.setPreferredSize(new Dimension(125, 42));
    btnFechar.setPreferredSize(new Dimension(125, 42));
    btnCadastrar.setPreferredSize(new Dimension(220, 42));

    rodape.add(btnLimpar);
    rodape.add(btnFechar);
    rodape.add(btnCadastrar);

    principal.add(rodape, BorderLayout.SOUTH);

    setContentPane(principal);
    revalidate();
    repaint();
}

// ORGANIZA OS CAMPOS EM DUAS COLUNAS
private void adicionarCampo(
        JPanel painel,
        String titulo,
        JComponent campo,
        int coluna,
        int linha) {

    JPanel grupo = new JPanel(new BorderLayout(0, 6));
    grupo.setOpaque(false);

    JLabel label = new JLabel(titulo);
    label.setForeground(Estilo.TEXTO);
    label.setFont(
        new Font(Font.SANS_SERIF, Font.PLAIN, 13)
    );

    grupo.add(label, BorderLayout.NORTH);
    grupo.add(campo, BorderLayout.CENTER);

    GridBagConstraints gbc = new GridBagConstraints();
    gbc.gridx = coluna;
    gbc.gridy = linha;
    gbc.weightx = 1;
    gbc.fill = GridBagConstraints.HORIZONTAL;
    gbc.insets = new Insets(6, 7, 6, 7);

    painel.add(grupo, gbc);
}

    
    
    

    private void limparCampos(){
        txtNome.setText("");
        txtEspecialidade.setText("");
        txtTelefone.setText("");
        txtDataAdmissao.setText("");
        txtObservacao.setText("");
        chkAtivo.setSelected(true);
        if (switchAtivo != null) {
    switchAtivo.setSelected(true);
}
        txtNome.requestFocus();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txtId = new javax.swing.JTextField();
        txtNome = new javax.swing.JTextField();
        txtEspecialidade = new javax.swing.JTextField();
        txtTelefone = new javax.swing.JFormattedTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtObservacao = new javax.swing.JTextArea();
        chkAtivo = new javax.swing.JCheckBox();
        btnLimpar = new javax.swing.JButton();
        btnFechar = new javax.swing.JButton();
        btnCadastrar = new javax.swing.JButton();
        txtDataAdmissao = new javax.swing.JFormattedTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        txtId.setEditable(false);
        txtId.setBorder(javax.swing.BorderFactory.createTitledBorder("ID"));

        txtNome.setBorder(javax.swing.BorderFactory.createTitledBorder("Nome"));

        txtEspecialidade.setBorder(javax.swing.BorderFactory.createTitledBorder("Especialidade"));

        txtTelefone.setBorder(javax.swing.BorderFactory.createTitledBorder("Telefone"));
        try {
            txtTelefone.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("(##)#####-####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }

        txtObservacao.setColumns(20);
        txtObservacao.setRows(5);
        txtObservacao.setBorder(javax.swing.BorderFactory.createTitledBorder("Observação"));
        jScrollPane1.setViewportView(txtObservacao);

        chkAtivo.setSelected(true);
        chkAtivo.setText("Ativo");

        btnLimpar.setBackground(new java.awt.Color(204, 204, 0));
        btnLimpar.setText("Limpar");
        btnLimpar.addActionListener(this::btnLimparActionPerformed);

        btnFechar.setBackground(new java.awt.Color(102, 0, 0));
        btnFechar.setText("Fechar");
        btnFechar.addActionListener(this::btnFecharActionPerformed);

        btnCadastrar.setBackground(new java.awt.Color(0, 102, 0));
        btnCadastrar.setText("Cadastrar");
        btnCadastrar.addActionListener(this::btnCadastrarActionPerformed);

        txtDataAdmissao.setBorder(javax.swing.BorderFactory.createTitledBorder("Data de admissão"));
        try {
            txtDataAdmissao.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##/##/####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(txtTelefone, javax.swing.GroupLayout.DEFAULT_SIZE, 174, Short.MAX_VALUE)
                                .addComponent(txtId, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(txtNome, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(txtEspecialidade, javax.swing.GroupLayout.Alignment.LEADING))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(txtDataAdmissao, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 192, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(chkAtivo)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnFechar)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnLimpar)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnCadastrar)
                        .addGap(11, 11, 11))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(txtId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(txtNome, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(txtEspecialidade, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(txtTelefone, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(txtDataAdmissao, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 58, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(chkAtivo)
                    .addComponent(btnLimpar)
                    .addComponent(btnCadastrar)
                    .addComponent(btnFechar))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnLimparActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimparActionPerformed
        limparCampos();
    }//GEN-LAST:event_btnLimparActionPerformed

    private void btnFecharActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFecharActionPerformed
        dispose();
    }//GEN-LAST:event_btnFecharActionPerformed

    private void btnCadastrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCadastrarActionPerformed
        String nome = txtNome.getText().trim().toUpperCase();
        String especialidade = txtEspecialidade.getText().trim();
        String telefone = txtTelefone.getText().trim();
        String observacao = txtObservacao.getText().trim();
        boolean ativo = chkAtivo.isSelected();
        
        if(nome.isEmpty() || especialidade.isEmpty()) {
            Mensagem.aviso(this, "Preencha nome e especialidade!");
            return;
        }
        
        LocalDate data_Admissao;
        
        try {
    DateTimeFormatter formato = DateTimeFormatter
            .ofPattern("dd/MM/uuuu")
            .withResolverStyle(ResolverStyle.STRICT);

    data_Admissao = LocalDate.parse(
            txtDataAdmissao.getText().trim(), formato
    );

} catch (DateTimeParseException erro) {
    Mensagem.aviso(this, "Data inválida! Use DD/MM/AAAA.");
    return;
}
        
        String sqlInsert = """
                           INSERT INTO mecanico
                           (nome,especialidade,telefone,data_Admissao,observacao,ativo)
                           VALUES (?,?,?,?,?,?)
                           """;
        
         try {
             Connection conex = Conexao.conectar();
             PreparedStatement stmt = conex.prepareStatement(sqlInsert);
             
             stmt.setString(1, nome);
             stmt.setString(2, especialidade);
             stmt.setString(3, telefone);
             stmt.setDate(4, java.sql.Date.valueOf(data_Admissao));
             stmt.setString(5, observacao);
             stmt.setBoolean(6, ativo);
             
             int linhas = stmt.executeUpdate();
             
             if(linhas >0){
             Mensagem.sucesso(this, "Mecânico cadastrado com sucesso!");
              limparCampos();
             }    
        } catch (SQLException erro) {
            Mensagem.erro(
    this,
    "Não foi possível cadastrar o mecânico: "
        + erro.getMessage()
);
        }       
    }//GEN-LAST:event_btnCadastrarActionPerformed

   
    public static void main(String args[]) {
         Estilo.configurarTema();
        java.awt.EventQueue.invokeLater(() -> new FrmCadastroMecanico().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCadastrar;
    private javax.swing.JButton btnFechar;
    private javax.swing.JButton btnLimpar;
    private javax.swing.JCheckBox chkAtivo;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JFormattedTextField txtDataAdmissao;
    private javax.swing.JTextField txtEspecialidade;
    private javax.swing.JTextField txtId;
    private javax.swing.JTextField txtNome;
    private javax.swing.JTextArea txtObservacao;
    private javax.swing.JFormattedTextField txtTelefone;
    // End of variables declaration//GEN-END:variables
}
