package view;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.util.ArrayList;
import java.math.BigDecimal;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import util.Estilo;
import util.Mensagem;

public class FrmConsultaOS extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(FrmConsultaOS.class.getName());

        private void atualizarTabela(){
            String sql = """
                         SELECT os.id,
                         v.placa,
                         c.nome AS cliente,
                         m.nome AS mecanico,
                         s.descricao AS servico,
                         os.data_abertura,
                         os.status,
                         os.valor_cobrado,
                         os.data_conclusao
                         FROM ordem_servico os
                         JOIN veiculo v ON os.veiculo_id = v.id
                         JOIN cliente c ON v.cliente_id = c.id
                         JOIN mecanico m ON os.mecanico_id = m.id
                         JOIN servico s ON os.servico_id = s.id
                         ORDER BY os.id 
                         """;
            
            DefaultTableModel modelo = (DefaultTableModel) tblOS.getModel();
            
            modelo.setRowCount(0);
            
            try(Connection conex = Conexao.conectar();
                PreparedStatement stmt = conex.prepareStatement(sql);
                ResultSet rs = stmt.executeQuery()){
                
                while(rs.next()){
                    modelo.addRow(new Object []{
                        rs.getInt("id"), rs.getString("placa"),
                        rs.getString("cliente"), rs.getString("mecanico"),
                        rs.getString("servico"), rs.getTimestamp("data_abertura"),
                        rs.getString("status"),  rs.getBigDecimal("valor_cobrado"),
                        rs.getTimestamp("data_conclusao")
                    });
                }
            }catch(SQLException erro) {
                JOptionPane.showMessageDialog(this, "Erro ao carregar OS: " +erro.getMessage());
            }
        }
        
        private ArrayList<Integer> idMecanicos = new ArrayList<>();
        private ArrayList<Integer> idServicos = new ArrayList<>();
        
        
private void carregarMecanicos(
        String pesquisa, boolean somenteAtivos) {

    String sql = """
        SELECT id, nome, especialidade
        FROM mecanico
        WHERE (? = FALSE OR ativo = TRUE)
          AND (
              ? = ''
              OR (? = TRUE AND CAST(id AS TEXT) = ?)
              OR (? = FALSE AND nome ILIKE ?)
          )
        ORDER BY id
        """;

    cbMecanico.removeAllItems();
    idMecanicos.clear();

    try (Connection conex = Conexao.conectar();
         PreparedStatement stmt = conex.prepareStatement(sql)) {

        boolean pesquisaId = pesquisa.matches("\\d+");

        stmt.setBoolean(1, somenteAtivos);
        stmt.setString(2, pesquisa);
        stmt.setBoolean(3, pesquisaId);
        stmt.setString(4, pesquisa);
        stmt.setBoolean(5, pesquisaId);
        stmt.setString(6, "%" + pesquisa + "%");

        try (ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                int id = rs.getInt("id");

                cbMecanico.addItem(
                    "ID: " + id + " - "
                    + rs.getString("nome") + " - "
                    + rs.getString("especialidade")
                );

                idMecanicos.add(id);
            }
        }

        cbMecanico.setSelectedIndex(-1);

    } catch (SQLException erro) {
        Mensagem.erro(this,
            "Erro ao carregar mecânicos: " + erro.getMessage());
    }
}

private boolean carregandoOS = false;

        
        private void carregarServicos(String pesquisa, boolean somenteAtivos) {

    String sql = """
        SELECT id, descricao, valor_base
        FROM servico
        WHERE (? = FALSE OR ativo = TRUE)
        AND (
            ? = ''
            OR (? = TRUE AND CAST(id AS TEXT) = ?)
            OR (? = FALSE AND descricao ILIKE ?)
        )
        ORDER BY id
        """;

    cbServico.removeAllItems();
    idServicos.clear();
   

    try (Connection conex = Conexao.conectar();
         PreparedStatement stmt = conex.prepareStatement(sql)) {

        boolean pesquisaId = pesquisa.matches("\\d+");

        stmt.setBoolean(1, somenteAtivos);
        stmt.setString(2, pesquisa);
        stmt.setBoolean(3, pesquisaId);
        stmt.setString(4, pesquisa);
        stmt.setBoolean(5, pesquisaId);
        stmt.setString(6, "%" + pesquisa + "%");

        try (ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {

                int id = rs.getInt("id");
                String descricao = rs.getString("descricao");
                BigDecimal valorBase = rs.getBigDecimal("valor_base");

                cbServico.addItem(
                    "ID: " + id + " - " + descricao
                    + " - R$ " + valorBase
                );

                idServicos.add(id);
                
            }
        }

        cbServico.setSelectedIndex(-1);

    } catch (SQLException erro) {
        JOptionPane.showMessageDialog(this,
                "Erro ao carregar serviços: " + erro.getMessage());
    }
}
    
    public FrmConsultaOS() {
        initComponents();
        
        tblOS.setModel(new DefaultTableModel(new Object [][]{},
                                             new String[]{
                                                 "Nº OS", "Placa", "Cliente", "Mecânico",
                                                 "Serviço", "Data Abertura", "Status",
                                                 "Valor Cobrado", "Data Conclusão"
                                             }
                                            ){
                                                @Override 
                                                public boolean isCellEditable(int linha, int coluna){
                                                    return false;
                                                }
                                            });
        
        tblOS.setSelectionMode(
        ListSelectionModel.SINGLE_SELECTION
    );
        
        carregarMecanicos("", false);
        carregarServicos("", false);
        criarInterface();
        atualizarTabela();
        
    }

    
    
private void criarInterface() {

    setTitle("AutoManager | Consulta de Ordens de Serviço");
    setSize(1350, 900);
setResizable(false);
setLocationRelativeTo(null);

    Estilo.configurarIcone(this);

    JPanel principal = new JPanel(new BorderLayout(0, 16));
    principal.setBackground(Estilo.FUNDO);
    principal.setBorder(new EmptyBorder(22, 32, 22, 32));

    // CABEÇALHO
    JPanel cabecalho = new JPanel(new BorderLayout());
    cabecalho.setOpaque(false);
    cabecalho.add(
        new JLabel(Estilo.carregarLogo(280, 94)),
        BorderLayout.WEST
    );

    JLabel secao = new JLabel("ORDENS DE SERVIÇO / CONSULTA");
    secao.setForeground(Estilo.LARANJA);
    secao.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
    cabecalho.add(secao, BorderLayout.EAST);

    JPanel topo = new JPanel(new BorderLayout(0, 12));
    topo.setOpaque(false);
    topo.add(cabecalho, BorderLayout.CENTER);

    JPanel linha = new JPanel();
    linha.setBackground(Estilo.LARANJA);
    linha.setPreferredSize(new Dimension(0, 2));
    topo.add(linha, BorderLayout.SOUTH);

    principal.add(topo, BorderLayout.NORTH);

    // CONTEÚDO
    JPanel conteudo = new JPanel();
    conteudo.setOpaque(false);
    conteudo.setLayout(new BoxLayout(conteudo, BoxLayout.Y_AXIS));
    conteudo.setBorder(new EmptyBorder(0, 0, 20, 0));

    JLabel titulo = new JLabel("Consulta de Ordens de Serviço");
    titulo.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 26));
    titulo.setForeground(Estilo.TEXTO);
    titulo.setAlignmentX(Component.LEFT_ALIGNMENT);

    JLabel subtitulo = new JLabel(
        "GERENCIE AS ORDENS DE SERVIÇO CADASTRADAS"
    );
    subtitulo.setForeground(Estilo.TEXTO_SECUNDARIO);
    subtitulo.setAlignmentX(Component.LEFT_ALIGNMENT);

    conteudo.add(titulo);
    conteudo.add(Box.createVerticalStrut(6));
    conteudo.add(subtitulo);
    conteudo.add(Box.createVerticalStrut(20));

    // PESQUISA
    JPanel pesquisa = criarCardOS();

    cbPesquisarPor.setModel(new DefaultComboBoxModel<>(
        new String[]{
            "Número da OS", "Placa", "Cliente",
            "Mecânico", "Status", "Período de Abertura"
        }
    ));

    Estilo.configurarCombo(cbPesquisarPor);
    cbPesquisarPor.setBorder(
        UIManager.getBorder("ComboBox.border")
    );

    Estilo.configurarCampo(txtPesquisar);
    Estilo.configurarFoco(txtPesquisar);
    txtPesquisar.putClientProperty(
        "JTextField.placeholderText", "Digite sua pesquisa"
    );

    Estilo.configurarCampo(txtDataInicio);
    Estilo.configurarCampo(txtDataFim);

    txtDataInicio.setBorder(
        UIManager.getBorder("TextField.border")
    );
    txtDataFim.setBorder(
        UIManager.getBorder("TextField.border")
    );

    Estilo.configurarBotao(btnLocalizar, "laranja");
    Estilo.configurarBotao(btnAtualizar, "cinza");

    btnLocalizar.setText("BUSCAR");
    btnAtualizar.setText("ATUALIZAR");

    JPanel filtros = new JPanel(new GridBagLayout());
    filtros.setOpaque(false);

    GridBagConstraints g = new GridBagConstraints();
    g.gridy = 0;
    g.fill = GridBagConstraints.HORIZONTAL;
    g.insets = new Insets(0, 0, 0, 10);

    g.gridx = 0;
    g.weightx = 0;
    filtros.add(campoOS("Pesquisar por", cbPesquisarPor), g);

    g.gridx = 1;
    g.weightx = 1;
    filtros.add(campoOS("Pesquisa", txtPesquisar), g);

    JPanel periodo = new JPanel(new GridLayout(1, 2, 10, 0));
    periodo.setOpaque(false);
    periodo.add(campoOS("Data inicial", txtDataInicio));
    periodo.add(campoOS("Data final", txtDataFim));

    g.gridx = 2;
    g.weightx = 0.6;
    filtros.add(periodo, g);

    JPanel botoesBusca = new JPanel(
        new FlowLayout(FlowLayout.RIGHT, 8, 0)
    );
    botoesBusca.setOpaque(false);

    btnLocalizar.setPreferredSize(new Dimension(120, 42));
    btnAtualizar.setPreferredSize(new Dimension(130, 42));

    botoesBusca.add(btnLocalizar);
    botoesBusca.add(btnAtualizar);

    g.gridx = 3;
    g.weightx = 0;
    g.insets = new Insets(19, 0, 0, 0);
    filtros.add(botoesBusca, g);

    pesquisa.add(filtros, BorderLayout.CENTER);
    pesquisa.setPreferredSize(new Dimension(0, 100));
    pesquisa.setMaximumSize(
        new Dimension(Integer.MAX_VALUE, 100)
    );

    // Alterna entre texto e período
    cbPesquisarPor.addActionListener(e -> {
        boolean porPeriodo = "Período de Abertura".equals(
            cbPesquisarPor.getSelectedItem()
        );

        txtPesquisar.setEnabled(!porPeriodo);
        txtDataInicio.setEnabled(porPeriodo);
        txtDataFim.setEnabled(porPeriodo);
    });

    txtDataInicio.setEnabled(false);
    txtDataFim.setEnabled(false);

    conteudo.add(pesquisa);
    conteudo.add(Box.createVerticalStrut(18));

    // TABELA
    JPanel cardTabela = criarCardOS();

    Estilo.configurarTabela(tblOS);
    tblOS.setRowHeight(38);
    tblOS.setShowVerticalLines(false);
    tblOS.setShowHorizontalLines(false);
    tblOS.setFillsViewportHeight(true);
    tblOS.setAutoCreateRowSorter(true);

    tblOS.getTableHeader().setReorderingAllowed(false);
    tblOS.getTableHeader().setPreferredSize(
        new Dimension(0, 42)
    );

    tblOS.setDefaultRenderer(
        Object.class, new RenderizadorOS()
    );
    tblOS.setDefaultRenderer(
        String.class, new RenderizadorOS()
    );
    tblOS.setDefaultRenderer(
        Integer.class, new RenderizadorOS()
    );
    tblOS.setDefaultRenderer(
        BigDecimal.class, new RenderizadorOS()
    );
    tblOS.setDefaultRenderer(
        Timestamp.class, new RenderizadorOS()
    );

    tblOS.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

    int[] larguras = {
        80, 105, 185, 185, 220,
        170, 155, 140, 170
    };

    for (int i = 0; i < larguras.length; i++) {
        tblOS.getColumnModel()
            .getColumn(i).setPreferredWidth(larguras[i]);
    }

    jScrollPane1.setBorder(null);
    jScrollPane1.getViewport().setBackground(Estilo.PAINEL);
    jScrollPane1.setPreferredSize(new Dimension(0, 280));
    jScrollPane1.setHorizontalScrollBarPolicy(
        JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED
    );

    cardTabela.add(jScrollPane1, BorderLayout.CENTER);
    cardTabela.setPreferredSize(new Dimension(0, 320));
    cardTabela.setMaximumSize(
        new Dimension(Integer.MAX_VALUE, 320)
    );

    conteudo.add(cardTabela);
    conteudo.add(Box.createVerticalStrut(18));

    // EDIÇÃO
    JPanel edicao = criarCardOS();

    JPanel corpo = new JPanel();
    corpo.setOpaque(false);
    corpo.setLayout(new BoxLayout(corpo, BoxLayout.Y_AXIS));

    JLabel tituloEdicao = new JLabel(
        "EDITAR ORDEM DE SERVIÇO SELECIONADA"
    );
    tituloEdicao.setFont(
        new Font(Font.SANS_SERIF, Font.BOLD, 14)
    );
    tituloEdicao.setForeground(Estilo.TEXTO);
    tituloEdicao.setAlignmentX(Component.LEFT_ALIGNMENT);

    corpo.add(tituloEdicao);
    corpo.add(Box.createVerticalStrut(16));

    // ESTILIZA CAMPOS
    JTextField[] campos = {
        txtNOS, txtPlaca, txtCliente,
        txtValorCobrado, txtDataAbertura,
        txtDataConclusao
    };

    for (JTextField campo : campos) {
        Estilo.configurarCampo(campo);
        campo.setBorder(
            UIManager.getBorder("TextField.border")
        );
        campo.putClientProperty("JComponent.roundRect", true);
    }

    txtNOS.setEditable(false);
    txtPlaca.setEditable(false);
    txtCliente.setEditable(false);
    txtDataAbertura.setEditable(false);

    Estilo.configurarCombo(cbMecanico);
    Estilo.configurarCombo(cbServico);
    Estilo.configurarCombo(cbStatus);

    cbMecanico.setBorder(
        UIManager.getBorder("ComboBox.border")
    );
    cbServico.setBorder(
        UIManager.getBorder("ComboBox.border")
    );
    cbStatus.setBorder(
        UIManager.getBorder("ComboBox.border")
    );

    cbStatus.setModel(new DefaultComboBoxModel<>(
        new String[]{
            "ABERTA", "EM_ANDAMENTO",
            "CONCLUIDA", "CANCELADA"
        }
    ));

    // IDENTIFICAÇÃO
    JPanel identificacao = new JPanel(
        new GridLayout(1, 3, 14, 0)
    );
    identificacao.setOpaque(false);

    identificacao.add(campoOS("Nº OS", txtNOS));
    identificacao.add(campoOS("Placa", txtPlaca));
    identificacao.add(campoOS("Cliente", txtCliente));

    identificacao.setPreferredSize(new Dimension(0, 65));
    identificacao.setMaximumSize(
        new Dimension(Integer.MAX_VALUE, 65)
    );
    identificacao.setAlignmentX(Component.LEFT_ALIGNMENT);

    corpo.add(identificacao);
    corpo.add(Box.createVerticalStrut(14));

    // MECÂNICO, SERVIÇO E STATUS
    JPanel linha2 = new JPanel(
        new GridLayout(1, 3, 14, 0)
    );
    linha2.setOpaque(false);

    linha2.add(campoOS("Mecânico", cbMecanico));
    linha2.add(campoOS("Serviço", cbServico));
    linha2.add(campoOS("Status", cbStatus));

    linha2.setPreferredSize(new Dimension(0, 65));
    linha2.setMaximumSize(
        new Dimension(Integer.MAX_VALUE, 65)
    );
    linha2.setAlignmentX(Component.LEFT_ALIGNMENT);

    corpo.add(linha2);
    corpo.add(Box.createVerticalStrut(14));

    // VALOR E DATAS
    JPanel linha3 = new JPanel(
        new GridLayout(1, 3, 14, 0)
    );
    linha3.setOpaque(false);

    linha3.add(campoOS(
        "Valor cobrado (R$)", txtValorCobrado
    ));
    linha3.add(campoOS(
        "Data de abertura", txtDataAbertura
    ));
    linha3.add(campoOS(
        "Data de conclusão", txtDataConclusao
    ));

    linha3.setPreferredSize(new Dimension(0, 65));
    linha3.setMaximumSize(
        new Dimension(Integer.MAX_VALUE, 65)
    );
    linha3.setAlignmentX(Component.LEFT_ALIGNMENT);

    corpo.add(linha3);
    corpo.add(Box.createVerticalStrut(14));

    // DIAGNÓSTICO E OBSERVAÇÕES
    Estilo.configurarArea(txtDiagnostico);
    Estilo.configurarArea(txtObs);

    txtDiagnostico.setBorder(new EmptyBorder(10, 12, 10, 12));
    txtObs.setBorder(new EmptyBorder(10, 12, 10, 12));

    jScrollPane3.setBorder(null);
    jScrollPane4.setBorder(null);

    JPanel textos = new JPanel(
        new GridLayout(1, 2, 14, 0)
    );
    textos.setOpaque(false);

    textos.add(campoOS("Diagnóstico", jScrollPane3));
    textos.add(campoOS("Observações", jScrollPane4));

    textos.setPreferredSize(new Dimension(0, 145));
    textos.setMaximumSize(
        new Dimension(Integer.MAX_VALUE, 145)
    );
    textos.setAlignmentX(Component.LEFT_ALIGNMENT);

    corpo.add(textos);

    edicao.add(corpo, BorderLayout.CENTER);
    edicao.setPreferredSize(new Dimension(0, 495));
    edicao.setMaximumSize(
        new Dimension(Integer.MAX_VALUE, 495)
    );

    conteudo.add(edicao);

    // ROLAGEM
    JScrollPane scrollCentral = new JScrollPane(conteudo);
    scrollCentral.setBorder(null);
    scrollCentral.setOpaque(false);
    scrollCentral.getViewport().setOpaque(false);
    scrollCentral.getVerticalScrollBar().setUnitIncrement(16);
    scrollCentral.setHorizontalScrollBarPolicy(
        JScrollPane.HORIZONTAL_SCROLLBAR_NEVER
    );

    principal.add(scrollCentral, BorderLayout.CENTER);

    // RODAPÉ FIXO
    JPanel rodape = new JPanel(
        new FlowLayout(FlowLayout.RIGHT, 12, 0)
    );
    rodape.setOpaque(false);

    Estilo.configurarBotao(btnFechar, "cinza");
    Estilo.configurarBotao(btnExcluir, "vermelho");
    Estilo.configurarBotao(btnAlterar, "laranja");

    btnFechar.setText("FECHAR");
    btnExcluir.setText("EXCLUIR");
    btnAlterar.setText("ALTERAR");

    btnFechar.setPreferredSize(new Dimension(155, 44));
    btnExcluir.setPreferredSize(new Dimension(155, 44));
    btnAlterar.setPreferredSize(new Dimension(155, 44));

    rodape.add(btnFechar);
    rodape.add(btnExcluir);
    rodape.add(btnAlterar);

    principal.add(rodape, BorderLayout.SOUTH);

    txtPesquisar.addActionListener(
        e -> btnLocalizar.doClick()
    );

    setContentPane(principal);

    SwingUtilities.invokeLater(() ->
        scrollCentral.getVerticalScrollBar().setValue(0)
    );

    revalidate();
    repaint();
}

// CARD
private JPanel criarCardOS() {
    JPanel painel = new JPanel(new BorderLayout());
    painel.setBackground(Estilo.PAINEL);
    painel.setBorder(new EmptyBorder(18, 20, 18, 20));
    painel.setAlignmentX(Component.LEFT_ALIGNMENT);
    return painel;
}

// CAMPO COM TÍTULO
private JPanel campoOS(String titulo, JComponent componente) {
    JPanel painel = new JPanel(new BorderLayout(0, 6));
    painel.setOpaque(false);

    JLabel label = new JLabel(titulo);
    label.setForeground(Estilo.TEXTO);
    label.setFont(Estilo.FONTE_PADRAO);

    painel.add(label, BorderLayout.NORTH);
    painel.add(componente, BorderLayout.CENTER);

    return painel;
}

// RENDERIZADOR DA TABELA
private class RenderizadorOS extends DefaultTableCellRenderer {

    @Override
    public Component getTableCellRendererComponent(
            JTable tabela, Object valor,
            boolean selecionado, boolean foco,
            int linha, int coluna) {

        Object exibicao = valor;

        if (valor instanceof Timestamp data) {
            exibicao = data.toLocalDateTime()
                .format(DateTimeFormatter.ofPattern(
                    "dd/MM/yyyy HH:mm"
                ));
        }

        if (valor instanceof BigDecimal numero) {
            exibicao = "R$ " + numero.toPlainString();
        }

        super.getTableCellRendererComponent(
            tabela, exibicao, selecionado,
            foco, linha, coluna
        );

        setBorder(new EmptyBorder(0, 12, 0, 12));

        if (selecionado) {
            setBackground(new Color(124, 62, 29));
            setForeground(Color.WHITE);
        } else {
            setBackground(
                linha % 2 == 0
                    ? Estilo.PAINEL
                    : new Color(40, 46, 57)
            );

            if (coluna == 6 && valor != null) {
                String status = valor.toString();

                switch (status) {
                    case "CONCLUIDA" ->
                        setForeground(new Color(74, 222, 128));
                    case "CANCELADA" ->
                        setForeground(new Color(248, 113, 113));
                    case "EM_ANDAMENTO" ->
                        setForeground(new Color(251, 191, 36));
                    default ->
                        setForeground(Estilo.TEXTO);
                }
            } else {
                setForeground(Estilo.TEXTO);
            }
        }

        return this;
    }
}

    
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        jTextPane1 = new javax.swing.JTextPane();
        jTextField7 = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        cbPesquisarPor = new javax.swing.JComboBox<>();
        txtPesquisar = new javax.swing.JTextField();
        btnLocalizar = new javax.swing.JButton();
        btnAtualizar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblOS = new javax.swing.JTable();
        txtNOS = new javax.swing.JTextField();
        txtPlaca = new javax.swing.JTextField();
        cbMecanico = new javax.swing.JComboBox<>();
        cbServico = new javax.swing.JComboBox<>();
        jScrollPane3 = new javax.swing.JScrollPane();
        txtDiagnostico = new javax.swing.JTextArea();
        cbStatus = new javax.swing.JComboBox<>();
        txtValorCobrado = new javax.swing.JTextField();
        jScrollPane4 = new javax.swing.JScrollPane();
        txtObs = new javax.swing.JTextArea();
        btnAlterar = new javax.swing.JButton();
        btnFechar = new javax.swing.JButton();
        btnExcluir = new javax.swing.JButton();
        txtDataInicio = new javax.swing.JFormattedTextField();
        txtDataFim = new javax.swing.JFormattedTextField();
        jLabel1 = new javax.swing.JLabel();
        txtDataAbertura = new javax.swing.JFormattedTextField();
        txtDataConclusao = new javax.swing.JFormattedTextField();
        txtCliente = new javax.swing.JTextField();

        jScrollPane2.setViewportView(jTextPane1);

        jTextField7.setText("jTextField7");

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 51, 51));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        cbPesquisarPor.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Número da OS", "Placa", "Cliente", "Mecânico", "Status", "Período de Abertura", " " }));
        cbPesquisarPor.setBorder(javax.swing.BorderFactory.createTitledBorder("Filtro:"));

        txtPesquisar.setBorder(javax.swing.BorderFactory.createTitledBorder("Pesquisa:"));

        btnLocalizar.setText("Localizar");
        btnLocalizar.addActionListener(this::btnLocalizarActionPerformed);

        btnAtualizar.setText("Atualizar");
        btnAtualizar.addActionListener(this::btnAtualizarActionPerformed);

        tblOS.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Nº OS", "Placa", "Cliente", "Mecânico", "Serviço", "Data Abertura", "Status", "Valor Cobrado", "Data Conclusão"
            }
        ));
        tblOS.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblOSMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblOS);

        txtNOS.setEditable(false);
        txtNOS.setBorder(javax.swing.BorderFactory.createTitledBorder("Nº OS"));

        txtPlaca.setEditable(false);
        txtPlaca.setBorder(javax.swing.BorderFactory.createTitledBorder("Placa"));

        cbMecanico.setBorder(javax.swing.BorderFactory.createTitledBorder("Mecanico:"));

        cbServico.setBorder(javax.swing.BorderFactory.createTitledBorder("Servico:"));

        txtDiagnostico.setColumns(20);
        txtDiagnostico.setRows(5);
        txtDiagnostico.setBorder(javax.swing.BorderFactory.createTitledBorder("Diagnostico:"));
        jScrollPane3.setViewportView(txtDiagnostico);

        cbStatus.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ABERTA", "EM_ANDAMENTO", "CONCLUIDA", "CANCELADA", " " }));
        cbStatus.setBorder(null);
        cbStatus.addActionListener(this::cbStatusActionPerformed);

        txtValorCobrado.setBorder(javax.swing.BorderFactory.createTitledBorder("Valor Cobrado"));

        txtObs.setColumns(20);
        txtObs.setRows(5);
        txtObs.setBorder(javax.swing.BorderFactory.createTitledBorder("Observacao"));
        jScrollPane4.setViewportView(txtObs);

        btnAlterar.setText("Alterar");
        btnAlterar.addActionListener(this::btnAlterarActionPerformed);

        btnFechar.setText("Fechar");
        btnFechar.addActionListener(this::btnFecharActionPerformed);

        btnExcluir.setText("Excluir");
        btnExcluir.addActionListener(this::btnExcluirActionPerformed);

        txtDataInicio.setBorder(javax.swing.BorderFactory.createTitledBorder("Periodo Abertura"));
        try {
            txtDataInicio.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##/##/####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        txtDataInicio.addActionListener(this::txtDataInicioActionPerformed);

        try {
            txtDataFim.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##/##/####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }

        jLabel1.setText("até");

        txtDataAbertura.setEditable(false);
        txtDataAbertura.setBorder(javax.swing.BorderFactory.createTitledBorder("Data Abertura"));
        try {
            txtDataAbertura.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##/##/####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }

        txtDataConclusao.setBorder(javax.swing.BorderFactory.createTitledBorder("Data Conclusao"));
        try {
            txtDataConclusao.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##/##/####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }

        txtCliente.setEditable(false);
        txtCliente.setBorder(javax.swing.BorderFactory.createTitledBorder("Cliente:"));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jScrollPane1)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(cbPesquisarPor, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txtPesquisar, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(84, 84, 84)
                        .addComponent(txtDataInicio, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel1)
                        .addGap(18, 18, 18)
                        .addComponent(txtDataFim, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(64, 64, 64)
                        .addComponent(btnLocalizar, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 50, Short.MAX_VALUE)
                        .addComponent(btnAtualizar, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(24, 24, 24))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(txtNOS, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(txtPlaca, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(txtCliente))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(cbMecanico, javax.swing.GroupLayout.PREFERRED_SIZE, 257, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(cbServico, javax.swing.GroupLayout.PREFERRED_SIZE, 257, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 520, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(220, 220, 220)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cbStatus, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtValorCobrado, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txtDataAbertura, javax.swing.GroupLayout.DEFAULT_SIZE, 110, Short.MAX_VALUE)
                                    .addComponent(txtDataConclusao))
                                .addGap(51, 51, 51)
                                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnAlterar, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnExcluir, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)
                        .addComponent(btnFechar, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(cbPesquisarPor, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(txtPesquisar)
                        .addComponent(txtDataInicio)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnLocalizar, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnAtualizar, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txtDataFim, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel1)))
                .addGap(48, 48, 48)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                            .addGap(80, 80, 80)
                            .addComponent(cbStatus, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(txtPlaca, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(txtNOS, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cbMecanico, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbServico, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtValorCobrado, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(12, 12, 12)
                                .addComponent(txtDataAbertura, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(txtDataConclusao, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 34, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnExcluir, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnAlterar, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnFechar, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtDataInicioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDataInicioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDataInicioActionPerformed

    private void btnLocalizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLocalizarActionPerformed
        String pesquisa = txtPesquisar.getText().trim();
        String tipo_pesquisa = cbPesquisarPor.getSelectedItem().toString();
        
        if(!tipo_pesquisa.equals("Período de Abertura") && pesquisa.isEmpty()){
                	Mensagem.aviso(this, "Digite um valor para pesquisar!");
                                return;
        }
        
        String sql = """
                     SELECT os.id, v.placa, c.nome AS cliente,
                     m.nome AS mecanico, s.descricao AS servico,
                     os.data_abertura, os.status,
                     os.valor_cobrado, os.data_conclusao
                     FROM ordem_servico os
                     JOIN veiculo v ON os.veiculo_id = v.id
                     JOIN cliente c ON v.cliente_id = c.id
                     JOIN mecanico m ON os.mecanico_id = m.id
                     JOIN servico s ON os.servico_id = s.id
                     """;
        
        switch (tipo_pesquisa) {
            case "Número da OS":
                sql += " WHERE os.id = ?";
                break;
            case "Placa":
                sql += " WHERE v.placa ILIKE ?";
                break;
            case "Cliente":
                sql += " WHERE c.nome ILIKE ?";
                break;
            case "Mecânico":
                sql += " WHERE m.nome ILIKE ?";
                break;
            case "Status":
                sql += " WHERE os.status = ?";
                break;
            case "Período de Abertura":
                sql += " WHERE os.data_abertura >= ? AND os.data_abertura < ?";
                break;
            default:
                Mensagem.aviso(this, "Filtro inválido!");
                return;
        }
        
        sql += " ORDER BY os.id";
        
        try(Connection conex = Conexao.conectar();
            PreparedStatement stmt = conex.prepareStatement(sql)){
            
            switch (tipo_pesquisa) {
                case "Número da OS" -> stmt.setInt(1, Integer.parseInt(pesquisa));
                case "Status" -> stmt.setString(1, pesquisa.toUpperCase().replace(" ", "_"));
                case "Período de Abertura" -> {
                    DateTimeFormatter formato = DateTimeFormatter
                            .ofPattern("dd/MM/uuuu")
                            .withResolverStyle(ResolverStyle.STRICT);
                    LocalDate inicio = LocalDate.parse(
                            txtDataInicio.getText().trim(), formato);
                    LocalDate fim = LocalDate.parse(
                            txtDataFim.getText().trim(), formato);
                    if (fim.isBefore(inicio)) {
                        
                        Mensagem.aviso(this, "A data final não pode ser anterior à inicial!");
                        return;
                    }       stmt.setTimestamp(1,
                            java.sql.Timestamp.valueOf(inicio.atStartOfDay()));
                    stmt.setTimestamp(2,
                            java.sql.Timestamp.valueOf(fim.plusDays(1).atStartOfDay()));
                }
                default -> stmt.setString(1, "%" +pesquisa+ "%");
            }
            
            DefaultTableModel modelo = (DefaultTableModel) tblOS.getModel();
            
            try(ResultSet rs = stmt.executeQuery()){
                
                modelo.setRowCount(0);
                
                while(rs.next()){
                    modelo.addRow(new Object []{
                     rs.getInt("id"), rs.getString("placa"),
                     rs.getString("cliente"), rs.getString("mecanico"),
                     rs.getString("servico"), rs.getTimestamp("data_abertura"),
                     rs.getString("status"), rs.getBigDecimal("valor_cobrado"),
                     rs.getTimestamp("data_conclusao")   
                    });
                }
            }
            
            if(modelo.getRowCount() == 0){
                Mensagem.aviso(this, "Nenhuma ordem de serviço encontrada!");
            } 
            
        }catch(NumberFormatException erro){
            Mensagem.aviso(this, "ID inválido!");
            
        }catch(DateTimeParseException erro){
            Mensagem.aviso(this, "Data inválida! Use DD/MM/AAAA.");
            
        }catch(SQLException erro){
            Mensagem.erro(this, "Erro ao localizar OS: " + erro.getMessage());
        }
        
    }//GEN-LAST:event_btnLocalizarActionPerformed

    private void btnAtualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAtualizarActionPerformed
        atualizarTabela();
    }//GEN-LAST:event_btnAtualizarActionPerformed

    private void btnAlterarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAlterarActionPerformed
        int linha = tblOS.getSelectedRow();

    if (linha == -1) {
        JOptionPane.showMessageDialog(this, "Selecione uma Ordem de Serviço!");
        return;
    }

    int linhaModelo = tblOS.convertRowIndexToModel(linha);

    int id = Integer.parseInt(
            tblOS.getModel().getValueAt(linhaModelo, 0).toString());

    int posMecanico = cbMecanico.getSelectedIndex();
    int posServico = cbServico.getSelectedIndex();

    if (posMecanico < 0 || posMecanico >= idMecanicos.size()
            || posServico < 0 || posServico >= idServicos.size()) {

        JOptionPane.showMessageDialog(this, "Selecione um mecânico e um serviço!");
        return;
    }

    int mecanicoId = idMecanicos.get(posMecanico);
    int servicoId = idServicos.get(posServico);

    String diagnostico = txtDiagnostico.getText().trim();
    String observacao = txtObs.getText().trim();

    if (cbStatus.getSelectedItem() == null) {
        JOptionPane.showMessageDialog(this,
                "Selecione um status!");
        return;
    }

    String status = cbStatus.getSelectedItem().toString()
            .trim().toUpperCase().replace(" ", "_");

    if (!status.equals("ABERTA")
            && !status.equals("EM_ANDAMENTO")
            && !status.equals("CONCLUIDA")
            && !status.equals("CANCELADA")) {

        JOptionPane.showMessageDialog(this, "Status inválido!");
        return;
    }

    BigDecimal valor;

    try {
        String textoValor = txtValorCobrado.getText() .trim().replace(",", ".");

        valor = new BigDecimal(textoValor);

        if (valor.compareTo(BigDecimal.ZERO) < 0) {
            JOptionPane.showMessageDialog(this, "O valor cobrado não pode ser negativo!");
            return;
        }

    } catch (NumberFormatException erro) {
        JOptionPane.showMessageDialog(this, "Informe um valor cobrado válido!");
        return;
    }

   
    DateTimeFormatter formato = DateTimeFormatter
        .ofPattern("dd/MM/uuuu")
        .withResolverStyle(ResolverStyle.STRICT);

            LocalDate dataConclusao = null;

            String textoData = txtDataConclusao.getText().trim();


            String numerosData = textoData.replaceAll("\\D", "");

        try {

             if (!numerosData.isEmpty()) {

              dataConclusao = LocalDate.parse(textoData, formato);

         }

         } catch (DateTimeParseException erro) {

             JOptionPane.showMessageDialog(this, "Data inválida! Use DD/MM/AAAA.");
         return;
  }

    if (status.equals("CONCLUIDA") && dataConclusao == null) {
        JOptionPane.showMessageDialog(this, "Informe a data de conclusão!");
        return;
    }

    if (!status.equals("CONCLUIDA") && dataConclusao != null) {
        JOptionPane.showMessageDialog(this, "Somente OS concluídas podem ter data de conclusão!");
        return;
    }

    String sql = """
        UPDATE ordem_servico
        SET mecanico_id = ?,
            servico_id = ?,
            diagnostico = ?,
            status = ?,
            valor_cobrado = ?,
            observacao = ?,
            data_conclusao = ?
        WHERE id = ?
        """;

    try (Connection conex = Conexao.conectar()) {

        String sqlVerificar = """
            SELECT data_abertura, status
            FROM ordem_servico
            WHERE id = ?
            """;

        LocalDate dataAbertura;
        String statusAtual;

        try (PreparedStatement stmt =
                conex.prepareStatement(sqlVerificar)) {

            stmt.setInt(1, id);

            try (ResultSet rs = stmt.executeQuery()) {

                if (!rs.next()) {
                    JOptionPane.showMessageDialog(this,
                            "Ordem de Serviço não encontrada!");
                    return;
                }

                dataAbertura = rs.getTimestamp("data_abertura")
                        .toLocalDateTime().toLocalDate();

                statusAtual = rs.getString("status");
            }
        }

        if (dataConclusao != null
                && dataConclusao.isBefore(dataAbertura)) {

            JOptionPane.showMessageDialog(this, "A conclusão não pode ser anterior à abertura!");
            return;
        }

        boolean transicaoValida =
                statusAtual.equals(status)
                || (statusAtual.equals("ABERTA")
                    && (status.equals("EM_ANDAMENTO")
                        || status.equals("CANCELADA")))
                || (statusAtual.equals("EM_ANDAMENTO")
                    && (status.equals("CONCLUIDA")
                        || status.equals("CANCELADA")));

        if (!transicaoValida) {
            JOptionPane.showMessageDialog(this, "Alteração de status não permitida: "
                                          + statusAtual + " para " + status);
            return;
        }

        int opcao = JOptionPane.showConfirmDialog(this, "Deseja realmente alterar a OS nº " + id + "?",
                                                  "Confirmar alteração", JOptionPane.YES_NO_OPTION);

        if (opcao != JOptionPane.YES_OPTION) {
            return;
        }

        try (PreparedStatement stmt = conex.prepareStatement(sql)) {

            stmt.setInt(1, mecanicoId);
            stmt.setInt(2, servicoId);
            stmt.setString(3, diagnostico);
            stmt.setString(4, status);
            stmt.setBigDecimal(5, valor);
            stmt.setString(6, observacao);

            if (dataConclusao != null) {
                stmt.setTimestamp(7,
                        java.sql.Timestamp.valueOf(
                                dataConclusao.atStartOfDay()));
            } else {
                stmt.setNull(7, java.sql.Types.TIMESTAMP);
            }

            stmt.setInt(8, id);

            int linhas = stmt.executeUpdate();

            if (linhas > 0) {
                JOptionPane.showMessageDialog(this, "Ordem de Serviço alterada com sucesso!");

                atualizarTabela();

            } else {
                JOptionPane.showMessageDialog(this, "Nenhuma Ordem de Serviço foi alterada!");
            }
        }

    } catch (SQLException erro) {
        JOptionPane.showMessageDialog(this, "Erro ao alterar OS: " + erro.getMessage());
      }
    }//GEN-LAST:event_btnAlterarActionPerformed

    private void tblOSMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblOSMouseClicked
          int linha = tblOS.getSelectedRow();
    if (linha == -1) return;

    int linhaModelo = tblOS.convertRowIndexToModel(linha);

    int id = Integer.parseInt(
        tblOS.getModel().getValueAt(linhaModelo, 0).toString()
    );

    String sql = """
        SELECT os.*, v.placa, c.nome AS cliente
        FROM ordem_servico os
        JOIN veiculo v ON os.veiculo_id = v.id
        JOIN cliente c ON v.cliente_id = c.id
        WHERE os.id = ?
        """;

    try (Connection conex = Conexao.conectar();
         PreparedStatement stmt = conex.prepareStatement(sql)) {

        stmt.setInt(1, id);

        try (ResultSet rs = stmt.executeQuery()) {

            if (!rs.next()) {
                Mensagem.aviso(this, "OS não encontrada.");
                return;
            }

            carregandoOS = true;

            try {
                txtNOS.setText(String.valueOf(id));
                txtPlaca.setText(rs.getString("placa"));
                txtCliente.setText(rs.getString("cliente"));

                int mecanicoId = rs.getInt("mecanico_id");
                int servicoId = rs.getInt("servico_id");

                cbMecanico.setSelectedIndex(
                    idMecanicos.indexOf(mecanicoId)
                );

                cbServico.setSelectedIndex(
                    idServicos.indexOf(servicoId)
                );

                String diagnostico = rs.getString("diagnostico");
                String observacao = rs.getString("observacao");

                txtDiagnostico.setText(
                    diagnostico == null ? "" : diagnostico
                );
                txtObs.setText(
                    observacao == null ? "" : observacao
                );

                cbStatus.setSelectedItem(rs.getString("status"));

                BigDecimal valor =
                    rs.getBigDecimal("valor_cobrado");

                txtValorCobrado.setText(
                    valor == null ? "" : valor.toPlainString()
                );

                DateTimeFormatter formato =
                    DateTimeFormatter.ofPattern("dd/MM/uuuu");

                Timestamp abertura =
                    rs.getTimestamp("data_abertura");

                txtDataAbertura.setText(
                    abertura == null ? ""
                    : abertura.toLocalDateTime()
                        .toLocalDate().format(formato)
                );

                Timestamp conclusao =
                    rs.getTimestamp("data_conclusao");

                txtDataConclusao.setText(
                    conclusao == null ? ""
                    : conclusao.toLocalDateTime()
                        .toLocalDate().format(formato)
                );

            } finally {
                carregandoOS = false;
            }
        }

    } catch (SQLException erro) {
        Mensagem.erro(this,
            "Erro ao carregar OS: " + erro.getMessage());
    }
    }//GEN-LAST:event_tblOSMouseClicked

    private void btnFecharActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFecharActionPerformed
        dispose();
    }//GEN-LAST:event_btnFecharActionPerformed

    private void btnExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExcluirActionPerformed
          int linha = tblOS.getSelectedRow();

    if (linha == -1) {
        JOptionPane.showMessageDialog(this,
                "Selecione uma Ordem de Serviço para excluir!");
        return;
    }

    int linhaModelo = tblOS.convertRowIndexToModel(linha);

    int id = Integer.parseInt(
            tblOS.getModel().getValueAt(linhaModelo, 0).toString());

    int opcao = JOptionPane.showConfirmDialog(
            this,
            "Deseja realmente excluir a OS nº " + id + "?\n"
            + "Essa ação não poderá ser desfeita!",
            "Confirmar Exclusão",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE
    );

    if (opcao != JOptionPane.YES_OPTION) {
        return;
    }

    String sql = "DELETE FROM ordem_servico WHERE id = ?";

    try (Connection conex = Conexao.conectar();
         PreparedStatement stmt = conex.prepareStatement(sql)) {

        stmt.setInt(1, id);

        int linhasAfetadas = stmt.executeUpdate();

        if (linhasAfetadas > 0) {

            JOptionPane.showMessageDialog(this,
                    "Ordem de Serviço excluída com sucesso!");

            atualizarTabela();

        } else {

            JOptionPane.showMessageDialog(this,
                    "Ordem de Serviço não encontrada!");
        }

    } catch (SQLException erro) {

        JOptionPane.showMessageDialog(this,
                "Erro ao excluir OS: " + erro.getMessage());
     } 
    }//GEN-LAST:event_btnExcluirActionPerformed

    private void cbStatusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbStatusActionPerformed
        if (carregandoOS || cbStatus.getSelectedItem() == null) {
        return;
    }

    String status = cbStatus.getSelectedItem().toString();

    if ("CONCLUIDA".equals(status)) {

        String data = txtDataConclusao.getText()
                .replaceAll("\\D", "");

        if (data.isEmpty()) {
            txtDataConclusao.setText(
                LocalDate.now().format(
                    DateTimeFormatter.ofPattern("dd/MM/uuuu")
                )
            );
        }

    } else {
        txtDataConclusao.setText("");
    }
    }//GEN-LAST:event_cbStatusActionPerformed

    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        Estilo.configurarTema();
        java.awt.EventQueue.invokeLater(() -> new FrmConsultaOS().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAlterar;
    private javax.swing.JButton btnAtualizar;
    private javax.swing.JButton btnExcluir;
    private javax.swing.JButton btnFechar;
    private javax.swing.JButton btnLocalizar;
    private javax.swing.JComboBox<String> cbMecanico;
    private javax.swing.JComboBox<String> cbPesquisarPor;
    private javax.swing.JComboBox<String> cbServico;
    private javax.swing.JComboBox<String> cbStatus;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextPane jTextPane1;
    private javax.swing.JTable tblOS;
    private javax.swing.JTextField txtCliente;
    private javax.swing.JFormattedTextField txtDataAbertura;
    private javax.swing.JFormattedTextField txtDataConclusao;
    private javax.swing.JFormattedTextField txtDataFim;
    private javax.swing.JFormattedTextField txtDataInicio;
    private javax.swing.JTextArea txtDiagnostico;
    private javax.swing.JTextField txtNOS;
    private javax.swing.JTextArea txtObs;
    private javax.swing.JTextField txtPesquisar;
    private javax.swing.JTextField txtPlaca;
    private javax.swing.JTextField txtValorCobrado;
    // End of variables declaration//GEN-END:variables
}
