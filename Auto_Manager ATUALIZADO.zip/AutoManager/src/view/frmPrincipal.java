package view;
import com.formdev.flatlaf.FlatDarkLaf;
import javax.swing.UIManager;
import com.formdev.flatlaf.FlatLaf;
import java.awt.Color;
import java.awt.Font;
import javax.swing.SwingUtilities;
import util.Estilo;
import imagens.FrmSobre;
import imagens.FrmAjuda;
import java.awt.Dimension;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import util.Mensagem;


public class frmPrincipal extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(frmPrincipal.class.getName());

        


    
    
    
    
    
    
    
    
    public frmPrincipal() {
        initComponents();

    Estilo.aplicarTela(this);

    setTitle("AutoManager | Painel Principal");
    setSize(1350, 900);
    setResizable(false);
    setLocationRelativeTo(null);

    Estilo.configurarIcone(this);

    criarPainelInicial();
    carregarDashboard();
    }
    
    
    
    private JLabel lblClientesDashboard;
private JLabel lblVeiculosDashboard;
private JLabel lblAbertasDashboard;
private JLabel lblConcluidasDashboard;
private JTable tabelaRecentes;

private void criarPainelInicial() {

    JPanel raiz = new JPanel(new BorderLayout());
    raiz.setBackground(Estilo.FUNDO);
    
    // PAINEL LATERAL
JPanel lateral = new JPanel(new BorderLayout());
lateral.setBackground(new Color(24, 28, 36));
lateral.setPreferredSize(new Dimension(255, 0));
lateral.setBorder(new EmptyBorder(25, 18, 20, 18));
    
    JPanel navegacao = new JPanel();
navegacao.setOpaque(false);
navegacao.setLayout(
    new BoxLayout(navegacao, BoxLayout.Y_AXIS)
);
JLabel logo = new JLabel(Estilo.carregarLogo(210, 75));
logo.setAlignmentX(Component.LEFT_ALIGNMENT);

JLabel versao = new JLabel("WORKSHOP MANAGEMENT");
versao.setForeground(Estilo.TEXTO_SECUNDARIO);
versao.setFont(new Font("Segoe UI", Font.BOLD, 10));
versao.setAlignmentX(Component.LEFT_ALIGNMENT);

navegacao.add(logo);
navegacao.add(Box.createVerticalStrut(5));
navegacao.add(versao);
navegacao.add(Box.createVerticalStrut(35));

navegacao.add(criarTituloMenu("MENU PRINCIPAL"));
navegacao.add(Box.createVerticalStrut(12));

    // MENU LATERAL
    navegacao.add(criarBotaoLateral(
    "dashboard.png", "Visão geral", null, true
));
navegacao.add(Box.createVerticalStrut(8));

navegacao.add(criarBotaoLateral(
    "cliente.png", "Novo cliente", menuCadClientes, false
));
navegacao.add(Box.createVerticalStrut(8));

navegacao.add(criarBotaoLateral(
    "veiculo.png", "Veículos", menuConsVeiculos, false
));
navegacao.add(Box.createVerticalStrut(8));

navegacao.add(criarBotaoLateral(
    "mecanico.png", "Mecânicos", menuConsMecanicos, false
));
navegacao.add(Box.createVerticalStrut(8));

navegacao.add(criarBotaoLateral(
    "servico.png", "Serviços", menuConsServicos, false
));
navegacao.add(Box.createVerticalStrut(8));

navegacao.add(criarBotaoLateral(
    "abrir_os.png", "Ordens de serviço", menuConsOS, false
));
navegacao.add(Box.createVerticalStrut(30));

navegacao.add(criarTituloMenu("GERENCIAMENTO"));
navegacao.add(Box.createVerticalStrut(12));

navegacao.add(criarBotaoLateral(
    "relatorio.png", "Relatórios de OS", menuRelOS, false
));
navegacao.add(Box.createVerticalStrut(8));

navegacao.add(criarBotaoLateral(
    "ajuda.png", "Ajuda", menuAjudaSistema, false
));
navegacao.add(Box.createVerticalStrut(8));

// ADICIONAR NAVEGAÇÃO AO MENU LATERAL
lateral.add(navegacao, BorderLayout.NORTH);

// BOTÃO SAIR
JButton sair = criarBotaoLateral(
    "sair.png", "Encerrar sistema", null, false
);

sair.addActionListener(e -> confirmarSaida());
lateral.add(sair, BorderLayout.SOUTH);

// ADICIONAR MENU LATERAL À JANELA
raiz.add(lateral, BorderLayout.WEST);
    // ÁREA CENTRAL
    JPanel conteudo = new JPanel(new BorderLayout(0, 20));
    conteudo.setBackground(Estilo.FUNDO);
    conteudo.setBorder(new EmptyBorder(28, 30, 25, 30));

    JPanel cabecalho = new JPanel(new BorderLayout());
    cabecalho.setOpaque(false);

    JPanel textos = new JPanel();
    textos.setOpaque(false);
    textos.setLayout(new BoxLayout(textos, BoxLayout.Y_AXIS));

    JLabel titulo = new JLabel("Visão geral da oficina");
    titulo.setFont(new Font("Segoe UI", Font.BOLD, 29));
    titulo.setForeground(Estilo.TEXTO);

    JLabel subtitulo = new JLabel(
        "Acompanhe os principais dados e atividades do AutoManager."
    );
    subtitulo.setFont(new Font("Segoe UI", Font.PLAIN, 14));
    subtitulo.setForeground(Estilo.TEXTO_SECUNDARIO);

    textos.add(titulo);
    textos.add(Box.createVerticalStrut(7));
    textos.add(subtitulo);

    cabecalho.add(textos, BorderLayout.WEST);

    JButton atualizar = new JButton("↻  ATUALIZAR");
    Estilo.configurarBotao(atualizar, "cinza");
    atualizar.setPreferredSize(new Dimension(155, 43));
    atualizar.addActionListener(e -> carregarDashboard());

    cabecalho.add(atualizar, BorderLayout.EAST);
    conteudo.add(cabecalho, BorderLayout.NORTH);

    // ÁREA DO DASHBOARD
    JPanel dashboard = new JPanel(new BorderLayout(0, 20));
    dashboard.setOpaque(false);

    // CARDS DE INDICADORES
    JPanel indicadores = new JPanel(
        new GridLayout(1, 4, 14, 0)
    );
    indicadores.setOpaque(false);

    lblClientesDashboard = criarValorDashboard();
    lblVeiculosDashboard = criarValorDashboard();
    lblAbertasDashboard = criarValorDashboard();
    lblConcluidasDashboard = criarValorDashboard();

    indicadores.add(criarCardDashboard(
        "CLIENTES CADASTRADOS", lblClientesDashboard,
        new Color(249, 115, 22), "♙"
    ));

    indicadores.add(criarCardDashboard(
        "VEÍCULOS CADASTRADOS", lblVeiculosDashboard,
        new Color(96, 165, 250), "▣"
    ));

    indicadores.add(criarCardDashboard(
        "ORDENS ABERTAS", lblAbertasDashboard,
        new Color(251, 191, 36), "≡"
    ));

    indicadores.add(criarCardDashboard(
        "OS CONCLUÍDAS", lblConcluidasDashboard,
        new Color(74, 222, 128), "✓"
    ));

    indicadores.setPreferredSize(new Dimension(0, 132));
    dashboard.add(indicadores, BorderLayout.NORTH);

    // ÁREA CENTRAL COM TABELA
    JPanel centro = new JPanel(new BorderLayout(0, 18));
    centro.setOpaque(false);

    JPanel painelTabela = criarPainelDashboard();
    painelTabela.setLayout(new BorderLayout(0, 15));

    JPanel topoTabela = new JPanel(new BorderLayout());
    topoTabela.setOpaque(false);

    JLabel tituloTabela = new JLabel("Ordens de serviço recentes");
    tituloTabela.setFont(new Font("Segoe UI", Font.BOLD, 19));
    tituloTabela.setForeground(Estilo.TEXTO);

    JButton verTodas = new JButton("VER TODAS");
    Estilo.configurarBotao(verTodas, "cinza");
    verTodas.setPreferredSize(new Dimension(125, 37));
    verTodas.addActionListener(e -> menuConsOS.doClick());

    topoTabela.add(tituloTabela, BorderLayout.WEST);
    topoTabela.add(verTodas, BorderLayout.EAST);

    painelTabela.add(topoTabela, BorderLayout.NORTH);

    tabelaRecentes = new JTable(new DefaultTableModel(
        new Object[][] {},
        new String[]{
            "Nº OS", "Placa", "Cliente",
            "Serviço", "Status", "Abertura"
        }
    ) {
        @Override
        public boolean isCellEditable(int linha, int coluna) {
            return false;
        }
    });

    Estilo.configurarTabela(tabelaRecentes);
    tabelaRecentes.setRowHeight(43);
    tabelaRecentes.setShowGrid(false);
    tabelaRecentes.setFillsViewportHeight(true);
    tabelaRecentes.setSelectionMode(
        ListSelectionModel.SINGLE_SELECTION
    );

    tabelaRecentes.getTableHeader().setReorderingAllowed(false);
    tabelaRecentes.getTableHeader().setPreferredSize(
        new Dimension(0, 43)
    );

    tabelaRecentes.setDefaultRenderer(
        Object.class, new RenderizadorDashboard()
    );

    tabelaRecentes.setAutoResizeMode(
        JTable.AUTO_RESIZE_OFF
    );

    int[] larguras = {65, 105, 185, 205, 145, 150};

    for (int i = 0; i < larguras.length; i++) {
        tabelaRecentes.getColumnModel()
            .getColumn(i).setPreferredWidth(larguras[i]);
    }

    JScrollPane rolagem = new JScrollPane(tabelaRecentes);
    rolagem.setBorder(null);
    rolagem.getViewport().setBackground(Estilo.PAINEL);

    painelTabela.add(rolagem, BorderLayout.CENTER);
    centro.add(painelTabela, BorderLayout.CENTER);

    // ACESSOS RÁPIDOS
    JPanel acessos = criarPainelDashboard();
    acessos.setLayout(new BorderLayout(0, 15));

    JLabel tituloAcessos = new JLabel("Acesso rápido");
    tituloAcessos.setFont(new Font("Segoe UI", Font.BOLD, 19));
    tituloAcessos.setForeground(Estilo.TEXTO);

    acessos.add(tituloAcessos, BorderLayout.NORTH);

    JPanel botoes = new JPanel(
        new GridLayout(1, 4, 12, 0)
    );
    botoes.setOpaque(false);

    botoes.add(criarAcessoRapido(
        "abrir_os.png", "ABRIR OS", menuCadOS
    ));
    botoes.add(criarAcessoRapido(
        "cliente.png", "NOVO CLIENTE", menuCadClientes
    ));
    botoes.add(criarAcessoRapido(
        "veiculo.png", "CADASTRAR VEÍCULO", menuCadVeiculos
    ));
    botoes.add(criarAcessoRapido(
        "relatorio.png", "RELATÓRIOS", menuRelOS
    ));

    acessos.add(botoes, BorderLayout.CENTER);
    acessos.setPreferredSize(new Dimension(0, 135));

    centro.add(acessos, BorderLayout.SOUTH);
    dashboard.add(centro, BorderLayout.CENTER);

    conteudo.add(dashboard, BorderLayout.CENTER);

    // RODAPÉ
    JPanel rodape = new JPanel(new BorderLayout());
    rodape.setOpaque(false);

    JLabel status = new JLabel("●  AutoManager");
    status.setForeground(Estilo.VERDE);
    status.setFont(new Font("Segoe UI", Font.BOLD, 12));

    JLabel rodapeDireita = new JLabel(
        "Sistema de gerenciamento de oficinas"
    );
    rodapeDireita.setForeground(Estilo.TEXTO_SECUNDARIO);

    rodape.add(status, BorderLayout.WEST);
    rodape.add(rodapeDireita, BorderLayout.EAST);

    conteudo.add(rodape, BorderLayout.SOUTH);

    raiz.add(conteudo, BorderLayout.CENTER);

    setContentPane(raiz);
    revalidate();
    repaint();
}

private JPanel criarPainelDashboard() {
    JPanel painel = new JPanel();
    painel.setBackground(Estilo.PAINEL);
    painel.setBorder(new EmptyBorder(18, 20, 18, 20));
    return painel;
}

private JLabel criarValorDashboard() {
    JLabel label = new JLabel("—");
    label.setFont(new Font("Segoe UI", Font.BOLD, 34));
    label.setForeground(Estilo.TEXTO);
    return label;
}

private JPanel criarCardDashboard(
        String titulo, JLabel valor, Color cor, String simbolo) {

    JPanel card = criarPainelDashboard();
    card.setLayout(new BorderLayout(0, 12));

    JPanel superior = new JPanel(new BorderLayout());
    superior.setOpaque(false);

    JLabel texto = new JLabel(titulo);
    texto.setFont(new Font("Segoe UI", Font.BOLD, 11));
    texto.setForeground(Estilo.TEXTO_SECUNDARIO);

    JLabel icone = new JLabel(simbolo);
    icone.setFont(new Font("Segoe UI Symbol", Font.BOLD, 22));
    icone.setForeground(cor);

    superior.add(texto, BorderLayout.WEST);
    superior.add(icone, BorderLayout.EAST);

    card.add(superior, BorderLayout.NORTH);
    card.add(valor, BorderLayout.CENTER);

    JPanel detalhe = new JPanel();
    detalhe.setBackground(cor);
    detalhe.setPreferredSize(new Dimension(0, 3));

    card.add(detalhe, BorderLayout.SOUTH);

    return card;
}

private JLabel criarTituloMenu(String texto) {
    JLabel label = new JLabel(texto);
    label.setForeground(Estilo.TEXTO_SECUNDARIO);
    label.setFont(new Font("Segoe UI", Font.BOLD, 11));
    label.setAlignmentX(Component.LEFT_ALIGNMENT);
    return label;
}

private JButton criarBotaoLateral(
         String nomeImagem,
        String texto,
        JMenuItem destino,
        boolean selecionado) {

    JButton botao = new JButton(texto);

    botao.setHorizontalAlignment(SwingConstants.LEFT);
    botao.setFont(new Font("Segoe UI", Font.BOLD, 13));

    botao.setForeground(
        selecionado ? Estilo.LARANJA : Estilo.TEXTO
    );

    botao.setBackground(
        selecionado
            ? new Color(58, 44, 38)
            : new Color(24, 28, 36)
    );

    botao.setBorder(new EmptyBorder(12, 14, 12, 14));
    botao.setFocusPainted(false);
    botao.setOpaque(true);

    botao.setCursor(
        Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)
    );

    botao.setMaximumSize(
        new Dimension(Integer.MAX_VALUE, 45)
    );

    botao.setAlignmentX(Component.LEFT_ALIGNMENT);

    // CARREGAR PNG
    java.net.URL caminho = getClass().getResource(
        "/imagens/" + nomeImagem
    );

    if (caminho != null) {
        ImageIcon imagem = new ImageIcon(caminho);

        Image redimensionada = imagem.getImage()
            .getScaledInstance(
                22, 22, Image.SCALE_SMOOTH
            );

        botao.setIcon(new ImageIcon(redimensionada));
    } else {
        System.err.println(
            "Ícone lateral não encontrado: " + nomeImagem
        );
    }

    botao.setIconTextGap(14);
    botao.setHorizontalTextPosition(SwingConstants.RIGHT);
    botao.setVerticalAlignment(SwingConstants.CENTER);

    if (destino != null) {
        botao.addActionListener(e -> destino.doClick());
    }

    return botao;

}

private JButton criarAcessoRapido(
        String nomeImagem, String texto, JMenuItem destino) {

    JButton botao = new JButton(texto);

    Estilo.configurarBotao(botao, "cinza");

    botao.setText(texto);
    botao.setFont(new Font("Segoe UI", Font.BOLD, 12));
    botao.setForeground(Color.WHITE);
    botao.setCursor(
        Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)
    );

    // CARREGAR O PNG
    java.net.URL caminho = getClass().getResource(
        "/imagens/" + nomeImagem
    );

    if (caminho != null) {
        ImageIcon imagem = new ImageIcon(caminho);

        Image redimensionada = imagem.getImage()
            .getScaledInstance(
                30, 30, Image.SCALE_SMOOTH
            );

        botao.setIcon(new ImageIcon(redimensionada));
    } else {
        System.err.println(
            "ERRO: imagem não encontrada: /imagens/" + nomeImagem
        );
    }

    botao.setHorizontalAlignment(SwingConstants.CENTER);
    botao.setVerticalAlignment(SwingConstants.CENTER);
    botao.setHorizontalTextPosition(SwingConstants.RIGHT);
    botao.setIconTextGap(12);

    botao.addActionListener(e -> destino.doClick());

    return botao;
}

private class RenderizadorDashboard
        extends DefaultTableCellRenderer {

    @Override
    public Component getTableCellRendererComponent(
            JTable tabela, Object valor,
            boolean selecionado, boolean foco,
            int linha, int coluna) {

        super.getTableCellRendererComponent(
            tabela,
            valor == null ? "" : valor,
            selecionado, foco, linha, coluna
        );

        setBorder(new EmptyBorder(0, 12, 0, 12));

        if (selecionado) {
            setBackground(new Color(124, 62, 29));
            setForeground(Color.WHITE);
        } else {
            setBackground(
                linha % 2 == 0
                    ? Estilo.PAINEL
                    : new Color(40, 46, 57)
            );

            if (coluna == 4 && valor != null) {
                switch (valor.toString()) {
                    case "CONCLUIDA" ->
                        setForeground(Estilo.VERDE);

                    case "CANCELADA" ->
                        setForeground(Estilo.VERMELHO);

                    case "EM_ANDAMENTO" ->
                        setForeground(new Color(251, 191, 36));

                    case "ABERTA" ->
                        setForeground(new Color(96, 165, 250));

                    default ->
                        setForeground(Estilo.TEXTO);
                }
            } else {
                setForeground(Estilo.TEXTO);
            }
        }

        return this;
    }
}

private void carregarDashboard() {

    String sqlIndicadores = """
        SELECT
            (SELECT COUNT(*) FROM cliente) AS clientes,
            (SELECT COUNT(*) FROM veiculo) AS veiculos,
            (SELECT COUNT(*) FROM ordem_servico
             WHERE status = 'ABERTA') AS abertas,
            (SELECT COUNT(*) FROM ordem_servico
             WHERE status = 'CONCLUIDA') AS concluidas
        """;

    String sqlRecentes = """
        SELECT
            os.id,
            v.placa,
            c.nome AS cliente,
            s.descricao AS servico,
            os.status,
            os.data_abertura
        FROM ordem_servico os
        JOIN veiculo v ON os.veiculo_id = v.id
        JOIN cliente c ON v.cliente_id = c.id
        JOIN servico s ON os.servico_id = s.id
        ORDER BY os.data_abertura DESC, os.id DESC
        LIMIT 8
        """;

    try (Connection conex = Conexao.conectar()) {

        // INDICADORES
        try (PreparedStatement stmt =
                conex.prepareStatement(sqlIndicadores);
             ResultSet rs = stmt.executeQuery()) {

            if (rs.next()) {
                lblClientesDashboard.setText(
                    rs.getString("clientes")
                );

                lblVeiculosDashboard.setText(
                    rs.getString("veiculos")
                );

                lblAbertasDashboard.setText(
                    rs.getString("abertas")
                );

                lblConcluidasDashboard.setText(
                    rs.getString("concluidas")
                );
            }
        }

        // ORDENS RECENTES
        DefaultTableModel modelo =
            (DefaultTableModel) tabelaRecentes.getModel();

        modelo.setRowCount(0);

        java.time.format.DateTimeFormatter formato =
            java.time.format.DateTimeFormatter.ofPattern(
                "dd/MM/yyyy HH:mm"
            );

        try (PreparedStatement stmt =
                conex.prepareStatement(sqlRecentes);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {

                java.sql.Timestamp data =
                    rs.getTimestamp("data_abertura");

                String dataFormatada = data == null
                    ? ""
                    : data.toLocalDateTime().format(formato);

                modelo.addRow(new Object[]{
                    rs.getInt("id"),
                    rs.getString("placa"),
                    rs.getString("cliente"),
                    rs.getString("servico"),
                    rs.getString("status"),
                    dataFormatada
                });
            }
        }

    } catch (SQLException erro) {
        Mensagem.erro(this,
            "Erro ao carregar o painel: "
            + erro.getMessage());
    }
}


private void confirmarSaida() {
    int resposta = JOptionPane.showConfirmDialog(
        this,
        "Deseja realmente sair do AutoManager?",
        "Confirmar saída",
        JOptionPane.YES_NO_OPTION,
        JOptionPane.QUESTION_MESSAGE
    );

    if (resposta == JOptionPane.YES_OPTION) {
        System.exit(0);
    }
}







    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        menuCadClientes = new javax.swing.JMenuItem();
        menuCadVeiculos = new javax.swing.JMenuItem();
        menuCadMecanicos = new javax.swing.JMenuItem();
        menuCadServicos = new javax.swing.JMenuItem();
        menuCadOS = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        menuConsClientes = new javax.swing.JMenuItem();
        menuConsVeiculos = new javax.swing.JMenuItem();
        menuConsMecanicos = new javax.swing.JMenuItem();
        menuConsServicos = new javax.swing.JMenuItem();
        menuConsOS = new javax.swing.JMenuItem();
        jMenu3 = new javax.swing.JMenu();
        menuRelClientes = new javax.swing.JMenuItem();
        menuRelVeiculos = new javax.swing.JMenuItem();
        menuRelMecanicos = new javax.swing.JMenuItem();
        menuRelServicos = new javax.swing.JMenuItem();
        menuRelOS = new javax.swing.JMenuItem();
        jMenu4 = new javax.swing.JMenu();
        menuSobreAM = new javax.swing.JMenuItem();
        jMenu5 = new javax.swing.JMenu();
        menuAjudaSistema = new javax.swing.JMenuItem();
        jMenu6 = new javax.swing.JMenu();
        menuSairSistema = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 0, 51));

        jButton1.setText("jButton1");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(67, 67, 67)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(829, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(270, Short.MAX_VALUE))
        );

        jMenu1.setText("Cadastro");

        menuCadClientes.setText("Clientes");
        menuCadClientes.addActionListener(this::menuCadClientesActionPerformed);
        jMenu1.add(menuCadClientes);

        menuCadVeiculos.setText("Veículos");
        menuCadVeiculos.addActionListener(this::menuCadVeiculosActionPerformed);
        jMenu1.add(menuCadVeiculos);

        menuCadMecanicos.setText("Mecânicos");
        menuCadMecanicos.addActionListener(this::menuCadMecanicosActionPerformed);
        jMenu1.add(menuCadMecanicos);

        menuCadServicos.setText("Serviços");
        menuCadServicos.addActionListener(this::menuCadServicosActionPerformed);
        jMenu1.add(menuCadServicos);

        menuCadOS.setText("Abrir Ordem de Serviço");
        menuCadOS.addActionListener(this::menuCadOSActionPerformed);
        jMenu1.add(menuCadOS);

        jMenuBar1.add(jMenu1);

        jMenu2.setText("Consulta");
        jMenu2.addActionListener(this::jMenu2ActionPerformed);

        menuConsClientes.setText("Clientes");
        menuConsClientes.addActionListener(this::menuConsClientesActionPerformed);
        jMenu2.add(menuConsClientes);

        menuConsVeiculos.setText("Veículos");
        menuConsVeiculos.addActionListener(this::menuConsVeiculosActionPerformed);
        jMenu2.add(menuConsVeiculos);

        menuConsMecanicos.setText("Mecânicos");
        menuConsMecanicos.addActionListener(this::menuConsMecanicosActionPerformed);
        jMenu2.add(menuConsMecanicos);

        menuConsServicos.setText("Serviços");
        menuConsServicos.addActionListener(this::menuConsServicosActionPerformed);
        jMenu2.add(menuConsServicos);

        menuConsOS.setText("Ordens de Serviço");
        menuConsOS.addActionListener(this::menuConsOSActionPerformed);
        jMenu2.add(menuConsOS);

        jMenuBar1.add(jMenu2);

        jMenu3.setText("Relatório");

        menuRelClientes.setText("Clientes");
        menuRelClientes.addActionListener(this::menuRelClientesActionPerformed);
        jMenu3.add(menuRelClientes);

        menuRelVeiculos.setText("Veículos");
        menuRelVeiculos.addActionListener(this::menuRelVeiculosActionPerformed);
        jMenu3.add(menuRelVeiculos);

        menuRelMecanicos.setText("Mecânicos");
        menuRelMecanicos.addActionListener(this::menuRelMecanicosActionPerformed);
        jMenu3.add(menuRelMecanicos);

        menuRelServicos.setText("Serviços");
        menuRelServicos.addActionListener(this::menuRelServicosActionPerformed);
        jMenu3.add(menuRelServicos);

        menuRelOS.setText("Ordens de Serviço");
        menuRelOS.addActionListener(this::menuRelOSActionPerformed);
        jMenu3.add(menuRelOS);

        jMenuBar1.add(jMenu3);

        jMenu4.setText("Sobre");

        menuSobreAM.setText("Sobre o AutoManager");
        menuSobreAM.addActionListener(this::menuSobreAMActionPerformed);
        jMenu4.add(menuSobreAM);

        jMenuBar1.add(jMenu4);

        jMenu5.setText("Ajuda");

        menuAjudaSistema.setText("Como Utilizar o Sistema");
        menuAjudaSistema.addActionListener(this::menuAjudaSistemaActionPerformed);
        jMenu5.add(menuAjudaSistema);

        jMenuBar1.add(jMenu5);

        jMenu6.setText("Sair");
        jMenu6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu6MouseClicked(evt);
            }
        });
        jMenu6.addActionListener(this::jMenu6ActionPerformed);

        menuSairSistema.setText("Encerrar Sistema");
        jMenu6.add(menuSairSistema);

        jMenuBar1.add(jMenu6);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 195, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void menuCadClientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuCadClientesActionPerformed
       FrmCadastroCliente tela2 = new FrmCadastroCliente();
       tela2.setVisible(true);
       
    }//GEN-LAST:event_menuCadClientesActionPerformed

    private void menuConsMecanicosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuConsMecanicosActionPerformed
        FrmConsultaMecanico tela9 = new FrmConsultaMecanico();
        tela9.setVisible(true);
    }//GEN-LAST:event_menuConsMecanicosActionPerformed

    private void menuRelVeiculosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuRelVeiculosActionPerformed
        FrmRelatorioVeiculos tela13 = new FrmRelatorioVeiculos();
        tela13.setVisible(true);
    }//GEN-LAST:event_menuRelVeiculosActionPerformed

    private void menuCadVeiculosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuCadVeiculosActionPerformed
        FrmCadastroVeiculo tela3 = new FrmCadastroVeiculo();
        tela3.setVisible(true);
    }//GEN-LAST:event_menuCadVeiculosActionPerformed

    private void menuCadMecanicosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuCadMecanicosActionPerformed
        FrmCadastroMecanico tela4 = new FrmCadastroMecanico();
        tela4.setVisible(true);
    }//GEN-LAST:event_menuCadMecanicosActionPerformed

    private void menuCadServicosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuCadServicosActionPerformed
        FrmCadastroServico tela5 = new FrmCadastroServico();
        tela5.setVisible(true);
    }//GEN-LAST:event_menuCadServicosActionPerformed

    private void menuCadOSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuCadOSActionPerformed
        FrmCadastroOS tela6 = new FrmCadastroOS();
        tela6.setVisible(true);
    }//GEN-LAST:event_menuCadOSActionPerformed

    private void menuConsClientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuConsClientesActionPerformed
        FrmConsultaCliente tela7 = new FrmConsultaCliente();
        tela7.setVisible(true);
    }//GEN-LAST:event_menuConsClientesActionPerformed

    private void jMenu2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenu2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jMenu2ActionPerformed

    private void menuConsVeiculosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuConsVeiculosActionPerformed
        FrmConsultaVeiculo tela8 = new FrmConsultaVeiculo();
        tela8.setVisible(true);
    }//GEN-LAST:event_menuConsVeiculosActionPerformed

    private void menuConsServicosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuConsServicosActionPerformed
        FrmConsultaServico tela10 = new FrmConsultaServico();
        tela10.setVisible(true);
    }//GEN-LAST:event_menuConsServicosActionPerformed

    private void menuConsOSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuConsOSActionPerformed
        FrmConsultaOS tela11 = new FrmConsultaOS();
        tela11.setVisible(true);
        
    }//GEN-LAST:event_menuConsOSActionPerformed

    private void menuRelClientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuRelClientesActionPerformed
        FrmRelatorioClientes tela12 = new FrmRelatorioClientes();
        tela12.setVisible(true);
    }//GEN-LAST:event_menuRelClientesActionPerformed

    private void menuRelMecanicosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuRelMecanicosActionPerformed
        FrmRelatorioMecanicos tela14 = new FrmRelatorioMecanicos();
        tela14.setVisible(true);
    }//GEN-LAST:event_menuRelMecanicosActionPerformed

    private void menuRelServicosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuRelServicosActionPerformed
        FrmRelatorioServicos tela15 = new FrmRelatorioServicos();
        tela15.setVisible(true);
    }//GEN-LAST:event_menuRelServicosActionPerformed

    private void menuRelOSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuRelOSActionPerformed
        FrmRelatorioOS tela16 = new FrmRelatorioOS();
        tela16.setVisible(true);
    }//GEN-LAST:event_menuRelOSActionPerformed

    private void menuSobreAMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuSobreAMActionPerformed
        FrmSobre tela17 = new FrmSobre();
        tela17.setVisible(true);
    }//GEN-LAST:event_menuSobreAMActionPerformed

    private void menuAjudaSistemaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuAjudaSistemaActionPerformed
        FrmAjuda tela18 = new FrmAjuda();
        tela18.setVisible(true);
    }//GEN-LAST:event_menuAjudaSistemaActionPerformed

    private void jMenu6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu6MouseClicked
       int resposta = JOptionPane.showConfirmDialog(
    this,
    "Deseja realmente sair do AutoManager?",
    "Confirmar saída",
    JOptionPane.YES_NO_OPTION,
    JOptionPane.QUESTION_MESSAGE
);

if (resposta == JOptionPane.YES_OPTION) {
    System.exit(0);
} 
    }//GEN-LAST:event_jMenu6MouseClicked

    private void jMenu6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenu6ActionPerformed
        confirmarSaida();
    }//GEN-LAST:event_jMenu6ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        
         Estilo.configurarTema();

        java.awt.EventQueue.invokeLater(() -> {

        frmPrincipal menu = new frmPrincipal();
        menu.setLocationRelativeTo(null);
        menu.setVisible(true);
    });
    
        
        
      //  java.awt.EventQueue.invokeLater(() -> new frmPrincipal().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenu jMenu5;
    private javax.swing.JMenu jMenu6;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JMenuItem menuAjudaSistema;
    private javax.swing.JMenuItem menuCadClientes;
    private javax.swing.JMenuItem menuCadMecanicos;
    private javax.swing.JMenuItem menuCadOS;
    private javax.swing.JMenuItem menuCadServicos;
    private javax.swing.JMenuItem menuCadVeiculos;
    private javax.swing.JMenuItem menuConsClientes;
    private javax.swing.JMenuItem menuConsMecanicos;
    private javax.swing.JMenuItem menuConsOS;
    private javax.swing.JMenuItem menuConsServicos;
    private javax.swing.JMenuItem menuConsVeiculos;
    private javax.swing.JMenuItem menuRelClientes;
    private javax.swing.JMenuItem menuRelMecanicos;
    private javax.swing.JMenuItem menuRelOS;
    private javax.swing.JMenuItem menuRelServicos;
    private javax.swing.JMenuItem menuRelVeiculos;
    private javax.swing.JMenuItem menuSairSistema;
    private javax.swing.JMenuItem menuSobreAM;
    // End of variables declaration//GEN-END:variables
}
