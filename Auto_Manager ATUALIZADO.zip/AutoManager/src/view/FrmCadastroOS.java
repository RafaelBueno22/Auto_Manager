package view;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import conexao.Conexao;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import util.Estilo;
import util.Mensagem;
import util.BordaArredondada;

public class FrmCadastroOS extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(FrmCadastroOS.class.getName());

        private ArrayList<Integer> idVeiculos = new ArrayList<>();
        private ArrayList<Integer> idMecanicos = new ArrayList<>();
        private ArrayList<Integer> idServicos = new ArrayList<>();
        private ArrayList<BigDecimal> valoresServicos = new ArrayList<>();
        
        private void limparCampos(){
                
            txtPesquisarVeiculo.setText("");
            txtPesquisarMecanico.setText("");
            txtPesquisarServico.setText("");
            carregarVeiculos("");
            carregarMecanicos("");
            carregarServicos("");
            cbVeiculo.setSelectedIndex(-1);
            cbMecanico.setSelectedIndex(-1);
            cbServico.setSelectedIndex(-1);
            txtDescricao.setText("");
            txtDiagnostico.setText("");
            txtValorCobrado.setText("");
            txtObservacao.setText("");
            txtNumeroOS.setText("");
txtDataAbertura.setText("");
txtDataConclusao.setText("");
txtStatus.setText("ABERTA");
            txtDescricao.requestFocus();

        }
                
        
        private void carregarServicos(String pesquisa){
            String sql = """
                         SELECT id, descricao, valor_base
                         FROM servico
                         WHERE ativo = TRUE
                         AND (
                         ? = ''
                         OR (? = TRUE AND CAST(id AS TEXT) = ?)
                         OR (? = FALSE AND descricao ILIKE ?)
                         )
                         ORDER BY id
                         """;
            
            cbServico.removeAllItems();
            idServicos.clear();
            valoresServicos.clear();
            
            try (
                 Connection conex = Conexao.conectar();
                 PreparedStatement stmt = conex.prepareStatement(sql);
                    ){
                boolean pesquisaId = pesquisa.matches("\\d+");

                stmt.setString(1, pesquisa);
                stmt.setBoolean(2, pesquisaId);
                stmt.setString(3, pesquisa);
                stmt.setBoolean(4, pesquisaId);
                stmt.setString(5, "%" + pesquisa + "%");

              try (ResultSet rs = stmt.executeQuery()) {
                  
                      while (rs.next()) {

                      int id = rs.getInt("id");
                      String descricao = rs.getString("descricao");
                      BigDecimal valorBase = rs.getBigDecimal("valor_base");
                      
                   
                      cbServico.addItem("ID: " +id+ " - " +descricao+ " - R$ " +valorBase);

                        idServicos.add(id);
                        valoresServicos.add(valorBase);
            }
        }

        if (cbServico.getItemCount() == 1) {
    cbServico.setSelectedIndex(0);
} else {
    cbServico.setSelectedIndex(-1);
}
        
            } catch (SQLException erro) {
                JOptionPane.showMessageDialog(this, "Erro ao pesquisar serviços: " + erro.getMessage());
            }
        }
        
        
        private void carregarMecanicos(String pesquisa){
            String sql = """
                         SELECT id, nome, especialidade
                         FROM mecanico
                         WHERE ativo = TRUE
                         AND(
                            ? = ''
                            OR (? = TRUE AND CAST (id AS TEXT) = ?)
                            OR (? = FALSE AND nome ILIKE ? )
                        )
                        ORDER BY id
                         
                         """;
            
            cbMecanico.removeAllItems();
            idMecanicos.clear();
            
            try (
                 Connection conex = Conexao.conectar();
                 PreparedStatement stmt = conex.prepareStatement(sql)
                    ){
                boolean pesquisaId = pesquisa.matches("\\d+");

                stmt.setString(1, pesquisa);
                stmt.setBoolean(2, pesquisaId);
                stmt.setString(3, pesquisa);
                stmt.setBoolean(4, pesquisaId);
                stmt.setString(5, "%" + pesquisa + "%");
                
                
                try(ResultSet rs = stmt.executeQuery()){
                    while(rs.next()){
                        int id = rs.getInt("id");
                        String nome = rs.getString("nome");
                        String especialidade = rs.getString("especialidade");
                        
                       
                        cbMecanico.addItem("ID: " +id+ " - " +nome+ " - " +especialidade);
                        
                        idMecanicos.add(id);
                    }       
                
                    }
                if (cbMecanico.getItemCount() == 1) {
    cbMecanico.setSelectedIndex(0);
} else {
    cbMecanico.setSelectedIndex(-1);
}
            } catch (SQLException erro) {
                JOptionPane.showMessageDialog(this, "Erro ao pesquisar mecanicos: " + erro.getMessage());
            }
            
        }
                
        private void carregarVeiculos(String pesquisa){
            String sql = """
                         SELECT id, placa, marca, modelo
                             FROM veiculo
                             WHERE ativo = TRUE
                             AND (
                                 ? = ''
                                 OR (? = TRUE AND CAST(id AS TEXT) = ?)
                                 OR (? = FALSE AND (placa ILIKE ? OR modelo ILIKE ?))
                             )
                             ORDER BY id
                             """;
            
            cbVeiculo.removeAllItems();
            idVeiculos.clear();
            
            try (Connection conex = Conexao.conectar();
                 PreparedStatement stmt = conex.prepareStatement(sql) ){
                
                boolean pesquisaId = pesquisa.matches("\\d+");

                stmt.setString(1, pesquisa);
                stmt.setBoolean(2, pesquisaId);
                stmt.setString(3, pesquisa);
                stmt.setBoolean(4, pesquisaId);
                stmt.setString(5, "%" + pesquisa + "%");
                stmt.setString(6, "%" + pesquisa + "%");
                
                try(ResultSet rs = stmt.executeQuery()){
                
                    while(rs.next()){
                        int id = rs.getInt("id");
                        String placa = rs.getString("placa");
                        String marca = rs.getString("marca");
                        String modelo = rs.getString("modelo");
                        
                        cbVeiculo.addItem("ID: " +id+ " - " +placa+ " - " +marca+ " - " +modelo);
                        
                        idVeiculos.add(id);
                    }
                }
                
                if (cbVeiculo.getItemCount() == 1) {
    cbVeiculo.setSelectedIndex(0);
} else {
    cbVeiculo.setSelectedIndex(-1);
}
                
            } catch (SQLException erro) {
                JOptionPane.showMessageDialog(this, "Erro ao pesquisar veículos: " + erro.getMessage());
            }
        }
        
    public FrmCadastroOS() {
        initComponents();
            criarInterface();

        
        carregarVeiculos("");
        carregarMecanicos("");
        carregarServicos("");
    }
    
    
private void criarInterface() {

    setTitle("AutoManager | Ordem de Serviço");
    setSize(1100, 780);
    setMinimumSize(new Dimension(900, 650));
    setLocationRelativeTo(null);

    Estilo.configurarIcone(this);

    JPanel principal = new JPanel(new BorderLayout(0, 16));
    principal.setBackground(Estilo.FUNDO);
    principal.setBorder(new EmptyBorder(22, 32, 22, 32));

    // CABEÇALHO
    JPanel cabecalho = new JPanel(new BorderLayout());
    cabecalho.setOpaque(false);

    cabecalho.add(
        new JLabel(Estilo.carregarLogo(280, 94)),
        BorderLayout.WEST
    );

    JLabel secao = new JLabel("ORDENS DE SERVIÇO / 05");
    secao.setForeground(Estilo.LARANJA);
    secao.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 15));
    cabecalho.add(secao, BorderLayout.EAST);

    JPanel topo = new JPanel(new BorderLayout(0, 12));
    topo.setOpaque(false);
    topo.add(cabecalho, BorderLayout.CENTER);

    JPanel linha = new JPanel();
    linha.setBackground(Estilo.LARANJA);
    linha.setPreferredSize(new Dimension(0, 2));
    topo.add(linha, BorderLayout.SOUTH);

    principal.add(topo, BorderLayout.NORTH);

    // CONFIGURAÇÃO DOS CAMPOS
    JTextField[] campos = {
        txtNumeroOS, txtDataAbertura, txtDataConclusao,
        txtStatus, txtPesquisarVeiculo, txtPesquisarMecanico,
        txtPesquisarServico, txtValorCobrado
    };

    for (JTextField campo : campos) {
        Estilo.configurarCampo(campo);
        campo.setPreferredSize(new Dimension(100, 38));

        if (campo.isEditable()) {
            Estilo.configurarFoco(campo);
        } else {
            campo.setFocusable(false);
            campo.setBackground(new Color(35, 40, 49));
            campo.setForeground(Estilo.TEXTO_SECUNDARIO);
        }
    }

    txtNumeroOS.putClientProperty(
        "JTextField.placeholderText", "Automático"
    );
    txtDataAbertura.putClientProperty(
        "JTextField.placeholderText", "Definida ao abrir"
    );
    txtDataConclusao.putClientProperty(
        "JTextField.placeholderText", "Ainda não concluída"
    );
    txtValorCobrado.putClientProperty(
        "JTextField.placeholderText", "Ex.: 150,00"
    );

    txtPesquisarVeiculo.putClientProperty(
        "JTextField.placeholderText", "ID, placa ou modelo"
    );
    txtPesquisarMecanico.putClientProperty(
        "JTextField.placeholderText", "ID ou nome"
    );
    txtPesquisarServico.putClientProperty(
        "JTextField.placeholderText", "ID ou descrição"
    );

    txtStatus.setText("ABERTA");

    JComboBox<?>[] combos = {
        cbVeiculo, cbMecanico, cbServico
    };

    for (JComboBox<?> combo : combos) {
        Estilo.configurarCombo(combo);
        combo.setPreferredSize(new Dimension(100, 38));
    }

    // BOTÕES DE PESQUISA
    JButton[] pesquisas = {
        btnPesquisarVeiculo,
        btnPesquisarMecanico,
        btnPesquisarServico
    };

    for (JButton botao : pesquisas) {
        Estilo.configurarBotao(botao, "laranja");
        Estilo.configurarHover(
            botao, new Color(234, 88, 12)
        );
        botao.setIcon(null);
        botao.setText("BUSCAR");
        botao.setPreferredSize(new Dimension(105, 38));
    }

    // ÁREA COM ROLAGEM
    JPanel conteudo = new JPanel();
    conteudo.setOpaque(false);
    conteudo.setLayout(
        new BoxLayout(conteudo, BoxLayout.Y_AXIS)
    );

    JLabel titulo = new JLabel("Abertura de Ordem de Serviço");
    titulo.setFont(
        new Font(Font.SANS_SERIF, Font.BOLD, 26)
    );
    titulo.setForeground(Estilo.TEXTO);
    titulo.setAlignmentX(Component.LEFT_ALIGNMENT);

    conteudo.add(titulo);
    conteudo.add(Box.createVerticalStrut(18));

    // CARD 1: DADOS DA OS
    JPanel dados = criarCard("DADOS DA ORDEM DE SERVIÇO");

    JPanel gradeDados = new JPanel(new GridLayout(2, 2, 16, 12));
    gradeDados.setOpaque(false);

    gradeDados.add(criarCampo("Número da OS", txtNumeroOS));
    gradeDados.add(criarCampo("Data de abertura", txtDataAbertura));
    gradeDados.add(criarCampo("Status", txtStatus));
    gradeDados.add(criarCampo("Data de conclusão", txtDataConclusao));

    dados.add(gradeDados, BorderLayout.CENTER);
    conteudo.add(dados);
    conteudo.add(Box.createVerticalStrut(16));

    // CARD 2: VÍNCULOS
    JPanel vinculos = criarCard("VEÍCULO, MECÂNICO E SERVIÇO");

    JPanel gradeVinculos = new JPanel(
        new GridLayout(3, 1, 0, 15)
    );
    gradeVinculos.setOpaque(false);

    gradeVinculos.add(criarPesquisa(
        "Veículo", txtPesquisarVeiculo,
        btnPesquisarVeiculo, cbVeiculo
    ));

    gradeVinculos.add(criarPesquisa(
        "Mecânico responsável", txtPesquisarMecanico,
        btnPesquisarMecanico, cbMecanico
    ));

    gradeVinculos.add(criarPesquisa(
        "Serviço", txtPesquisarServico,
        btnPesquisarServico, cbServico
    ));

    vinculos.add(gradeVinculos, BorderLayout.CENTER);
    conteudo.add(vinculos);
    conteudo.add(Box.createVerticalStrut(16));

    // CARD 3: DETALHES
    JPanel detalhes = criarCard("DETALHES DO SERVIÇO");

    JPanel corpoDetalhes = new JPanel(new BorderLayout(0, 14));
    corpoDetalhes.setOpaque(false);

    JPanel areas = new JPanel(new GridLayout(1, 2, 16, 0));
    areas.setOpaque(false);

    areas.add(criarArea(
        "Descrição do problema",
        txtDescricao, jScrollPane1
    ));

    areas.add(criarArea(
        "Diagnóstico",
        txtDiagnostico, jScrollPane2
    ));

    corpoDetalhes.add(areas, BorderLayout.NORTH);

    JPanel inferior = new JPanel(new BorderLayout(0, 14));
    inferior.setOpaque(false);

    inferior.add(
        criarCampo("Valor cobrado (R$)", txtValorCobrado),
        BorderLayout.NORTH
    );

    inferior.add(
        criarArea("Observações", txtObservacao, jScrollPane3),
        BorderLayout.CENTER
    );

    corpoDetalhes.add(inferior, BorderLayout.CENTER);
    detalhes.add(corpoDetalhes, BorderLayout.CENTER);

    conteudo.add(detalhes);

    JScrollPane scrollCentral = new JScrollPane(conteudo);
    scrollCentral.setBorder(null);
    scrollCentral.setOpaque(false);
    scrollCentral.getViewport().setOpaque(false);
    scrollCentral.getVerticalScrollBar().setUnitIncrement(16);
    scrollCentral.setHorizontalScrollBarPolicy(
        JScrollPane.HORIZONTAL_SCROLLBAR_NEVER
    );

    principal.add(scrollCentral, BorderLayout.CENTER);

    // RODAPÉ
    JPanel rodape = new JPanel(
        new FlowLayout(FlowLayout.RIGHT, 12, 0)
    );
    rodape.setOpaque(false);

    Estilo.configurarBotao(btnLimpar, "cinza");
    Estilo.configurarBotao(btnFechar, "vermelho");
    Estilo.configurarBotao(btnAbrirOS, "laranja");

    Estilo.configurarHover(
        btnLimpar, new Color(100, 116, 139)
    );
    Estilo.configurarHover(
        btnFechar, new Color(220, 38, 38)
    );
    Estilo.configurarHover(
        btnAbrirOS, new Color(234, 88, 12)
    );

    btnLimpar.setText("LIMPAR");
    btnFechar.setText("FECHAR");
    btnAbrirOS.setText("ABRIR ORDEM DE SERVIÇO");

    btnLimpar.setPreferredSize(new Dimension(125, 42));
    btnFechar.setPreferredSize(new Dimension(125, 42));
    btnAbrirOS.setPreferredSize(new Dimension(260, 42));

    rodape.add(btnLimpar);
    rodape.add(btnFechar);
    rodape.add(btnAbrirOS);

    principal.add(rodape, BorderLayout.SOUTH);

    setContentPane(principal);

    SwingUtilities.invokeLater(() ->
        scrollCentral.getViewport().setViewPosition(
            new Point(0, 0)
        )
    );

    revalidate();
    repaint();
}

// CARD COM TÍTULO
private JPanel criarCard(String titulo) {

    JPanel card = new JPanel(new BorderLayout(0, 16));
    card.setBackground(Estilo.PAINEL);
    card.setBorder(new EmptyBorder(20, 22, 20, 22));
    card.setAlignmentX(Component.LEFT_ALIGNMENT);

    JLabel label = new JLabel(titulo);
    label.setForeground(Estilo.TEXTO);
    label.setFont(
        new Font(Font.SANS_SERIF, Font.BOLD, 13)
    );

    JPanel cabecalho = new JPanel(
        new FlowLayout(FlowLayout.LEFT, 10, 0)
    );
    cabecalho.setOpaque(false);

    JPanel barra = new JPanel();
    barra.setBackground(Estilo.LARANJA);
    barra.setPreferredSize(new Dimension(4, 18));

    cabecalho.add(barra);
    cabecalho.add(label);

    card.add(cabecalho, BorderLayout.NORTH);
    return card;
}

// CAMPO COM LABEL
private JPanel criarCampo(String titulo, JComponent componente) {

    JPanel painel = new JPanel(new BorderLayout(0, 6));
    painel.setOpaque(false);

    JLabel label = new JLabel(titulo);
    label.setForeground(Estilo.TEXTO);

    painel.add(label, BorderLayout.NORTH);
    painel.add(componente, BorderLayout.CENTER);

    return painel;
}

// CAMPO DE PESQUISA COM COMBOBOX
private JPanel criarPesquisa(
        String titulo,
        JTextField pesquisa,
        JButton botao,
        JComboBox<?> combo) {

    JPanel painel = new JPanel(new BorderLayout(0, 7));
    painel.setOpaque(false);

    JLabel label = new JLabel(titulo);
    label.setForeground(Estilo.TEXTO);

    JPanel busca = new JPanel(new BorderLayout(8, 0));
    busca.setOpaque(false);

    busca.add(pesquisa, BorderLayout.CENTER);
    busca.add(botao, BorderLayout.EAST);

    painel.add(label, BorderLayout.NORTH);
    painel.add(busca, BorderLayout.CENTER);
    painel.add(combo, BorderLayout.SOUTH);

    return painel;
}

// ÁREA DE TEXTO COM BORDA ARREDONDADA
private JPanel criarArea(
        String titulo,
        JTextArea area,
        JScrollPane scroll) {

    JPanel painel = new JPanel(new BorderLayout(0, 6));
    painel.setOpaque(false);

    JLabel label = new JLabel(titulo);
    label.setForeground(Estilo.TEXTO);

    Estilo.configurarArea(area);

    area.setBorder(
        BorderFactory.createEmptyBorder(10, 14, 10, 14)
    );

    scroll.setBorder(
        new BordaArredondada(Estilo.BORDA, 18)
    );

    scroll.setBackground(Estilo.COMPONENTE);
    scroll.getViewport().setBackground(Estilo.COMPONENTE);
    scroll.setPreferredSize(new Dimension(100, 105));

    scroll.setVerticalScrollBarPolicy(
        JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED
    );

    area.addFocusListener(new java.awt.event.FocusAdapter() {

        @Override
        public void focusGained(java.awt.event.FocusEvent e) {
            scroll.setBorder(
                new BordaArredondada(Estilo.LARANJA, 18)
            );
        }

        @Override
        public void focusLost(java.awt.event.FocusEvent e) {
            scroll.setBorder(
                new BordaArredondada(Estilo.BORDA, 18)
            );
        }
    });

    painel.add(label, BorderLayout.NORTH);
    painel.add(scroll, BorderLayout.CENTER);

    return painel;
}


    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txtNumeroOS = new javax.swing.JTextField();
        txtPesquisarVeiculo = new javax.swing.JTextField();
        btnPesquisarVeiculo = new javax.swing.JButton();
        cbVeiculo = new javax.swing.JComboBox<>();
        txtPesquisarMecanico = new javax.swing.JTextField();
        btnPesquisarMecanico = new javax.swing.JButton();
        cbMecanico = new javax.swing.JComboBox<>();
        txtPesquisarServico = new javax.swing.JTextField();
        cbServico = new javax.swing.JComboBox<>();
        btnPesquisarServico = new javax.swing.JButton();
        txtDataAbertura = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtDescricao = new javax.swing.JTextArea();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtDiagnostico = new javax.swing.JTextArea();
        txtStatus = new javax.swing.JTextField();
        txtValorCobrado = new javax.swing.JTextField();
        jScrollPane3 = new javax.swing.JScrollPane();
        txtObservacao = new javax.swing.JTextArea();
        txtDataConclusao = new javax.swing.JTextField();
        btnLimpar = new javax.swing.JButton();
        btnFechar = new javax.swing.JButton();
        btnAbrirOS = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        txtNumeroOS.setEditable(false);
        txtNumeroOS.setBorder(javax.swing.BorderFactory.createTitledBorder("Numero da OS"));

        txtPesquisarVeiculo.setBorder(javax.swing.BorderFactory.createTitledBorder("Pesquisar veículo"));

        btnPesquisarVeiculo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/lupa_transparente_30x30.png"))); // NOI18N
        btnPesquisarVeiculo.addActionListener(this::btnPesquisarVeiculoActionPerformed);

        txtPesquisarMecanico.setBorder(javax.swing.BorderFactory.createTitledBorder("Pesquisar mecanico"));

        btnPesquisarMecanico.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/lupa_transparente_30x30.png"))); // NOI18N
        btnPesquisarMecanico.addActionListener(this::btnPesquisarMecanicoActionPerformed);

        cbMecanico.addActionListener(this::cbMecanicoActionPerformed);

        txtPesquisarServico.setBorder(javax.swing.BorderFactory.createTitledBorder("Pesquisar serviço"));

        cbServico.addActionListener(this::cbServicoActionPerformed);

        btnPesquisarServico.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/lupa_transparente_30x30.png"))); // NOI18N
        btnPesquisarServico.addActionListener(this::btnPesquisarServicoActionPerformed);

        txtDataAbertura.setEditable(false);
        txtDataAbertura.setBorder(javax.swing.BorderFactory.createTitledBorder("Data de Abertura"));

        txtDescricao.setColumns(20);
        txtDescricao.setRows(5);
        txtDescricao.setBorder(javax.swing.BorderFactory.createTitledBorder("Descricao do problema"));
        jScrollPane1.setViewportView(txtDescricao);

        txtDiagnostico.setColumns(20);
        txtDiagnostico.setRows(5);
        txtDiagnostico.setBorder(javax.swing.BorderFactory.createTitledBorder("Diagnostico"));
        jScrollPane2.setViewportView(txtDiagnostico);

        txtStatus.setEditable(false);
        txtStatus.setText("ABERTA");
        txtStatus.setBorder(javax.swing.BorderFactory.createTitledBorder("Status"));

        txtValorCobrado.setBorder(javax.swing.BorderFactory.createTitledBorder("Valor Cobrado (R$)"));

        txtObservacao.setColumns(20);
        txtObservacao.setRows(5);
        txtObservacao.setBorder(javax.swing.BorderFactory.createTitledBorder("Observacao"));
        jScrollPane3.setViewportView(txtObservacao);

        txtDataConclusao.setEditable(false);
        txtDataConclusao.setBorder(javax.swing.BorderFactory.createTitledBorder("Data de conclusao"));

        btnLimpar.setBackground(new java.awt.Color(204, 204, 0));
        btnLimpar.setText("Limpar");
        btnLimpar.addActionListener(this::btnLimparActionPerformed);

        btnFechar.setBackground(new java.awt.Color(102, 0, 0));
        btnFechar.setText("Fechar");
        btnFechar.addActionListener(this::btnFecharActionPerformed);

        btnAbrirOS.setBackground(new java.awt.Color(0, 102, 0));
        btnAbrirOS.setText("Abrir OS");
        btnAbrirOS.addActionListener(this::btnAbrirOSActionPerformed);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(txtNumeroOS, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(txtDataAbertura, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cbVeiculo, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cbServico, javax.swing.GroupLayout.PREFERRED_SIZE, 221, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(txtPesquisarServico, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnPesquisarServico))
                            .addComponent(cbMecanico, javax.swing.GroupLayout.PREFERRED_SIZE, 221, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(txtPesquisarMecanico, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btnPesquisarMecanico))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(txtPesquisarVeiculo, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btnPesquisarVeiculo)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 213, Short.MAX_VALUE)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                        .addGap(6, 6, 6))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 248, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 108, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(txtDataConclusao, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(34, 34, 34))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(txtValorCobrado, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap())))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnFechar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnLimpar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnAbrirOS)
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(txtStatus, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtDataAbertura, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtNumeroOS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtPesquisarVeiculo, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnPesquisarVeiculo))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(cbVeiculo, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtPesquisarMecanico, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnPesquisarMecanico)))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(cbMecanico, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(txtPesquisarServico, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnPesquisarServico))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(cbServico, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(23, 23, 23)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(30, 30, 30)
                                .addComponent(txtValorCobrado))
                            .addComponent(txtStatus, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(104, 104, 104))
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 380, Short.MAX_VALUE)
                        .addComponent(txtDataConclusao, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(119, 119, 119)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnLimpar)
                    .addComponent(btnAbrirOS)
                    .addComponent(btnFechar))
                .addGap(20, 20, 20))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cbMecanicoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbMecanicoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbMecanicoActionPerformed

    private void btnPesquisarVeiculoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPesquisarVeiculoActionPerformed
        String pesquisa = txtPesquisarVeiculo.getText().trim().toUpperCase();
        
        
        carregarVeiculos(pesquisa);               
    }//GEN-LAST:event_btnPesquisarVeiculoActionPerformed

    private void btnPesquisarMecanicoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPesquisarMecanicoActionPerformed
         String pesquisa = txtPesquisarMecanico.getText().trim();

         carregarMecanicos(pesquisa);
    }//GEN-LAST:event_btnPesquisarMecanicoActionPerformed

    private void btnPesquisarServicoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPesquisarServicoActionPerformed
        String pesquisa = txtPesquisarServico.getText().trim();
        
         
         carregarServicos(pesquisa);
    }//GEN-LAST:event_btnPesquisarServicoActionPerformed

    private void cbServicoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbServicoActionPerformed
         int posicao = cbServico.getSelectedIndex();

           if (posicao < 0 || posicao >= valoresServicos.size()) {
              txtValorCobrado.setText("");
              return;
        }
    

         BigDecimal valor = valoresServicos.get(posicao);

         txtValorCobrado.setText(valor.toString());
    }//GEN-LAST:event_cbServicoActionPerformed

    private void btnFecharActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFecharActionPerformed
        dispose();
    }//GEN-LAST:event_btnFecharActionPerformed

    private void btnLimparActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimparActionPerformed
        limparCampos();
    }//GEN-LAST:event_btnLimparActionPerformed

    private void btnAbrirOSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAbrirOSActionPerformed
        int veiculo = cbVeiculo.getSelectedIndex();
        int mecanico = cbMecanico.getSelectedIndex();
        int servico = cbServico.getSelectedIndex();

    if (veiculo == -1 || mecanico == -1 || servico == -1) {
        Mensagem.aviso(
    this,
    "Selecione um veículo, mecânico e serviço!"
);
        return;
    }
    
        int idVeiculo = idVeiculos.get(veiculo);
        int idMecanico = idMecanicos.get(mecanico);
        int idServico = idServicos.get(servico); 
        String descricaoProblema = txtDescricao.getText().trim();
        String diagnostico = txtDiagnostico.getText().trim();
        String observacao = txtObservacao.getText().trim();
        
        if(descricaoProblema.isEmpty()){
            Mensagem.aviso(
    this,
    "Informe a descrição do problema!"
);
            return;
        }
        BigDecimal valorCobrado;
        
        try {
        valorCobrado = new BigDecimal(
                txtValorCobrado.getText().trim().replace(",", ".")
        );

        if (valorCobrado.compareTo(BigDecimal.ZERO) < 0) {
            Mensagem.aviso(this,
                    "O valor cobrado não pode ser negativo!");
            return;
        }

         }    catch (NumberFormatException erro) {
        Mensagem.aviso(this,
                "Informe um valor cobrado válido!");
        return;
         }
        
             String sqlInsert = """
                                INSERT INTO ordem_servico
                                (veiculo_id, mecanico_id, servico_id,
                                descricao_problema, diagnostico,
                                valor_cobrado, observacao)
                                VALUES (?, ?, ?, ?, ?, ?, ?)
                                RETURNING id
                                """;
             
             try (
                  Connection conex = Conexao.conectar();
                  PreparedStatement stmt = conex.prepareStatement(sqlInsert)){
                 
                        stmt.setInt(1, idVeiculo);
                        stmt.setInt(2, idMecanico);
                        stmt.setInt(3, idServico);
                        stmt.setString(4, descricaoProblema);
                        stmt.setString(5, diagnostico);
                        stmt.setBigDecimal(6, valorCobrado);
                        stmt.setString(7, observacao);

                try (ResultSet rs = stmt.executeQuery()) {

                     if (rs.next()) {
                     int numeroOS = rs.getInt("id");

                        Mensagem.aviso(this, "Ordem de Serviço nº " +numeroOS+ " aberta com sucesso!");
                        limparCampos();
                 }
             }

                } catch (SQLException erro) {
                Mensagem.aviso(this, "Erro ao abrir OS: " + erro.getMessage());
            }
    
    }//GEN-LAST:event_btnAbrirOSActionPerformed

    
    public static void main(String args[]) {
        
        Estilo.configurarTema();
        java.awt.EventQueue.invokeLater(() -> new FrmCadastroOS().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAbrirOS;
    private javax.swing.JButton btnFechar;
    private javax.swing.JButton btnLimpar;
    private javax.swing.JButton btnPesquisarMecanico;
    private javax.swing.JButton btnPesquisarServico;
    private javax.swing.JButton btnPesquisarVeiculo;
    private javax.swing.JComboBox<String> cbMecanico;
    private javax.swing.JComboBox<String> cbServico;
    private javax.swing.JComboBox<String> cbVeiculo;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTextField txtDataAbertura;
    private javax.swing.JTextField txtDataConclusao;
    private javax.swing.JTextArea txtDescricao;
    private javax.swing.JTextArea txtDiagnostico;
    private javax.swing.JTextField txtNumeroOS;
    private javax.swing.JTextArea txtObservacao;
    private javax.swing.JTextField txtPesquisarMecanico;
    private javax.swing.JTextField txtPesquisarServico;
    private javax.swing.JTextField txtPesquisarVeiculo;
    private javax.swing.JTextField txtStatus;
    private javax.swing.JTextField txtValorCobrado;
    // End of variables declaration//GEN-END:variables
}
