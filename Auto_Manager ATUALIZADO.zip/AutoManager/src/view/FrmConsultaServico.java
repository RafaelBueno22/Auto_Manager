package view;

import conexao.Conexao;
import java.math.BigDecimal;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.table.DefaultTableModel;
import java.sql.ResultSet;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import util.Estilo;
import util.Mensagem;
import util.SwitchAtivo;


public class FrmConsultaServico extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(FrmConsultaServico.class.getName());
    
    private SwitchAtivo switchAtivo;
private JLabel lblSituacao;
    
    private void atualizarTabela(){
        DefaultTableModel modelo = (DefaultTableModel) tblServicos.getModel();
        modelo.setRowCount(0);
        
        String sql = """
                     SELECT id, descricao, categoria, valor_base, tempo_estimado_horas, ativo
                     FROM servico ORDER BY id
                     """;
        try(Connection conex = Conexao.conectar();
            PreparedStatement stmt = conex.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery()){
                
                 while(rs.next()){
                   modelo.addRow(new Object []{
                       rs.getInt("id"), rs.getString("descricao"),
                       rs.getString("categoria"), rs.getBigDecimal("valor_base"),
                       rs.getBigDecimal("tempo_estimado_horas"), rs.getBoolean("ativo")
                   });            
            }
        }catch(SQLException erro){
             JOptionPane.showMessageDialog(this, "Erro ao atualizar: " +erro.getMessage());
        }         
    }
  
    public FrmConsultaServico() {
        initComponents();
        
         tblServicos.setModel(new DefaultTableModel(
        new Object[][] {},
        new String[] {
            "ID", "Descrição", "Categoria",
            "Valor Base", "Tempo Estimado", "Situação"
        }
    ) {
        @Override
        public boolean isCellEditable(int linha, int coluna) {
            return false;
        }
    });

    tblServicos.setSelectionMode(
        ListSelectionModel.SINGLE_SELECTION
    );

    criarInterface();
    atualizarTabela();
        
        
    }
    
    
    
private void criarInterface() {

    setTitle("AutoManager | Consulta de Serviços");
    setSize(1350, 900);
setResizable(false);
setLocationRelativeTo(null);

    Estilo.configurarIcone(this);

    // PAINEL PRINCIPAL
    JPanel principal = new JPanel(new BorderLayout(0, 16));
    principal.setBackground(Estilo.FUNDO);
    principal.setBorder(new EmptyBorder(22, 32, 22, 32));

    // CABEÇALHO
    JPanel cabecalho = new JPanel(new BorderLayout());
    cabecalho.setOpaque(false);

    cabecalho.add(
        new JLabel(Estilo.carregarLogo(280, 94)),
        BorderLayout.WEST
    );

    JLabel secao = new JLabel("SERVIÇOS / CONSULTA");
    secao.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 15));
    secao.setForeground(Estilo.LARANJA);
    cabecalho.add(secao, BorderLayout.EAST);

    JPanel topo = new JPanel(new BorderLayout(0, 12));
    topo.setOpaque(false);
    topo.add(cabecalho, BorderLayout.CENTER);

    JPanel linhaLaranja = new JPanel();
    linhaLaranja.setBackground(Estilo.LARANJA);
    linhaLaranja.setPreferredSize(new Dimension(0, 2));
    topo.add(linhaLaranja, BorderLayout.SOUTH);

    principal.add(topo, BorderLayout.NORTH);

    // CONTEÚDO CENTRAL
    JPanel conteudo = new JPanel();
    conteudo.setOpaque(false);
    conteudo.setLayout(
        new BoxLayout(conteudo, BoxLayout.Y_AXIS)
    );
    conteudo.setBorder(new EmptyBorder(0, 0, 20, 0));

    JLabel titulo = new JLabel("Consulta de Serviços");
    titulo.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 27));
    titulo.setForeground(Estilo.TEXTO);
    titulo.setAlignmentX(Component.LEFT_ALIGNMENT);

    JLabel subtitulo = new JLabel(
        "PESQUISE, VISUALIZE, ALTERE OU EXCLUA SERVIÇOS"
    );
    subtitulo.setForeground(Estilo.TEXTO_SECUNDARIO);
    subtitulo.setAlignmentX(Component.LEFT_ALIGNMENT);

    conteudo.add(titulo);
    conteudo.add(Box.createVerticalStrut(6));
    conteudo.add(subtitulo);
    conteudo.add(Box.createVerticalStrut(20));

    // PESQUISA
    JPanel pesquisa = criarCardServico();

    cbPesquisarPor.setModel(
        new DefaultComboBoxModel<>(
            new String[]{"ID", "Descrição", "Categoria"}
        )
    );

    Estilo.configurarCombo(cbPesquisarPor);
    cbPesquisarPor.setBorder(
        UIManager.getBorder("ComboBox.border")
    );
    cbPesquisarPor.setPreferredSize(new Dimension(170, 42));

    Estilo.configurarCampo(txtPesquisar);
    Estilo.configurarFoco(txtPesquisar);
    txtPesquisar.putClientProperty(
        "JTextField.placeholderText",
        "Digite o ID, descrição ou categoria"
    );
    txtPesquisar.setPreferredSize(new Dimension(300, 42));

    Estilo.configurarBotao(btnLocalizar, "laranja");
    Estilo.configurarBotao(btnAtualizar, "cinza");

    btnLocalizar.setText("BUSCAR");
    btnAtualizar.setText("ATUALIZAR");

    btnLocalizar.setPreferredSize(new Dimension(140, 42));
    btnAtualizar.setPreferredSize(new Dimension(145, 42));

    JPanel entrada = new JPanel(new BorderLayout(12, 0));
    entrada.setOpaque(false);
    entrada.add(cbPesquisarPor, BorderLayout.WEST);
    entrada.add(txtPesquisar, BorderLayout.CENTER);

    JPanel botoesPesquisa = new JPanel(
        new FlowLayout(FlowLayout.RIGHT, 10, 0)
    );
    botoesPesquisa.setOpaque(false);
    botoesPesquisa.add(btnLocalizar);
    botoesPesquisa.add(btnAtualizar);

    JPanel busca = new JPanel(new BorderLayout(12, 0));
    busca.setOpaque(false);
    busca.add(entrada, BorderLayout.CENTER);
    busca.add(botoesPesquisa, BorderLayout.EAST);

    pesquisa.add(busca, BorderLayout.NORTH);
    pesquisa.setPreferredSize(new Dimension(0, 82));
    pesquisa.setMaximumSize(
        new Dimension(Integer.MAX_VALUE, 82)
    );

    conteudo.add(pesquisa);
    conteudo.add(Box.createVerticalStrut(18));

    // TABELA
    JPanel cardTabela = criarCardServico();

    Estilo.configurarTabela(tblServicos);
    tblServicos.setRowHeight(38);
    tblServicos.setShowVerticalLines(false);
    tblServicos.setShowHorizontalLines(false);
    tblServicos.setFillsViewportHeight(true);
    tblServicos.setSelectionBackground(
        new Color(124, 62, 29)
    );
    tblServicos.setSelectionForeground(Color.WHITE);

    tblServicos.getTableHeader().setReorderingAllowed(false);
    tblServicos.getTableHeader().setPreferredSize(
        new Dimension(0, 42)
    );

    tblServicos.setAutoCreateRowSorter(true);

    tblServicos.setDefaultRenderer(
        Object.class, new RenderizadorServico()
    );
    tblServicos.setDefaultRenderer(
        Boolean.class, new RenderizadorServico()
    );
    tblServicos.setDefaultRenderer(
        Integer.class, new RenderizadorServico()
    );
    tblServicos.setDefaultRenderer(
        BigDecimal.class, new RenderizadorServico()
    );

    tblServicos.setAutoResizeMode(
        JTable.AUTO_RESIZE_ALL_COLUMNS
    );

    int[] larguras = {65, 300, 200, 150, 165, 110};

    for (int i = 0; i < larguras.length; i++) {
        tblServicos.getColumnModel()
            .getColumn(i).setPreferredWidth(larguras[i]);
    }

    jScrollPane1.setBorder(null);
    jScrollPane1.getViewport().setBackground(Estilo.PAINEL);
    jScrollPane1.setPreferredSize(new Dimension(0, 280));

    cardTabela.add(jScrollPane1, BorderLayout.CENTER);
    cardTabela.setPreferredSize(new Dimension(0, 320));
    cardTabela.setMaximumSize(
        new Dimension(Integer.MAX_VALUE, 320)
    );

    conteudo.add(cardTabela);
    conteudo.add(Box.createVerticalStrut(18));

    // PAINEL DE EDIÇÃO
    JPanel edicao = criarCardServico();

    JPanel corpoEdicao = new JPanel(new BorderLayout(0, 14));
    corpoEdicao.setOpaque(false);

    JLabel tituloEdicao = new JLabel(
        "EDITAR SERVIÇO SELECIONADO"
    );
    tituloEdicao.setForeground(Estilo.TEXTO);
    tituloEdicao.setFont(
        new Font(Font.SANS_SERIF, Font.BOLD, 14)
    );
    corpoEdicao.add(tituloEdicao, BorderLayout.NORTH);

    JTextField[] campos = {
        txtID, txtDescricao, txtCategoria,
        txtValorBase, txtTempoEstimado
    };

    for (JTextField campo : campos) {
        Estilo.configurarCampo(campo);
        campo.setBorder(
            UIManager.getBorder("TextField.border")
        );
        campo.putClientProperty(
            "JComponent.roundRect", true
        );

        if (campo != txtID) {
            Estilo.configurarFoco(campo);
        }
    }

    txtID.setEditable(false);
    txtID.setFocusable(false);
    txtID.setBackground(new Color(35, 40, 49));

    JPanel grade = new JPanel(
        new GridLayout(3, 2, 16, 12)
    );
    grade.setOpaque(false);
    grade.setPreferredSize(new Dimension(0, 220));

    grade.add(criarCampoServico("ID", txtID));
    grade.add(criarCampoServico("Descrição", txtDescricao));

    grade.add(criarCampoServico("Categoria", txtCategoria));
    grade.add(criarCampoServico("Valor base (R$)", txtValorBase));

    grade.add(criarCampoServico(
        "Tempo estimado (horas)", txtTempoEstimado
    ));
    JPanel vazio = new JPanel();
    vazio.setOpaque(false);
    grade.add(vazio);

    corpoEdicao.add(grade, BorderLayout.CENTER);

    // INTERRUPTOR ATIVO / INATIVO
    switchAtivo = new SwitchAtivo();
    switchAtivo.setSelected(chkAtivo.isSelected());

    lblSituacao = new JLabel(
        switchAtivo.isSelected()
            ? "Serviço ativo"
            : "Serviço inativo"
    );
    lblSituacao.setForeground(Estilo.TEXTO);
    lblSituacao.setFont(Estilo.FONTE_PADRAO);

    switchAtivo.addActionListener(e -> {
        boolean ativo = switchAtivo.isSelected();
        chkAtivo.setSelected(ativo);
        lblSituacao.setText(
            ativo ? "Serviço ativo" : "Serviço inativo"
        );
    });

    JPanel situacao = new JPanel(
        new FlowLayout(FlowLayout.LEFT, 12, 0)
    );
    situacao.setOpaque(false);
    situacao.add(switchAtivo);
    situacao.add(lblSituacao);

    corpoEdicao.add(situacao, BorderLayout.SOUTH);

    edicao.add(corpoEdicao, BorderLayout.CENTER);
    edicao.setPreferredSize(new Dimension(0, 335));
    edicao.setMaximumSize(
        new Dimension(Integer.MAX_VALUE, 335)
    );

    // ADICIONA O PAINEL DE EDIÇÃO
    conteudo.add(edicao);

    // ROLAGEM CENTRAL
    JScrollPane scrollCentral = new JScrollPane(conteudo);
    scrollCentral.setBorder(null);
    scrollCentral.setOpaque(false);
    scrollCentral.getViewport().setOpaque(false);
    scrollCentral.getVerticalScrollBar().setUnitIncrement(16);
    scrollCentral.setHorizontalScrollBarPolicy(
        JScrollPane.HORIZONTAL_SCROLLBAR_NEVER
    );

    principal.add(scrollCentral, BorderLayout.CENTER);

    // RODAPÉ
    JPanel rodape = new JPanel(
        new FlowLayout(FlowLayout.RIGHT, 12, 0)
    );
    rodape.setOpaque(false);

    Estilo.configurarBotao(btnFechar, "cinza");
    Estilo.configurarBotao(btnExcluir, "vermelho");
    Estilo.configurarBotao(btnAlterar, "laranja");

    btnFechar.setText("FECHAR");
    btnExcluir.setText("EXCLUIR");
    btnAlterar.setText("ALTERAR");

    btnFechar.setPreferredSize(new Dimension(155, 44));
    btnExcluir.setPreferredSize(new Dimension(155, 44));
    btnAlterar.setPreferredSize(new Dimension(155, 44));

    rodape.add(btnFechar);
    rodape.add(btnExcluir);
    rodape.add(btnAlterar);

    principal.add(rodape, BorderLayout.SOUTH);

    txtPesquisar.addActionListener(
        e -> btnLocalizar.doClick()
    );

    setContentPane(principal);

    SwingUtilities.invokeLater(() -> {
        scrollCentral.getVerticalScrollBar().setValue(0);
    });

    revalidate();
    repaint();
}

// CARD REUTILIZÁVEL
private JPanel criarCardServico() {
    JPanel painel = new JPanel(new BorderLayout());
    painel.setBackground(Estilo.PAINEL);
    painel.setBorder(new EmptyBorder(18, 20, 18, 20));
    painel.setAlignmentX(Component.LEFT_ALIGNMENT);
    return painel;
}

// CAMPO COM TÍTULO
private JPanel criarCampoServico(
        String titulo, JComponent campo) {

    JPanel painel = new JPanel(new BorderLayout(0, 6));
    painel.setOpaque(false);

    JLabel label = new JLabel(titulo);
    label.setForeground(Estilo.TEXTO);

    painel.add(label, BorderLayout.NORTH);
    painel.add(campo, BorderLayout.CENTER);

    return painel;
}

// RENDERIZADOR DA TABELA
private class RenderizadorServico
        extends DefaultTableCellRenderer {

    @Override
    public Component getTableCellRendererComponent(
            JTable tabela,
            Object valor,
            boolean selecionado,
            boolean foco,
            int linha,
            int coluna) {

        Object exibicao = valor;

        if (coluna == 5 && valor instanceof Boolean ativo) {
            exibicao = ativo ? "Ativo" : "Inativo";
        }

        super.getTableCellRendererComponent(
            tabela, exibicao, selecionado,
            foco, linha, coluna
        );

        setBorder(new EmptyBorder(0, 12, 0, 12));

        if (selecionado) {
            setBackground(new Color(124, 62, 29));
            setForeground(Color.WHITE);
        } else {
            setBackground(
                linha % 2 == 0
                    ? Estilo.PAINEL
                    : new Color(40, 46, 57)
            );

            if (coluna == 5 && valor instanceof Boolean ativo) {
                setForeground(
                    ativo
                        ? new Color(74, 222, 128)
                        : new Color(248, 113, 113)
                );
            } else {
                setForeground(Estilo.TEXTO);
            }
        }

        return this;
    }
}

    
    

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        cbPesquisarPor = new javax.swing.JComboBox<>();
        jPanel1 = new javax.swing.JPanel();
        txtPesquisar = new javax.swing.JTextField();
        btnLocalizar = new javax.swing.JButton();
        btnAtualizar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblServicos = new javax.swing.JTable();
        txtID = new javax.swing.JTextField();
        txtDescricao = new javax.swing.JTextField();
        txtValorBase = new javax.swing.JTextField();
        txtCategoria = new javax.swing.JTextField();
        txtTempoEstimado = new javax.swing.JTextField();
        chkAtivo = new javax.swing.JCheckBox();
        btnAlterar = new javax.swing.JButton();
        btnFechar = new javax.swing.JButton();
        btnExcluir = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        cbPesquisarPor.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ID", "Descricao", "Categoria", " " }));
        cbPesquisarPor.setBorder(javax.swing.BorderFactory.createTitledBorder("Filtro"));

        jPanel1.setBackground(new java.awt.Color(0, 153, 0));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1109, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 108, Short.MAX_VALUE)
        );

        txtPesquisar.setBorder(javax.swing.BorderFactory.createTitledBorder("Pesquisar"));

        btnLocalizar.setText("Localizar");
        btnLocalizar.addActionListener(this::btnLocalizarActionPerformed);

        btnAtualizar.setText("Atualizar");
        btnAtualizar.addActionListener(this::btnAtualizarActionPerformed);

        tblServicos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Descrição", "Categoria", "Valor Base", "Tempo Estimado", "Ativo"
            }
        ));
        tblServicos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblServicosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblServicos);

        txtID.setEditable(false);
        txtID.setBorder(javax.swing.BorderFactory.createTitledBorder("ID"));

        txtDescricao.setBorder(javax.swing.BorderFactory.createTitledBorder("Descrição"));

        txtValorBase.setBorder(javax.swing.BorderFactory.createTitledBorder("Valor Base (R$)"));

        txtCategoria.setBorder(javax.swing.BorderFactory.createTitledBorder("Categoria"));

        txtTempoEstimado.setBorder(javax.swing.BorderFactory.createTitledBorder("Tempo Estimado"));

        chkAtivo.setSelected(true);
        chkAtivo.setText("Ativo");

        btnAlterar.setText("Alterar");
        btnAlterar.addActionListener(this::btnAlterarActionPerformed);

        btnFechar.setText("Fechar");
        btnFechar.addActionListener(this::btnFecharActionPerformed);

        btnExcluir.setText("Excluir");
        btnExcluir.addActionListener(this::btnExcluirActionPerformed);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(cbPesquisarPor, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(txtPesquisar, javax.swing.GroupLayout.PREFERRED_SIZE, 301, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnLocalizar, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btnAtualizar, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(btnAlterar, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnExcluir, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnFechar, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(txtID, javax.swing.GroupLayout.PREFERRED_SIZE, 301, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(txtCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, 301, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(txtTempoEstimado, javax.swing.GroupLayout.PREFERRED_SIZE, 301, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(txtDescricao, javax.swing.GroupLayout.PREFERRED_SIZE, 301, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(txtValorBase, javax.swing.GroupLayout.PREFERRED_SIZE, 301, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(116, 116, 116)
                                .addComponent(chkAtivo)))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(txtPesquisar, javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cbPesquisarPor)
                    .addComponent(btnLocalizar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnAtualizar, javax.swing.GroupLayout.DEFAULT_SIZE, 51, Short.MAX_VALUE))
                .addGap(46, 46, 46)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txtID, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txtCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(txtTempoEstimado, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtValorBase, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(chkAtivo)
                    .addComponent(txtDescricao, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 38, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnExcluir, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnFechar, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnAlterar, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnFecharActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFecharActionPerformed
        dispose();
    }//GEN-LAST:event_btnFecharActionPerformed

    private void btnLocalizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLocalizarActionPerformed
        String pesquisa = txtPesquisar.getText().trim();

    if (pesquisa.isEmpty()) {
        Mensagem.aviso(this, "Digite um valor para pesquisar.");
        return;
    }

    String tipo = cbPesquisarPor
            .getSelectedItem().toString();

    String sql;

    switch (tipo) {
        case "ID":
            sql = "SELECT * FROM servico WHERE id = ?";
            break;
        case "Descrição":
            sql = "SELECT * FROM servico WHERE descricao ILIKE ?";
            break;
        case "Categoria":
            sql = "SELECT * FROM servico WHERE categoria ILIKE ?";
            break;
        default:
            return;
    }

    Integer idPesquisa = null;

    if ("ID".equals(tipo)) {
        try {
            idPesquisa = Integer.valueOf(pesquisa);
        } catch (NumberFormatException erro) {
            Mensagem.aviso(this, "Informe um ID numérico válido.");
            return;
        }
    }

    DefaultTableModel modelo =
            (DefaultTableModel) tblServicos.getModel();

    try (Connection conex = Conexao.conectar();
         PreparedStatement stmt = conex.prepareStatement(sql)) {

        if (idPesquisa != null) {
            stmt.setInt(1, idPesquisa);
        } else {
            stmt.setString(1, "%" + pesquisa + "%");
        }

        try (ResultSet rs = stmt.executeQuery()) {
            modelo.setRowCount(0);

            while (rs.next()) {
                modelo.addRow(new Object[]{
                    rs.getInt("id"),
                    rs.getString("descricao"),
                    rs.getString("categoria"),
                    rs.getBigDecimal("valor_base"),
                    rs.getBigDecimal("tempo_estimado_horas"),
                    rs.getBoolean("ativo")
                });
            }
        }

        if (modelo.getRowCount() == 0) {
            Mensagem.aviso(this, "Nenhum serviço encontrado.");
        }

    } catch (SQLException erro) {
        Mensagem.erro(this,
            "Erro ao pesquisar serviço: " + erro.getMessage());
    }
    }//GEN-LAST:event_btnLocalizarActionPerformed

    private void btnAtualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAtualizarActionPerformed
        atualizarTabela();
    }//GEN-LAST:event_btnAtualizarActionPerformed

    private void btnAlterarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAlterarActionPerformed
        int linha = tblServicos.getSelectedRow();

    if (linha == -1) {
        Mensagem.aviso(this, "Selecione um serviço.");
        return;
    }

    int id = Integer.parseInt(
        tblServicos.getValueAt(linha, 0).toString()
    );

    String descricao = txtDescricao.getText().trim();
    String categoria = txtCategoria.getText().trim();
    boolean ativo = chkAtivo.isSelected();

    if (descricao.isEmpty() || categoria.isEmpty()) {
        Mensagem.aviso(this,
            "Preencha a descrição e a categoria.");
        return;
    }

    BigDecimal valorBase;
    BigDecimal tempoEstimado = null;

    try {
        valorBase = new BigDecimal(
            txtValorBase.getText().trim().replace(",", ".")
        );

        if (valorBase.compareTo(BigDecimal.ZERO) < 0) {
            Mensagem.aviso(this,
                "O valor base não pode ser negativo.");
            return;
        }

        String tempoTexto = txtTempoEstimado.getText().trim();

        if (!tempoTexto.isEmpty()) {
            tempoEstimado = new BigDecimal(
                tempoTexto.replace(",", ".")
            );

            if (tempoEstimado.compareTo(BigDecimal.ZERO) <= 0) {
                Mensagem.aviso(this,
                    "O tempo estimado deve ser maior que zero.");
                return;
            }
        }

    } catch (NumberFormatException erro) {
        Mensagem.aviso(this,
            "Informe valores numéricos válidos.");
        return;
    }

    if (!Mensagem.confirmar(
            this, "Deseja realmente alterar este serviço?")) {
        return;
    }

    String sql = """
        UPDATE servico
        SET descricao = ?,
            categoria = ?,
            valor_base = ?,
            tempo_estimado_horas = ?,
            ativo = ?
        WHERE id = ?
        """;

    try (Connection conex = Conexao.conectar();
         PreparedStatement stmt = conex.prepareStatement(sql)) {

        stmt.setString(1, descricao);
        stmt.setString(2, categoria);
        stmt.setBigDecimal(3, valorBase);

        if (tempoEstimado == null) {
            stmt.setNull(4, java.sql.Types.NUMERIC);
        } else {
            stmt.setBigDecimal(4, tempoEstimado);
        }

        stmt.setBoolean(5, ativo);
        stmt.setInt(6, id);

        int linhas = stmt.executeUpdate();

        if (linhas > 0) {
            Mensagem.sucesso(this,
                "Serviço alterado com sucesso!");
            atualizarTabela();
        } else {
            Mensagem.aviso(this,
                "Serviço não encontrado.");
        }

    } catch (SQLException erro) {
        Mensagem.erro(this,
            "Erro ao alterar serviço: " + erro.getMessage());
    }
        
        
       
       
    }//GEN-LAST:event_btnAlterarActionPerformed

    private void tblServicosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblServicosMouseClicked
        int linha = tblServicos.getSelectedRow();
    if (linha == -1) return;

    txtID.setText(String.valueOf(
        tblServicos.getValueAt(linha, 0)
    ));

    txtDescricao.setText(String.valueOf(
        tblServicos.getValueAt(linha, 1)
    ));

    txtCategoria.setText(String.valueOf(
        tblServicos.getValueAt(linha, 2)
    ));

    Object valor = tblServicos.getValueAt(linha, 3);
    txtValorBase.setText(
        valor == null ? "" : valor.toString()
    );

    Object tempo = tblServicos.getValueAt(linha, 4);
    txtTempoEstimado.setText(
        tempo == null ? "" : tempo.toString()
    );

    boolean ativo = Boolean.TRUE.equals(
        tblServicos.getValueAt(linha, 5)
    );

    chkAtivo.setSelected(ativo);
    switchAtivo.setSelected(ativo);

    lblSituacao.setText(
        ativo ? "Serviço ativo" : "Serviço inativo"
    );
    }//GEN-LAST:event_tblServicosMouseClicked

    private void btnExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExcluirActionPerformed
       int linha = tblServicos.getSelectedRow();

    if (linha == -1) {
        Mensagem.aviso(this,
            "Selecione um serviço para excluir.");
        return;
    }

    int id = Integer.parseInt(
        tblServicos.getValueAt(linha, 0).toString()
    );

    String sqlVerificar = """
        SELECT COUNT(*)
        FROM ordem_servico
        WHERE servico_id = ?
        """;

    try (Connection conex = Conexao.conectar()) {

        int quantidade = 0;

        try (PreparedStatement stmt =
                conex.prepareStatement(sqlVerificar)) {

            stmt.setInt(1, id);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    quantidade = rs.getInt(1);
                }
            }
        }

        if (quantidade > 0) {

            boolean desativar = Mensagem.confirmar(
                this,
                "<html>Este serviço possui " + quantidade
                + " OS vinculada(s).<br>"
                + "Não é possível excluí-lo.<br>"
                + "Deseja desativar o serviço?</html>"
            );

            if (!desativar) return;

            String sql = """
                UPDATE servico
                SET ativo = FALSE
                WHERE id = ?
                """;

            try (PreparedStatement stmt =
                    conex.prepareStatement(sql)) {

                stmt.setInt(1, id);

                if (stmt.executeUpdate() > 0) {
                    Mensagem.sucesso(this,
                        "Serviço desativado com sucesso!");
                } else {
                    Mensagem.aviso(this,
                        "Serviço não encontrado.");
                }
            }

        } else {

            if (!Mensagem.confirmar(
                    this,
                    "Deseja realmente excluir este serviço?")) {
                return;
            }

            String sql = "DELETE FROM servico WHERE id = ?";

            try (PreparedStatement stmt =
                    conex.prepareStatement(sql)) {

                stmt.setInt(1, id);

                if (stmt.executeUpdate() > 0) {
                    Mensagem.sucesso(this,
                        "Serviço excluído com sucesso!");
                } else {
                    Mensagem.aviso(this,
                        "Serviço não encontrado.");
                }
            }
        }

        atualizarTabela();

    } catch (SQLException erro) {
        Mensagem.erro(this,
            "Erro ao excluir serviço: " + erro.getMessage());
    }
    }//GEN-LAST:event_btnExcluirActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        Estilo.configurarTema();
        java.awt.EventQueue.invokeLater(() -> new FrmConsultaServico().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAlterar;
    private javax.swing.JButton btnAtualizar;
    private javax.swing.JButton btnExcluir;
    private javax.swing.JButton btnFechar;
    private javax.swing.JButton btnLocalizar;
    private javax.swing.JComboBox<String> cbPesquisarPor;
    private javax.swing.JCheckBox chkAtivo;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblServicos;
    private javax.swing.JTextField txtCategoria;
    private javax.swing.JTextField txtDescricao;
    private javax.swing.JTextField txtID;
    private javax.swing.JTextField txtPesquisar;
    private javax.swing.JTextField txtTempoEstimado;
    private javax.swing.JTextField txtValorBase;
    // End of variables declaration//GEN-END:variables
}
