package view;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import util.Estilo;
import util.SwitchAtivo;
import util.Mensagem;

public class FrmConsultaMecanico extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(FrmConsultaMecanico.class.getName());

    private SwitchAtivo switchAtivo;
private JLabel lblSituacao;
    
        private void atualizarTabela(){
            DefaultTableModel modelo = (DefaultTableModel) tblMecanicos.getModel();
            modelo.setRowCount(0);
            
            String sql = """
                         SELECT id, nome, especialidade, telefone, data_admissao, ativo
                         FROM mecanico ORDER BY id
                         """;
            
            try(Connection conex = Conexao.conectar();
                PreparedStatement stmt = conex.prepareStatement(sql);
                ResultSet rs = stmt.executeQuery()){
                
                while(rs.next()){
                    modelo.addRow(new Object[]{
                        rs.getInt("id"), rs.getString("nome"),
                        rs.getString("especialidade"), rs.getString("telefone"),
                        rs.getString("data_admissao"), rs.getBoolean("ativo")
                    });
                }
            }catch(SQLException erro){
                JOptionPane.showMessageDialog(this, "Erro ao atualizar: " +erro.getMessage());
            }
        }
    
    public FrmConsultaMecanico() {
        initComponents();
        
        tblMecanicos.setModel(new DefaultTableModel(
        new Object[][] {},
        new String[] {
            "ID", "Nome", "Especialidade",
            "Telefone", "Data de Admissão", "Situação"
        }
    ) {
        @Override
        public boolean isCellEditable(int linha, int coluna) {
            return false;
        }
    });

    tblMecanicos.setSelectionMode(
        javax.swing.ListSelectionModel.SINGLE_SELECTION
    );

    criarInterface();
    atualizarTabela();
    }
    
    
    
private void criarInterface() {

    setTitle("AutoManager | Consulta de Mecânicos");
    setSize(1350, 900);
setResizable(false);
setLocationRelativeTo(null);

    Estilo.configurarIcone(this);

    // PAINEL PRINCIPAL
    JPanel principal = new JPanel(new BorderLayout(0, 16));
    principal.setBackground(Estilo.FUNDO);
    principal.setBorder(new EmptyBorder(22, 32, 22, 32));

    // CABEÇALHO
    JPanel cabecalho = new JPanel(new BorderLayout());
    cabecalho.setOpaque(false);

    cabecalho.add(
        new JLabel(Estilo.carregarLogo(280, 94)),
        BorderLayout.WEST
    );

    JLabel secao = new JLabel("MECÂNICOS / CONSULTA");
    secao.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 15));
    secao.setForeground(Estilo.LARANJA);
    cabecalho.add(secao, BorderLayout.EAST);

    JPanel topo = new JPanel(new BorderLayout(0, 12));
    topo.setOpaque(false);
    topo.add(cabecalho, BorderLayout.CENTER);

    JPanel linhaLaranja = new JPanel();
    linhaLaranja.setBackground(Estilo.LARANJA);
    linhaLaranja.setPreferredSize(new Dimension(0, 2));
    topo.add(linhaLaranja, BorderLayout.SOUTH);

    principal.add(topo, BorderLayout.NORTH);

    // CONTEÚDO CENTRAL
    JPanel conteudo = new JPanel();
    conteudo.setOpaque(false);
    conteudo.setLayout(
        new BoxLayout(conteudo, BoxLayout.Y_AXIS)
    );
    conteudo.setBorder(new EmptyBorder(0, 0, 20, 0));

    JLabel titulo = new JLabel("Consulta de Mecânicos");
    titulo.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 27));
    titulo.setForeground(Estilo.TEXTO);
    titulo.setAlignmentX(Component.LEFT_ALIGNMENT);

    JLabel subtitulo = new JLabel(
        "PESQUISE, VISUALIZE, ALTERE OU EXCLUA MECÂNICOS"
    );
    subtitulo.setForeground(Estilo.TEXTO_SECUNDARIO);
    subtitulo.setAlignmentX(Component.LEFT_ALIGNMENT);

    conteudo.add(titulo);
    conteudo.add(Box.createVerticalStrut(6));
    conteudo.add(subtitulo);
    conteudo.add(Box.createVerticalStrut(20));

    // PESQUISA
    JPanel pesquisa = criarCardMecanico();

    cbPesquisarPor.setModel(
        new DefaultComboBoxModel<>(
            new String[]{"ID", "Nome", "Especialidade"}
        )
    );

    Estilo.configurarCombo(cbPesquisarPor);
    cbPesquisarPor.setBorder(
        UIManager.getBorder("ComboBox.border")
    );
    cbPesquisarPor.setPreferredSize(new Dimension(170, 42));

    Estilo.configurarCampo(txtPesquisar);
    Estilo.configurarFoco(txtPesquisar);
    txtPesquisar.putClientProperty(
        "JTextField.placeholderText",
        "Digite o ID, nome ou especialidade"
    );
    txtPesquisar.setPreferredSize(new Dimension(300, 42));

    Estilo.configurarBotao(btnLocalizar, "laranja");
    Estilo.configurarBotao(btnAtualizar, "cinza");

    btnLocalizar.setText("BUSCAR");
    btnAtualizar.setText("ATUALIZAR");

    btnLocalizar.setPreferredSize(new Dimension(140, 42));
    btnAtualizar.setPreferredSize(new Dimension(145, 42));

    JPanel entrada = new JPanel(new BorderLayout(12, 0));
    entrada.setOpaque(false);
    entrada.add(cbPesquisarPor, BorderLayout.WEST);
    entrada.add(txtPesquisar, BorderLayout.CENTER);

    JPanel botoesPesquisa = new JPanel(
        new FlowLayout(FlowLayout.RIGHT, 10, 0)
    );
    botoesPesquisa.setOpaque(false);
    botoesPesquisa.add(btnLocalizar);
    botoesPesquisa.add(btnAtualizar);

    JPanel busca = new JPanel(new BorderLayout(12, 0));
    busca.setOpaque(false);
    busca.add(entrada, BorderLayout.CENTER);
    busca.add(botoesPesquisa, BorderLayout.EAST);

    pesquisa.add(busca, BorderLayout.NORTH);
    pesquisa.setPreferredSize(new Dimension(0, 82));
    pesquisa.setMaximumSize(
        new Dimension(Integer.MAX_VALUE, 82)
    );

    conteudo.add(pesquisa);
    conteudo.add(Box.createVerticalStrut(18));

    // TABELA
    JPanel cardTabela = criarCardMecanico();

    Estilo.configurarTabela(tblMecanicos);
    tblMecanicos.setRowHeight(38);
    tblMecanicos.setShowVerticalLines(false);
    tblMecanicos.setShowHorizontalLines(false);
    tblMecanicos.setFillsViewportHeight(true);
    tblMecanicos.setSelectionBackground(
        new Color(124, 62, 29)
    );
    tblMecanicos.setSelectionForeground(Color.WHITE);

    tblMecanicos.getTableHeader().setReorderingAllowed(false);
    tblMecanicos.getTableHeader().setPreferredSize(
        new Dimension(0, 42)
    );

    tblMecanicos.setAutoCreateRowSorter(true);

    tblMecanicos.setDefaultRenderer(
        Object.class, new RenderizadorMecanico()
    );
    tblMecanicos.setDefaultRenderer(
        Boolean.class, new RenderizadorMecanico()
    );
    tblMecanicos.setDefaultRenderer(
        Integer.class, new RenderizadorMecanico()
    );

    tblMecanicos.setAutoResizeMode(
        JTable.AUTO_RESIZE_ALL_COLUMNS
    );

    int[] larguras = {60, 220, 230, 165, 170, 110};

    for (int i = 0; i < larguras.length; i++) {
        tblMecanicos.getColumnModel()
            .getColumn(i).setPreferredWidth(larguras[i]);
    }

    jScrollPane1.setBorder(null);
    jScrollPane1.getViewport().setBackground(Estilo.PAINEL);
    jScrollPane1.setPreferredSize(new Dimension(0, 260));

    cardTabela.add(jScrollPane1, BorderLayout.CENTER);
    cardTabela.setPreferredSize(new Dimension(0, 300));
    cardTabela.setMaximumSize(
        new Dimension(Integer.MAX_VALUE, 300)
    );

    conteudo.add(cardTabela);
    conteudo.add(Box.createVerticalStrut(18));

    // PAINEL DE EDIÇÃO
    JPanel edicao = criarCardMecanico();

    JPanel corpoEdicao = new JPanel(new BorderLayout(0, 14));
    corpoEdicao.setOpaque(false);

    JLabel tituloEdicao = new JLabel(
        "EDITAR MECÂNICO SELECIONADO"
    );
    tituloEdicao.setForeground(Estilo.TEXTO);
    tituloEdicao.setFont(
        new Font(Font.SANS_SERIF, Font.BOLD, 14)
    );
    corpoEdicao.add(tituloEdicao, BorderLayout.NORTH);

    // CAMPOS
    JTextField[] campos = {
        txtID, txtNome, txtEspecialidade,
        txtTelefone, txtData
    };

    for (JTextField campo : campos) {
        Estilo.configurarCampo(campo);
        campo.setBorder(
            UIManager.getBorder("TextField.border")
        );
        campo.putClientProperty(
            "JComponent.roundRect", true
        );

        if (campo != txtID) {
            Estilo.configurarFoco(campo);
        }
    }

    txtID.setEditable(false);
    txtID.setFocusable(false);
    txtID.setBackground(new Color(35, 40, 49));

    JPanel grade = new JPanel(
        new GridLayout(3, 2, 16, 12)
    );
    grade.setOpaque(false);
    grade.setPreferredSize(new Dimension(0, 220));

    grade.add(criarCampoMecanico("ID", txtID));
    grade.add(criarCampoMecanico("Nome", txtNome));

    grade.add(criarCampoMecanico(
        "Especialidade", txtEspecialidade
    ));
    grade.add(criarCampoMecanico("Telefone", txtTelefone));

    grade.add(criarCampoMecanico(
        "Data de admissão", txtData
    ));
    grade.add(new JPanel() {{ setOpaque(false); }});

    corpoEdicao.add(grade, BorderLayout.CENTER);

    // SWITCH ATIVO / INATIVO
    switchAtivo = new SwitchAtivo();
    switchAtivo.setSelected(chkAtivo.isSelected());

    lblSituacao = new JLabel(
        switchAtivo.isSelected()
            ? "Mecânico ativo"
            : "Mecânico inativo"
    );
    lblSituacao.setForeground(Estilo.TEXTO);
    lblSituacao.setFont(Estilo.FONTE_PADRAO);

    switchAtivo.addActionListener(e -> {
        boolean ativo = switchAtivo.isSelected();
        chkAtivo.setSelected(ativo);
        lblSituacao.setText(
            ativo ? "Mecânico ativo" : "Mecânico inativo"
        );
    });

    JPanel situacao = new JPanel(
        new FlowLayout(FlowLayout.LEFT, 12, 0)
    );
    situacao.setOpaque(false);
    situacao.add(switchAtivo);
    situacao.add(lblSituacao);

    corpoEdicao.add(situacao, BorderLayout.SOUTH);

    edicao.add(corpoEdicao, BorderLayout.CENTER);
    edicao.setPreferredSize(new Dimension(0, 335));
    edicao.setMaximumSize(
        new Dimension(Integer.MAX_VALUE, 335)
    );

    // NÃO ESQUECER DE ADICIONAR O CARD
    conteudo.add(edicao);

    // ROLAGEM CENTRAL
    JScrollPane scrollCentral = new JScrollPane(conteudo);
    scrollCentral.setBorder(null);
    scrollCentral.setOpaque(false);
    scrollCentral.getViewport().setOpaque(false);
    scrollCentral.getVerticalScrollBar().setUnitIncrement(16);
    scrollCentral.setHorizontalScrollBarPolicy(
        JScrollPane.HORIZONTAL_SCROLLBAR_NEVER
    );

    principal.add(scrollCentral, BorderLayout.CENTER);

    // RODAPÉ
    JPanel rodape = new JPanel(
        new FlowLayout(FlowLayout.RIGHT, 12, 0)
    );
    rodape.setOpaque(false);

    Estilo.configurarBotao(btnFechar, "cinza");
    Estilo.configurarBotao(btnExcluir, "vermelho");
    Estilo.configurarBotao(btnAlterar, "laranja");

    btnFechar.setText("FECHAR");
    btnExcluir.setText("EXCLUIR");
    btnAlterar.setText("ALTERAR");

    btnFechar.setPreferredSize(new Dimension(155, 44));
    btnExcluir.setPreferredSize(new Dimension(155, 44));
    btnAlterar.setPreferredSize(new Dimension(155, 44));

    rodape.add(btnFechar);
    rodape.add(btnExcluir);
    rodape.add(btnAlterar);

    principal.add(rodape, BorderLayout.SOUTH);

    txtPesquisar.addActionListener(
        e -> btnLocalizar.doClick()
    );

    setContentPane(principal);

    SwingUtilities.invokeLater(() -> {
        scrollCentral.getVerticalScrollBar().setValue(0);
    });

    revalidate();
    repaint();
}

// CARD REUTILIZÁVEL
private JPanel criarCardMecanico() {
    JPanel painel = new JPanel(new BorderLayout());
    painel.setBackground(Estilo.PAINEL);
    painel.setBorder(new EmptyBorder(18, 20, 18, 20));
    painel.setAlignmentX(Component.LEFT_ALIGNMENT);
    return painel;
}

// CAMPO COM TÍTULO
private JPanel criarCampoMecanico(
        String titulo, JComponent campo) {

    JPanel painel = new JPanel(new BorderLayout(0, 6));
    painel.setOpaque(false);

    JLabel label = new JLabel(titulo);
    label.setForeground(Estilo.TEXTO);

    painel.add(label, BorderLayout.NORTH);
    painel.add(campo, BorderLayout.CENTER);

    return painel;
}

// RENDERIZADOR DA TABELA
private class RenderizadorMecanico
        extends DefaultTableCellRenderer {

    @Override
    public Component getTableCellRendererComponent(
            JTable tabela,
            Object valor,
            boolean selecionado,
            boolean foco,
            int linha,
            int coluna) {

        Object exibicao = valor;

        if (coluna == 5 && valor instanceof Boolean ativo) {
            exibicao = ativo ? "Ativo" : "Inativo";
        }

        super.getTableCellRendererComponent(
            tabela, exibicao, selecionado,
            foco, linha, coluna
        );

        setBorder(new EmptyBorder(0, 12, 0, 12));

        if (selecionado) {
            setBackground(new Color(124, 62, 29));
            setForeground(Color.WHITE);
        } else {
            setBackground(
                linha % 2 == 0
                    ? Estilo.PAINEL
                    : new Color(40, 46, 57)
            );

            if (coluna == 5 && valor instanceof Boolean ativo) {
                setForeground(
                    ativo
                        ? new Color(74, 222, 128)
                        : new Color(248, 113, 113)
                );
            } else {
                setForeground(Estilo.TEXTO);
            }
        }

        return this;
    }
}

    
    
    

  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        cbPesquisarPor = new javax.swing.JComboBox<>();
        txtPesquisar = new javax.swing.JTextField();
        btnExcluir = new javax.swing.JButton();
        btnAtualizar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblMecanicos = new javax.swing.JTable();
        txtID = new javax.swing.JTextField();
        txtNome = new javax.swing.JTextField();
        txtEspecialidade = new javax.swing.JTextField();
        txtData = new javax.swing.JTextField();
        txtTelefone = new javax.swing.JFormattedTextField();
        chkAtivo = new javax.swing.JCheckBox();
        btnLocalizar = new javax.swing.JButton();
        btnFechar = new javax.swing.JButton();
        btnAlterar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 153, 153));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        cbPesquisarPor.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ID", "Nome", "Especialidade", " " }));
        cbPesquisarPor.setBorder(javax.swing.BorderFactory.createTitledBorder("Filtro:"));

        txtPesquisar.setBorder(javax.swing.BorderFactory.createTitledBorder("Pesquisar:"));

        btnExcluir.setText("Excluir");
        btnExcluir.addActionListener(this::btnExcluirActionPerformed);

        btnAtualizar.setText("Atualizar");
        btnAtualizar.addActionListener(this::btnAtualizarActionPerformed);

        tblMecanicos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Nome", "Especialidade", "Telefone", "Data de Admissão", "Ativo"
            }
        ));
        tblMecanicos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblMecanicosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblMecanicos);

        txtID.setEditable(false);
        txtID.setBorder(javax.swing.BorderFactory.createTitledBorder("ID"));

        txtNome.setBorder(javax.swing.BorderFactory.createTitledBorder("Nome:"));

        txtEspecialidade.setBorder(javax.swing.BorderFactory.createTitledBorder("Especialidade"));

        txtData.setBorder(javax.swing.BorderFactory.createTitledBorder("Data de Admissão:"));

        txtTelefone.setBorder(javax.swing.BorderFactory.createTitledBorder("Telefone:"));
        try {
            txtTelefone.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("(##)#####-####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }

        chkAtivo.setSelected(true);
        chkAtivo.setText("Ativo");

        btnLocalizar.setText("Localizar");
        btnLocalizar.addActionListener(this::btnLocalizarActionPerformed);

        btnFechar.setText("Fechar");
        btnFechar.addActionListener(this::btnFecharActionPerformed);

        btnAlterar.setText("Alterar");
        btnAlterar.addActionListener(this::btnAlterarActionPerformed);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jScrollPane1)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(15, 15, 15)
                                .addComponent(cbPesquisarPor, javax.swing.GroupLayout.PREFERRED_SIZE, 320, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(txtPesquisar, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(49, 49, 49)
                                .addComponent(btnLocalizar, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnAtualizar, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(txtEspecialidade, javax.swing.GroupLayout.PREFERRED_SIZE, 329, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                        .addComponent(txtID, javax.swing.GroupLayout.PREFERRED_SIZE, 329, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(txtTelefone))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(txtNome, javax.swing.GroupLayout.PREFERRED_SIZE, 329, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(txtData, javax.swing.GroupLayout.PREFERRED_SIZE, 329, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(144, 144, 144)
                                .addComponent(chkAtivo)))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnAlterar, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnExcluir, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnFechar, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(38, 38, 38)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(txtPesquisar, javax.swing.GroupLayout.DEFAULT_SIZE, 56, Short.MAX_VALUE)
                                .addComponent(btnAtualizar, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(btnLocalizar, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(cbPesquisarPor))
                        .addGap(68, 68, 68)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(28, 28, 28)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtID, javax.swing.GroupLayout.DEFAULT_SIZE, 47, Short.MAX_VALUE)
                            .addComponent(txtTelefone))
                        .addGap(28, 28, 28))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(chkAtivo)
                        .addGap(16, 16, 16)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtNome, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtData, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addComponent(txtEspecialidade, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 79, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnFechar, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnExcluir, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnAlterar, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnFecharActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFecharActionPerformed
        dispose();
    }//GEN-LAST:event_btnFecharActionPerformed

    private void btnAtualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAtualizarActionPerformed
        atualizarTabela();
    }//GEN-LAST:event_btnAtualizarActionPerformed

    private void btnLocalizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLocalizarActionPerformed
       String pesquisa = txtPesquisar.getText().trim();

    if (pesquisa.isEmpty()) {
        JOptionPane.showMessageDialog(
            this, "Digite um valor para pesquisar."
        );
        return;
    }

    String tipo = cbPesquisarPor
        .getSelectedItem().toString();

    String sql;

    switch (tipo) {
        case "ID":
            sql = "SELECT * FROM mecanico WHERE id = ?";
            break;

        case "Nome":
            sql = "SELECT * FROM mecanico WHERE nome ILIKE ?";
            break;

        case "Especialidade":
            sql = "SELECT * FROM mecanico WHERE especialidade ILIKE ?";
            break;

        default:
            return;
    }

    Integer idPesquisa = null;

    if ("ID".equals(tipo)) {
        try {
            idPesquisa = Integer.valueOf(pesquisa);
        } catch (NumberFormatException erro) {
            JOptionPane.showMessageDialog(
                this, "Informe um ID numérico válido."
            );
            return;
        }
    }

    DefaultTableModel modelo =
        (DefaultTableModel) tblMecanicos.getModel();

    try (Connection conex = Conexao.conectar();
         PreparedStatement stmt = conex.prepareStatement(sql)) {

        if (idPesquisa != null) {
            stmt.setInt(1, idPesquisa);
        } else {
            stmt.setString(1, "%" + pesquisa + "%");
        }

        try (ResultSet rs = stmt.executeQuery()) {

            modelo.setRowCount(0);

            while (rs.next()) {
                modelo.addRow(new Object[]{
                    rs.getInt("id"),
                    rs.getString("nome"),
                    rs.getString("especialidade"),
                    rs.getString("telefone"),
                    rs.getString("data_admissao"),
                    rs.getBoolean("ativo")
                });
            }
        }

        if (modelo.getRowCount() == 0) {
            JOptionPane.showMessageDialog(
                this, "Nenhum mecânico encontrado."
            );
        }

    } catch (SQLException erro) {
        JOptionPane.showMessageDialog(
            this, "Erro na pesquisa: " + erro.getMessage()
        );
    }
    }//GEN-LAST:event_btnLocalizarActionPerformed

    private void btnAlterarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAlterarActionPerformed
        int linha =  tblMecanicos.getSelectedRow();
        if(linha == -1){
            JOptionPane.showMessageDialog(this, "Selecione um Mecanico");
            return;
        }
        int id = Integer.parseInt(tblMecanicos.getValueAt(linha, 0).toString());
        String nome = txtNome.getText().trim();
        String especialidade = txtEspecialidade.getText().trim();
        String telefone = txtTelefone.getText();
        String data_admissao = txtData.getText();
        Boolean ativo = chkAtivo.isSelected();
        
        LocalDate dataAdmissao;
        
        try{
            DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/uuuu").withResolverStyle(ResolverStyle.STRICT);
            
            dataAdmissao = LocalDate.parse(txtData.getText().trim(), formato);
        }catch(DateTimeParseException erro){
            JOptionPane.showMessageDialog(this, "Data Invalida");
            return;
        }
        
        int confirmacao = JOptionPane.showConfirmDialog(this,
                                "Deseja realmente alterar este mecanico?",
                                "Confirmar alteração",
                                JOptionPane.YES_NO_OPTION);
        
        if(confirmacao != JOptionPane.YES_OPTION)return;
        
        String sql = """
                     UPDATE mecanico
                     SET nome = ?,
                     especialidade = ?,
                     telefone = ?,
                     data_admissao = ?,
                     ativo = ?
                     WHERE id = ?                     
                     """;
        try(Connection conex = Conexao.conectar();
            PreparedStatement stmt = conex.prepareStatement(sql)){
                stmt.setString(1, nome);
                stmt.setString(2, especialidade);
                stmt.setString(3, telefone);
                stmt.setDate(4, java.sql.Date.valueOf(dataAdmissao));
                stmt.setBoolean(5, ativo);
                stmt.setInt(6, id);
                
                int linhasAlteradas = stmt.executeUpdate();
                
                if(linhasAlteradas >0){
                    Mensagem.sucesso(
    this, "Mecânico alterado com sucesso!"
);
                    
                    atualizarTabela();
                }else{
                    JOptionPane.showMessageDialog(this, "Mecanico nao encontrado");
                }
                
        }catch(SQLException erro){
            JOptionPane.showMessageDialog(this, "Erro ao alterar mecanico - Erro: " +erro.getMessage());
        }
    }//GEN-LAST:event_btnAlterarActionPerformed

    private void tblMecanicosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblMecanicosMouseClicked
         int linha = tblMecanicos.getSelectedRow();
    if (linha == -1) return;

    txtID.setText(String.valueOf(
        tblMecanicos.getValueAt(linha, 0)
    ));

    txtNome.setText(String.valueOf(
        tblMecanicos.getValueAt(linha, 1)
    ));

    txtEspecialidade.setText(String.valueOf(
        tblMecanicos.getValueAt(linha, 2)
    ));

    Object telefone = tblMecanicos.getValueAt(linha, 3);
    txtTelefone.setText(
        telefone == null ? "" : telefone.toString()
    );

    Object data = tblMecanicos.getValueAt(linha, 4);

    if (data != null && !data.toString().isBlank()) {
        try {
            LocalDate dataAdmissao = LocalDate.parse(
                data.toString()
            );

            txtData.setText(
                dataAdmissao.format(
                    DateTimeFormatter.ofPattern("dd/MM/uuuu")
                )
            );
        } catch (DateTimeParseException erro) {
            txtData.setText(data.toString());
        }
    } else {
        txtData.setText("");
    }

    boolean ativo = Boolean.TRUE.equals(
        tblMecanicos.getValueAt(linha, 5)
    );

    chkAtivo.setSelected(ativo);
    switchAtivo.setSelected(ativo);

    lblSituacao.setText(
        ativo ? "Mecânico ativo" : "Mecânico inativo"
    );
        
    }//GEN-LAST:event_tblMecanicosMouseClicked

    private void btnExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExcluirActionPerformed
        
    if (txtID.getText().trim().isEmpty()) {
        JOptionPane.showMessageDialog(this,
                "Selecione um mecanico para excluir!");
        return;
    }

    int id = Integer.parseInt(txtID.getText().trim());

    
    int confirmar = JOptionPane.showConfirmDialog(
            this,
            "Deseja realmente excluir este mecanico?",
            "Confirmar exclusao",
            JOptionPane.YES_NO_OPTION
    );

    if (confirmar != JOptionPane.YES_OPTION) {
        return;
    }

    
    String sqlVerificar = """
        SELECT COUNT(*)
        FROM ordem_servico
        WHERE mecanico_id = ?
        """;

    try (Connection conex = Conexao.conectar()) {

        int quantidade = 0;

        try (PreparedStatement stmt = conex.prepareStatement(sqlVerificar)) {

            stmt.setInt(1, id);

            try (ResultSet rs = stmt.executeQuery()) {

                if (rs.next()) {
                    quantidade = rs.getInt(1);
                }
            }
        }

       
        if (quantidade > 0) {

            int opcao = JOptionPane.showConfirmDialog(
                    this,
                    "Este mecanico possui " + quantidade
                    + " Ordem(ns) de Servico vinculada(s).\n"
                    + "Nao é possível exclui-lo.\n\n"
                    + "Deseja desativar o mecanico?",
                    "Mecanico com OS vinculada",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.WARNING_MESSAGE
            );

            if (opcao == JOptionPane.YES_OPTION) {

                String sqlDesativar = """
                    UPDATE mecanico
                    SET ativo = FALSE
                    WHERE id = ?
                    """;

                try (PreparedStatement stmt =
                        conex.prepareStatement(sqlDesativar)) {

                    stmt.setInt(1, id);

                    int linhas = stmt.executeUpdate();

                    if (linhas > 0) {
                        JOptionPane.showMessageDialog(this,
                                "Mecanico desativado com sucesso!");
                    }
                }
            }

        } else {

             
            String sqlExcluir = """
                DELETE FROM mecanico
                WHERE id = ?
                """;

            try (PreparedStatement stmt =
                    conex.prepareStatement(sqlExcluir)) {

                stmt.setInt(1, id);

                int linhas = stmt.executeUpdate();

                if (linhas > 0) {
                    JOptionPane.showMessageDialog(this,
                            "Mecanico excluído com sucesso!");
                } else {
                    JOptionPane.showMessageDialog(this,
                            "Mecanico não encontrado!");
                }
            }
        }

       
        atualizarTabela();

    } catch (SQLException erro) {

        JOptionPane.showMessageDialog(this,
                "Erro ao excluir mecanico: " + erro.getMessage());
     } 
    }//GEN-LAST:event_btnExcluirActionPerformed

    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new FrmConsultaMecanico().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAlterar;
    private javax.swing.JButton btnAtualizar;
    private javax.swing.JButton btnExcluir;
    private javax.swing.JButton btnFechar;
    private javax.swing.JButton btnLocalizar;
    private javax.swing.JComboBox<String> cbPesquisarPor;
    private javax.swing.JCheckBox chkAtivo;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblMecanicos;
    private javax.swing.JTextField txtData;
    private javax.swing.JTextField txtEspecialidade;
    private javax.swing.JTextField txtID;
    private javax.swing.JTextField txtNome;
    private javax.swing.JTextField txtPesquisar;
    private javax.swing.JFormattedTextField txtTelefone;
    // End of variables declaration//GEN-END:variables
}
