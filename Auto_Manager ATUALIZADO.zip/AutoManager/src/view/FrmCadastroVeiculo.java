
package view;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import conexao.Conexao;
import java.util.ArrayList;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import util.Estilo;
import util.Mensagem;
import util.SwitchAtivo;
import util.BordaArredondada;

public class FrmCadastroVeiculo extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(FrmCadastroVeiculo.class.getName());

    private ArrayList<Integer> idClientes = new ArrayList<>();

   
    
    
    public FrmCadastroVeiculo() {
        initComponents();
    criarInterface();
    carregarClientes("");
    }
    
    
private SwitchAtivo switchAtivo;

private void criarInterface() {

    setTitle("AutoManager | Cadastro de Veículos");
    setSize(1050, 720);
    setResizable(false);
    setLocationRelativeTo(null);

    Estilo.configurarIcone(this);

    Color fundo = Estilo.FUNDO;
    Color painel = Estilo.PAINEL;
    Color texto = Estilo.TEXTO;
    Color laranja = Estilo.LARANJA;

    // Remover os componentes do layout antigo
    getContentPane().removeAll();
    getContentPane().setLayout(new BorderLayout());

    JPanel principal = new JPanel(new BorderLayout(0, 18));
    principal.setBackground(fundo);
    principal.setBorder(new EmptyBorder(24, 35, 24, 35));

    // CABEÇALHO
    JPanel cabecalho = new JPanel(new BorderLayout());
    cabecalho.setOpaque(false);

    JLabel logo = new JLabel(Estilo.carregarLogo(280, 94));
    cabecalho.add(logo, BorderLayout.WEST);

    JLabel secao = new JLabel("VEÍCULOS / 02");
    secao.setForeground(laranja);
    secao.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 15));
    cabecalho.add(secao, BorderLayout.EAST);

    JPanel topo = new JPanel(new BorderLayout(0, 12));
    topo.setOpaque(false);
    topo.add(cabecalho, BorderLayout.CENTER);

    JPanel linha = new JPanel();
    linha.setBackground(laranja);
    linha.setPreferredSize(new Dimension(0, 2));
    topo.add(linha, BorderLayout.SOUTH);

    principal.add(topo, BorderLayout.NORTH);

    // ÁREA CENTRAL
    JPanel centro = new JPanel();
    centro.setOpaque(false);
    centro.setLayout(new BoxLayout(centro, BoxLayout.Y_AXIS));

    JLabel titulo = new JLabel("Cadastro de Veículos");
    titulo.setForeground(texto);
    titulo.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 27));
    titulo.setAlignmentX(Component.LEFT_ALIGNMENT);

    JLabel subtitulo = new JLabel(
        "CONTROLE E GERENCIAMENTO DE VEÍCULOS");
    subtitulo.setForeground(new Color(156, 163, 175));
    subtitulo.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));
    subtitulo.setAlignmentX(Component.LEFT_ALIGNMENT);

    centro.add(titulo);
    centro.add(Box.createVerticalStrut(5));
    centro.add(subtitulo);
    centro.add(Box.createVerticalStrut(20));

    // CARD PROPRIETÁRIO
    JPanel cardCliente = criarCard(
        "INFORMAÇÕES DO PROPRIETÁRIO", painel);

    JPanel camposCliente = new JPanel(new GridBagLayout());
    camposCliente.setOpaque(false);

    Estilo.configurarCampo(txtPesquisarCliente);
    Estilo.configurarFoco(txtPesquisarCliente);

    txtPesquisarCliente.setToolTipText(
        "Pesquise pelo nome ou ID do cliente");

    cbCliente.setFont(
        new Font(Font.SANS_SERIF, Font.PLAIN, 14));
    cbCliente.setBackground(Estilo.COMPONENTE);
    cbCliente.setForeground(texto);

    Estilo.configurarBotao(btnBuscarCliente, "laranja");
    btnBuscarCliente.setText("BUSCAR");
    btnBuscarCliente.setIcon(null);

    adicionarCampo(camposCliente,
        "Pesquisar cliente", txtPesquisarCliente, 0, 0);

    adicionarCampo(camposCliente,
        "Proprietário", cbCliente, 1, 0);

    GridBagConstraints busca = new GridBagConstraints();
    busca.gridx = 2;
    busca.gridy = 0;
    busca.insets = new Insets(21, 12, 5, 0);
    busca.fill = GridBagConstraints.HORIZONTAL;

    btnBuscarCliente.setPreferredSize(new Dimension(110, 40));
    camposCliente.add(btnBuscarCliente, busca);

    cardCliente.add(camposCliente, BorderLayout.CENTER);
    cardCliente.setAlignmentX(Component.LEFT_ALIGNMENT);
    centro.add(cardCliente);
    centro.add(Box.createVerticalStrut(15));

    // CARD VEÍCULO
    JPanel cardVeiculo = criarCard(
        "INFORMAÇÕES DO VEÍCULO", painel);

    JPanel camposVeiculo = new JPanel(new GridBagLayout());
    camposVeiculo.setOpaque(false);

    JTextField[] campos = {
        txtID, txtPlaca, txtMarca,
        txtModelo, txtAno, txtCor
    };

    for (JTextField campo : campos) {
        Estilo.configurarCampo(campo);
        if (campo != txtID) {
            Estilo.configurarFoco(campo);
        }
    }

    txtID.setEditable(false);
    txtID.setFocusable(false);
txtID.setText("");
txtID.setToolTipText("Gerado automaticamente");
Estilo.configurarCampo(txtID);

txtID.setBackground(new Color(35, 40, 49));
txtID.setForeground(new Color(156, 163, 175));



    adicionarCampo(camposVeiculo, "ID", txtID, 0, 0);
    adicionarCampo(camposVeiculo, "Placa", txtPlaca, 1, 0);
    adicionarCampo(camposVeiculo, "Marca", txtMarca, 0, 1);
    adicionarCampo(camposVeiculo, "Modelo", txtModelo, 1, 1);
    adicionarCampo(camposVeiculo, "Ano", txtAno, 0, 2);
    adicionarCampo(camposVeiculo, "Cor", txtCor, 1, 2);

    JPanel dadosVeiculo = new JPanel(new BorderLayout(0, 12));
    dadosVeiculo.setOpaque(false);
    dadosVeiculo.add(camposVeiculo, BorderLayout.NORTH);

    // OBSERVAÇÃO
    JPanel areaObservacao = new JPanel(new BorderLayout(0, 5));
    areaObservacao.setOpaque(false);

    JLabel lblObservacao = new JLabel("Observações");
    lblObservacao.setForeground(texto);

    txtObservacao.setFont(
        new Font(Font.SANS_SERIF, Font.PLAIN, 14));
    txtObservacao.setBackground(Estilo.COMPONENTE);
    txtObservacao.setForeground(texto);
    txtObservacao.setCaretColor(texto);
    txtObservacao.setLineWrap(true);
    txtObservacao.setWrapStyleWord(true);
    txtObservacao.setBorder(new EmptyBorder(8, 10, 8, 10));

    jScrollPane2.setBorder(
    new BordaArredondada(Estilo.BORDA, 18)
);
    jScrollPane2.setBackground(Estilo.COMPONENTE);
jScrollPane2.getViewport().setBackground(Estilo.COMPONENTE);
txtObservacao.setBackground(Estilo.COMPONENTE);

txtObservacao.addFocusListener(
    new java.awt.event.FocusAdapter() {

        @Override
        public void focusGained(java.awt.event.FocusEvent e) {
            jScrollPane2.setBorder(
                new BordaArredondada(Estilo.LARANJA, 18)
            );
        }

        @Override
        public void focusLost(java.awt.event.FocusEvent e) {
            jScrollPane2.setBorder(
                new BordaArredondada(Estilo.BORDA, 18)
            );
        }
    }
);

txtObservacao.setBorder(
    BorderFactory.createEmptyBorder(10, 14, 10, 14)
);
    jScrollPane2.setPreferredSize(new Dimension(0, 65));

    areaObservacao.add(lblObservacao, BorderLayout.NORTH);
    areaObservacao.add(jScrollPane2, BorderLayout.CENTER);

    dadosVeiculo.add(areaObservacao, BorderLayout.CENTER);

    // INTERRUPTOR ATIVO
    switchAtivo = new SwitchAtivo();
    switchAtivo.setSelected(chkAtivo.isSelected());

    switchAtivo.addActionListener(e ->
        chkAtivo.setSelected(switchAtivo.isSelected()));

    JPanel situacao = new JPanel(
        new FlowLayout(FlowLayout.LEFT, 10, 0));
    situacao.setOpaque(false);

    JLabel lblAtivo = new JLabel("Veículo ativo");
    lblAtivo.setForeground(texto);

    situacao.add(switchAtivo);
    situacao.add(lblAtivo);

    dadosVeiculo.add(situacao, BorderLayout.SOUTH);

    cardVeiculo.add(dadosVeiculo, BorderLayout.CENTER);
    cardVeiculo.setAlignmentX(Component.LEFT_ALIGNMENT);
    centro.add(cardVeiculo);

    JScrollPane scrollCentral = new JScrollPane(centro);

scrollCentral.setBorder(null);
scrollCentral.setOpaque(false);
scrollCentral.getViewport().setOpaque(false);

scrollCentral.setHorizontalScrollBarPolicy(
    JScrollPane.HORIZONTAL_SCROLLBAR_NEVER
);

scrollCentral.setVerticalScrollBarPolicy(
    JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED
);

scrollCentral.getVerticalScrollBar().setUnitIncrement(16);

principal.add(scrollCentral, BorderLayout.CENTER);

    // RODAPÉ
    JPanel rodape = new JPanel(
        new FlowLayout(FlowLayout.RIGHT, 12, 0));
    rodape.setOpaque(false);

    Estilo.configurarBotao(btnLimpar, "cinza");
    Estilo.configurarBotao(btnFechar, "vermelho");
    Estilo.configurarBotao(btnCadastrar, "laranja");

    Estilo.configurarHover(
        btnLimpar, new Color(100, 116, 139));
    Estilo.configurarHover(
        btnFechar, new Color(220, 38, 38));
    Estilo.configurarHover(
        btnCadastrar, new Color(234, 88, 12));

    btnLimpar.setText("LIMPAR");
    btnFechar.setText("FECHAR");
    btnCadastrar.setText("CADASTRAR VEÍCULO");

    btnLimpar.setPreferredSize(new Dimension(125, 42));
    btnFechar.setPreferredSize(new Dimension(125, 42));
    btnCadastrar.setPreferredSize(new Dimension(205, 42));

    rodape.add(btnLimpar);
    rodape.add(btnFechar);
    rodape.add(btnCadastrar);

    principal.add(rodape, BorderLayout.SOUTH);

    setContentPane(principal);
    revalidate();
    repaint();
}

// Cria um card com título e barra laranja
private JPanel criarCard(String titulo, Color corFundo) {

    JPanel card = new JPanel(new BorderLayout(0, 15));
    card.setBackground(corFundo);
    card.setBorder(new EmptyBorder(15, 20, 15, 20));

    JPanel cabecalho = new JPanel(
        new FlowLayout(FlowLayout.LEFT, 10, 0));
    cabecalho.setOpaque(false);

    JPanel barra = new JPanel();
    barra.setBackground(Estilo.LARANJA);
    barra.setPreferredSize(new Dimension(4, 18));

    JLabel label = new JLabel(titulo);
    label.setForeground(Estilo.TEXTO);
    label.setFont(
        new Font(Font.SANS_SERIF, Font.BOLD, 13));

    cabecalho.add(barra);
    cabecalho.add(label);

    card.add(cabecalho, BorderLayout.NORTH);
    return card;
}

// Organiza os campos em duas colunas
private void adicionarCampo(
        JPanel painel, String titulo,
        JComponent campo, int coluna, int linha) {

    JPanel grupo = new JPanel(new BorderLayout(0, 5));
    grupo.setOpaque(false);

    JLabel label = new JLabel(titulo);
    label.setForeground(Estilo.TEXTO);
    label.setFont(
        new Font(Font.SANS_SERIF, Font.PLAIN, 13));

    grupo.add(label, BorderLayout.NORTH);
    grupo.add(campo, BorderLayout.CENTER);

    GridBagConstraints gbc = new GridBagConstraints();
    gbc.gridx = coluna;
    gbc.gridy = linha;
    gbc.weightx = 1;
    gbc.fill = GridBagConstraints.HORIZONTAL;
    gbc.insets = new Insets(5, 6, 5, 6);

    painel.add(grupo, gbc);
}

    
    
    
    
    
    
    private void limparCampos(){
        txtPlaca.setText("");
        txtMarca.setText("");
        txtModelo.setText("");
        txtAno.setText("");
        txtCor.setText("");
        txtObservacao.setText("");
        txtPesquisarCliente.setText("");
        cbCliente.setSelectedIndex(-1);
        chkAtivo.setSelected(true);
        if (switchAtivo != null) {
    switchAtivo.setSelected(true);
}
        carregarClientes("");
        txtPlaca.requestFocus();
    }
    
    private void carregarClientes(String pesquisa){
        String sql = """
                     SELECT id, nome
                     FROM cliente
                     WHERE ativo = TRUE
                     AND (
                     ? = ''
                     OR (? = TRUE AND CAST(id AS TEXT) = ?)
                     OR (? = FALSE AND (nome ILIKE ? ))
                     )
                     
                     """;
        
        cbCliente.removeAllItems();
        idClientes.clear();
        
        try (Connection conex = Conexao.conectar();
             PreparedStatement stmt = conex.prepareStatement(sql)){
            
            boolean pesquisaId = pesquisa.matches("\\d+");

            stmt.setString(1, pesquisa);
            stmt.setBoolean(2, pesquisaId);
            stmt.setString(3, pesquisa);
            stmt.setBoolean(4, pesquisaId);
            stmt.setString(5, "%" + pesquisa + "%");
            
            try (ResultSet rs = stmt.executeQuery()) {
            while (rs.next()){
                int id = rs.getInt("id");
                String nome = rs.getString("nome");
                
                cbCliente.addItem("ID: " + id + " - " + nome);
                idClientes.add(id);
                
            }
            
          }  
            
            if (cbCliente.getItemCount() == 1) {
    cbCliente.setSelectedIndex(0);
} else {
    cbCliente.setSelectedIndex(-1);
}
            
        } catch (SQLException erro) {
            JOptionPane.showMessageDialog(this, "Erro ao pesquisar clientes: " + erro.getMessage());
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txtID = new javax.swing.JTextField();
        txtPesquisarCliente = new javax.swing.JTextField();
        btnBuscarCliente = new javax.swing.JButton();
        txtPlaca = new javax.swing.JTextField();
        txtMarca = new javax.swing.JTextField();
        txtModelo = new javax.swing.JTextField();
        txtCor = new javax.swing.JTextField();
        cbCliente = new javax.swing.JComboBox<>();
        txtAno = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtObservacao = new javax.swing.JTextArea();
        chkAtivo = new javax.swing.JCheckBox();
        btnLimpar = new javax.swing.JButton();
        btnFechar = new javax.swing.JButton();
        btnCadastrar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        txtID.setEditable(false);
        txtID.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "ID", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Verdana", 0, 12))); // NOI18N

        txtPesquisarCliente.setToolTipText("Digite aqui o ID do cliente:");
        txtPesquisarCliente.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Pesquisar cliente", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Verdana", 0, 12))); // NOI18N
        txtPesquisarCliente.addActionListener(this::txtPesquisarClienteActionPerformed);

        btnBuscarCliente.setIcon(new javax.swing.ImageIcon(getClass().getResource("/view/lupa_transparente_30x30.png"))); // NOI18N
        btnBuscarCliente.addActionListener(this::btnBuscarClienteActionPerformed);

        txtPlaca.setToolTipText("Digite aqui a placa do carro:");
        txtPlaca.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Placa", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Verdana", 0, 12))); // NOI18N

        txtMarca.setToolTipText("Digite aqui a marca do carro:");
        txtMarca.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Marca", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Verdana", 0, 12))); // NOI18N

        txtModelo.setToolTipText("Digite aqui o modelo do carro:");
        txtModelo.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Modelo", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Verdana", 0, 12))); // NOI18N
        txtModelo.addActionListener(this::txtModeloActionPerformed);

        txtCor.setToolTipText("Digite aqui a cor do carro:");
        txtCor.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Cor", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Verdana", 0, 12))); // NOI18N

        txtAno.setBorder(javax.swing.BorderFactory.createTitledBorder("Ano"));

        txtObservacao.setColumns(20);
        txtObservacao.setRows(5);
        txtObservacao.setBorder(javax.swing.BorderFactory.createTitledBorder("Observação"));
        jScrollPane2.setViewportView(txtObservacao);

        chkAtivo.setSelected(true);
        chkAtivo.setText("Veículo ativo");

        btnLimpar.setBackground(new java.awt.Color(204, 204, 0));
        btnLimpar.setText("Limpar");
        btnLimpar.addActionListener(this::btnLimparActionPerformed);

        btnFechar.setBackground(new java.awt.Color(102, 0, 0));
        btnFechar.setText("Fechar");
        btnFechar.addActionListener(this::btnFecharActionPerformed);

        btnCadastrar.setBackground(new java.awt.Color(0, 102, 0));
        btnCadastrar.setText("Cadastrar");
        btnCadastrar.addActionListener(this::btnCadastrarActionPerformed);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(jScrollPane2)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(txtCor, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(txtAno))
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                .addComponent(txtID, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(txtPlaca, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addComponent(txtModelo, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(18, 18, 18)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                            .addComponent(cbCliente, javax.swing.GroupLayout.Alignment.LEADING, 0, 193, Short.MAX_VALUE)
                                            .addComponent(txtPesquisarCliente, javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(txtMarca))))
                                .addGap(18, 18, 18)
                                .addComponent(btnBuscarCliente))
                            .addComponent(chkAtivo))
                        .addGap(0, 97, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnFechar, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnLimpar, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnCadastrar, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnBuscarCliente, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(txtPesquisarCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(txtID, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(cbCliente, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtPlaca, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(119, 119, 119)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtMarca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtModelo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtAno, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtCor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(chkAtivo)
                        .addContainerGap(160, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnCadastrar, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnFechar, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnLimpar, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap())))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtModeloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtModeloActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtModeloActionPerformed

    private void txtPesquisarClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPesquisarClienteActionPerformed
        String pesquisa = txtPesquisarCliente.getText().trim();
    carregarClientes(pesquisa);

    }//GEN-LAST:event_txtPesquisarClienteActionPerformed

    private void btnLimparActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimparActionPerformed
        limparCampos();
    }//GEN-LAST:event_btnLimparActionPerformed

    private void btnCadastrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCadastrarActionPerformed
     
        int posicao = cbCliente.getSelectedIndex();
        
        if(posicao == -1){
            Mensagem.aviso(this, "Selecione um cliente!");
            return;
        }
        
        int idCliente = idClientes.get(posicao);
        
          String placa = txtPlaca.getText().trim().toUpperCase();
          String marca = txtMarca.getText().trim();
          String modelo = txtModelo.getText().trim();
          String cor = txtCor.getText().trim();
          String observacao = txtObservacao.getText().trim();
          boolean ativo = chkAtivo.isSelected();
          
          if(placa.isEmpty() || marca.isEmpty() || modelo.isEmpty()){
              Mensagem.aviso(this, "Preencha placa, marca e modelo!");
              return;
          }
          
          int ano;
          
          try {
            ano = Integer.parseInt(txtAno.getText().trim());
            
        } catch (NumberFormatException erro) {
            Mensagem.aviso(this, "Digite um ano válido!");
            return;
        }
          
          if(ano < 1900 || ano > 2100){
              Mensagem.aviso(this, "O ano deve ser entre 1900 e 2100!");
              return;
          }
        
        String sqlInsert = """
                           INSERT INTO veiculo
                           (cliente_id,placa,marca,modelo,ano,cor,observacao,ativo)
                           VALUES (?,?,?,?,?,?,?,?)
                           """;
        
        try {
            Connection conex = Conexao.conectar();
            PreparedStatement stmt = conex.prepareStatement(sqlInsert);
            
          stmt.setInt(1, idCliente);
          stmt.setString(2, placa);
          stmt.setString(3, marca);
          stmt.setString(4, modelo);
          stmt.setInt(5, ano);
          stmt.setString(6, cor);
          stmt.setString(7, observacao);
          stmt.setBoolean(8, ativo);                  

            int linhas = stmt.executeUpdate();
            if(linhas >0){
           	Mensagem.sucesso(this, "Veículo cadastrado com sucesso!");
            limparCampos();
            }
        } catch (SQLException erro) {
            Mensagem.erro(
    this,
    "Erro ao pesquisar clientes: " + erro.getMessage()
);
        }
        
    }//GEN-LAST:event_btnCadastrarActionPerformed

    private void btnFecharActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFecharActionPerformed
        dispose();
    }//GEN-LAST:event_btnFecharActionPerformed

    private void btnBuscarClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarClienteActionPerformed
    String pesquisa = txtPesquisarCliente.getText().trim();
    
        carregarClientes(pesquisa);
    }//GEN-LAST:event_btnBuscarClienteActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
         Estilo.configurarTema();
        java.awt.EventQueue.invokeLater(() -> new FrmCadastroVeiculo().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBuscarCliente;
    private javax.swing.JButton btnCadastrar;
    private javax.swing.JButton btnFechar;
    private javax.swing.JButton btnLimpar;
    private javax.swing.JComboBox<String> cbCliente;
    private javax.swing.JCheckBox chkAtivo;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField txtAno;
    private javax.swing.JTextField txtCor;
    private javax.swing.JTextField txtID;
    private javax.swing.JTextField txtMarca;
    private javax.swing.JTextField txtModelo;
    private javax.swing.JTextArea txtObservacao;
    private javax.swing.JTextField txtPesquisarCliente;
    private javax.swing.JTextField txtPlaca;
    // End of variables declaration//GEN-END:variables
}
